import supabase from './db-client.js';

// Leaderboard scores. Validated server-side: boards/scopes whitelisted,
// scores capped, names sanitized, per-name rate limited.

const BOARDS = ['daily', 'weekly', 'alltime'];
const MAX_SCORE = 100000;

const cleanName = (n) => String(n ?? 'Player').slice(0, 16).replace(/[<>]/g, '') || 'Player';
const cleanScope = (s) => String(s ?? '').slice(0, 24);

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const board = String(req.query.board ?? 'daily');
      const scope = cleanScope(req.query.scope ?? '');
      if (!BOARDS.includes(board)) return res.status(400).json({ error: 'bad board' });
      let q = supabase.from('scores').select('*').eq('board', board).order('score', { ascending: false }).limit(50);
      if (board !== 'alltime' && scope) q = q.eq('scope', scope);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { board, score, scope, name, avatar, title } = req.body ?? {};
      if (!BOARDS.includes(board)) return res.status(400).json({ error: 'bad board' });
      const pts = Math.floor(Number(score));
      if (!Number.isFinite(pts) || pts < 0 || pts > MAX_SCORE) return res.status(400).json({ error: 'bad score' });

      const nm = cleanName(name);
      // rate limit: max 1 row per name+board+scope per 60s (delete-then-insert pattern via check)
      const since = new Date(Date.now() - 60 * 1000).toISOString();
      const { data: recent } = await supabase.from('scores')
        .select('id').eq('board', board).eq('scope', cleanScope(scope)).eq('name', nm)
        .gte('created_at', since).limit(1);
      if (recent && recent.length) return res.status(429).json({ error: 'too fast, try again later' });

      // keep only best per name+board+scope: delete lower previous
      await supabase.from('scores').delete().eq('board', board).eq('scope', cleanScope(scope)).eq('name', nm).lt('score', pts);

      const { data: existing } = await supabase.from('scores')
        .select('id,score').eq('board', board).eq('scope', cleanScope(scope)).eq('name', nm).limit(1);
      if (existing && existing.length && existing[0].score >= pts) {
        return res.status(200).json({ ok: true, kept: true });
      }

      const { data, error } = await supabase.from('scores').insert({
        board, score: pts, scope: cleanScope(scope), name: nm,
        avatar: String(avatar ?? '⛏️').slice(0, 4),
        title: String(title ?? 'Rookie').slice(0, 24),
      }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

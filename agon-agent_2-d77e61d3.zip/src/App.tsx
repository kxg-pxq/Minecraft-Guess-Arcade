import { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { TopBar, BottomNav, Footer } from './components/Layout';
import Home from './pages/Home';
import Play from './pages/Play';
import GamePage from './pages/GamePage';
import Daily from './pages/Daily';
import Arcade from './pages/Arcade';
import { WikiIndex, WikiDetail } from './pages/Wiki';
import Leaderboards from './pages/Leaderboards';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import { usePlayer } from './lib/store';

function Shell() {
  const p = usePlayer();
  const gold = p.theme === 'gold';
  const color = p.colorUI !== false;
  useEffect(() => {
    document.body.classList.toggle('t-gold', gold);
    document.body.classList.toggle('t-color', color);
    return () => { document.body.classList.remove('t-gold'); document.body.classList.remove('t-color'); };
  }, [gold, color]);
  const themeBg = p.theme === 'nether' ? 'bg-[#1a0d12]' : p.theme === 'end' ? 'bg-[#0d0d1a]' : p.theme === 'gold' ? 'bg-[#201503]' : 'bg-[#150e20]';
  return (
    <div className={`min-h-screen ${themeBg} bg-grid pb-20 md:pb-0 ${gold ? 't-gold' : ''} ${color ? 't-color' : ''}`}>
      <TopBar />
      <main className="mx-auto max-w-7xl px-3 py-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/play" element={<Play />} />
          <Route path="/play/:id" element={<GamePage />} />
          <Route path="/daily" element={<Daily />} />
          <Route path="/arcade" element={<Arcade />} />
          <Route path="/wiki" element={<WikiIndex />} />
          <Route path="/wiki/:id" element={<WikiDetail />} />
          <Route path="/leaderboards" element={<Leaderboards />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
      <Footer />
      <BottomNav />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Shell />
    </BrowserRouter>
  );
}

// Shared profile-frame catalogue. All frames are FREE and apply to the
// top-right corner profile avatar (header chip) + the profile page avatar.
// Top 3 picks are exact image frames (local copies of user-supplied art):
//   frame-1.png = PRO crest      (src: designarena asset a3bf0646…)
//   frame-2.png = Victory crest  (src: designarena asset 489943e7…)
//   frame-3.png = Elite Eight    (src: designarena asset 5c957bdf…)
export interface FrameDef { id: string; name: string; hint: string; swatch: string; img?: string; }

export const FRAMES: FrameDef[] = [
  { id: 'art-pro', name: 'Pro Gold', hint: 'Top Pick 1 — ornate PRO crest', swatch: '#ffd94f', img: '/frames/frame-1.png' },
  { id: 'art-victory', name: 'Victory Crest', hint: 'Top Pick 2 — victory laurel', swatch: '#ffd94f', img: '/frames/frame-2.png' },
  { id: 'art-elite', name: 'Elite Eight', hint: 'Top Pick 3 — elite numeral', swatch: '#ffd94f', img: '/frames/frame-3.png' },
  { id: 'default', name: 'Default', hint: 'Starter frame', swatch: '#3b2a55' },
  { id: 'gold', name: 'Gold', hint: 'Classic gold glow', swatch: '#ffd94f' },
  { id: 'nether', name: 'Nether', hint: 'Fiery red rim', swatch: '#c93a2b' },
  { id: 'end', name: 'End', hint: 'Mystic purple', swatch: '#b04fd8' },
  { id: 'diamond', name: 'Diamond', hint: 'Icy cyan shine', swatch: '#5ff2e0' },
  { id: 'emerald', name: 'Emerald', hint: 'Lucky green', swatch: '#2ee6a8' },
  { id: 'ruby', name: 'Ruby', hint: 'Bold pink-red', swatch: '#ff4d6d' },
  { id: 'frost', name: 'Frost', hint: 'Winter blue', swatch: '#8fd0ff' },
  { id: 'shadow', name: 'Shadow', hint: 'Deep indigo', swatch: '#6b5ce7' },
  { id: 'lava', name: 'Lava', hint: 'Molten orange', swatch: '#ff6a1a' },
  { id: 'slime', name: 'Slime', hint: 'Toxic lime', swatch: '#7CFC00' },
  { id: 'royal', name: 'Royal', hint: 'Lavender regal', swatch: '#c9a0ff' },
  { id: 'rainbow', name: 'Rainbow', hint: 'Gradient border', swatch: 'linear-gradient(135deg,#ff4d6d,#ffd94f,#6abe30,#4fa8f0,#b04fd8)' },
  { id: 'animated', name: 'Pulse', hint: 'Pulsing gold glow', swatch: '#ffd94f' },
  { id: 'pro', name: 'Champion Pro', hint: 'Ornate gold + crown', swatch: '#ffd94f' },
];

const IDS = new Set(FRAMES.map(f => f.id));
export const safeFrame = (id: string) => (IDS.has(id) ? id : 'default');

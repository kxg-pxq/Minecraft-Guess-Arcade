// Per-mob combat stats for Mob vs Mob.
// HP and Attack = Normal-difficulty values from the Minecraft Wiki.
// Delays / dodge / armor are tuned for a fun arena pace (see notes).

export interface MobStat {
  hp: number;    // health points (2 = 1 heart)
  atk: number;   // attack damage per hit (Normal difficulty)
  delay: number; // seconds between attacks
  dodge: number; // 0..1 chance to dodge an incoming hit (defense)
  armor: number; // flat damage blocked per hit (arena rule, see note)
  note: string;  // flavor / special behavior
}

export const MOB_STATS: Record<string, MobStat> = {
  creeper:   { hp: 20, atk: 32, delay: 1.5, dodge: 0,    armor: 0, note: 'Explodes once at close range, then dies (kamikaze!)' },
  zombie:    { hp: 20, atk: 3,  delay: 0.9, dodge: 0.05, armor: 0, note: 'Relentless melee brawler' },
  skeleton:  { hp: 20, atk: 4,  delay: 2.0, dodge: 0.15, armor: 0, note: 'Ranged arrows; strafes to dodge' },
  spider:    { hp: 16, atk: 2,  delay: 0.9, dodge: 0.10, armor: 0, note: 'Fast pounces, low damage' },
  enderman:  { hp: 40, atk: 7,  delay: 1.0, dodge: 0.25, armor: 0, note: 'Teleports away from hits' },
  pig:       { hp: 10, atk: 0,  delay: 2.0, dodge: 0,    armor: 0, note: 'Passive — cannot attack' },
  cow:       { hp: 10, atk: 0,  delay: 2.0, dodge: 0,    armor: 0, note: 'Passive — cannot attack' },
  sheep:     { hp: 8,  atk: 0,  delay: 2.0, dodge: 0,    armor: 0, note: 'Passive — cannot attack' },
  chicken:   { hp: 4,  atk: 0,  delay: 1.5, dodge: 0.10, armor: 0, note: 'Passive — but tiny and quick' },
  wolf:      { hp: 20, atk: 4,  delay: 1.0, dodge: 0.10, armor: 0, note: 'Tamed stats; savage bite' },
  villager:  { hp: 20, atk: 0,  delay: 2.0, dodge: 0,    armor: 0, note: 'Passive — hrmm...' },
  iron_golem:{ hp: 100, atk: 14, delay: 1.0, dodge: 0,   armor: 1, note: 'Huge HP; hide blocks 1 dmg/hit (arena)' },
  blaze:     { hp: 20, atk: 5,  delay: 2.2, dodge: 0.10, armor: 0, note: 'Fireball bursts from range' },
  ghast:     { hp: 10, atk: 11, delay: 3.0, dodge: 0.10, armor: 0, note: 'Slow but massive fireballs' },
  slime:     { hp: 16, atk: 4,  delay: 1.0, dodge: 0.05, armor: 0, note: 'Big-slime bounce damage' },
  witch:     { hp: 26, atk: 6,  delay: 2.0, dodge: 0.15, armor: 0, note: 'Splash potions; drinks healing!' },
  pillager:  { hp: 24, atk: 4,  delay: 3.0, dodge: 0.05, armor: 0, note: 'Slow crossbow reloads' },
  axolotl:   { hp: 14, atk: 2,  delay: 1.0, dodge: 0.10, armor: 0, note: 'Scrappy little predator' },
  bee:       { hp: 10, atk: 2,  delay: 1.2, dodge: 0.15, armor: 0, note: 'May die after stinging' },
  warden:    { hp: 500, atk: 30, delay: 2.0, dodge: 0,   armor: 2, note: 'Final boss. Good luck.' },
};

import type { PlayerStats } from '../lib/store';

export interface Achievement {
  k: string; n: string; d: string; icon: string; xp: number; secret?: boolean;
  check: (s: PlayerStats, ctx: { perfect?: boolean; combo?: number; speedMs?: number; game?: string; diff?: string }) => boolean;
}

export const ACHIEVEMENTS: Achievement[] = [
  { k:'first-steps', n:'First Steps', d:'Play your first game', icon:'Footprints', xp:50, check:s=>s.games>=1 },
  { k:'warming-up', n:'Warming Up', d:'Play 10 games', icon:'Flame', xp:100, check:s=>s.games>=10 },
  { k:'arcade-regular', n:'Arcade Regular', d:'Play 50 games', icon:'Gamepad2', xp:250, check:s=>s.games>=50 },
  { k:'arcade-legend', n:'Arcade Legend', d:'Play 150 games', icon:'Trophy', xp:600, check:s=>s.games>=150 },
  { k:'sharp-eye', n:'Sharp Eye', d:'Answer 25 questions correctly', icon:'Eye', xp:100, check:s=>s.correct>=25 },
  { k:'know-it-all', n:'Know-It-All', d:'Answer 200 correctly', icon:'Brain', xp:400, check:s=>s.correct>=200 },
  { k:'scholar', n:'Block Scholar', d:'Answer 500 correctly', icon:'GraduationCap', xp:900, check:s=>s.correct>=500 },
  { k:'perfectionist', n:'Perfectionist', d:'Finish a game with 100% accuracy', icon:'Star', xp:200, check:(_s,c)=>!!c.perfect },
  { k:'flawless-x3', n:'Flawless x3', d:'3 perfect games total', icon:'Sparkles', xp:400, check:s=>s.perfectRuns>=3 },
  { k:'combo-5', n:'Combo x5', d:'Reach a 5-answer combo', icon:'Zap', xp:120, check:(_s,c)=>(c.combo??0)>=5 },
  { k:'combo-10', n:'Combo x10', d:'Reach a 10-answer combo', icon:'Zap', xp:300, check:(_s,c)=>(c.combo??0)>=10 },
  { k:'combo-20', n:'Unstoppable', d:'Reach a 20-answer combo', icon:'Rocket', xp:700, check:(_s,c)=>(c.combo??0)>=20 },
  { k:'speedster', n:'Speedster', d:'Answer correctly in under 2 seconds', icon:'Timer', xp:150, check:(_s,c)=>(c.speedMs??99999)<2000 },
  { k:'lightning', n:'Lightning Brain', d:'Answer correctly in under 1 second', icon:'Zap', xp:350, check:(_s,c)=>(c.speedMs??99999)<1000 },
  { k:'daily-devotee', n:'Daily Devotee', d:'Complete a Daily Pack', icon:'CalendarCheck', xp:200, check:s=>s.dailyDone>=1 },
  { k:'streak-3', n:'On a Roll', d:'Reach a 3-day streak', icon:'Flame', xp:200, check:s=>s.bestStreak>=3 },
  { k:'streak-7', n:'Week Warrior', d:'Reach a 7-day streak', icon:'Flame', xp:500, check:s=>s.bestStreak>=7 },
  { k:'streak-30', n:'Monthly Master', d:'Reach a 30-day streak', icon:'Crown', xp:1500, check:s=>s.bestStreak>=30 },
  { k:'explorer', n:'Explorer', d:'Open 10 wiki pages', icon:'BookOpen', xp:120, check:s=>s.wikiViews>=10 },
  { k:'librarian', n:'Librarian', d:'Open 40 wiki pages', icon:'Library', xp:350, check:s=>s.wikiViews>=40 },
  { k:'collector-10', n:'Collector', d:'Discover 10 entities', icon:'Package', xp:150, check:s=>s.discovered>=10 },
  { k:'collector-50', n:'Hoarder', d:'Discover 50 entities', icon:'Boxes', xp:450, check:s=>s.discovered>=50 },
  { k:'collector-all', n:'Completionist', d:'Discover 100 entities', icon:'Gem', xp:1200, check:s=>s.discovered>=100 },
  { k:'tournament-champ', n:'Champion', d:'Win a tournament', icon:'Medal', xp:250, check:s=>s.tournaments>=1 },
  { k:'tournament-x5', n:'Grand Champion', d:'Win 5 tournaments', icon:'Trophy', xp:600, check:s=>s.tournaments>=5 },
  { k:'insane-clear', n:'Fearless', d:'Finish a game on Insane', icon:'Skull', xp:400, check:s=>s.insaneClears>=1 },
  { k:'nightmare-clear', n:'Nightmare Fuel', d:'Finish a game on Nightmare', icon:'Ghost', xp:800, check:s=>s.nightmareClears>=1 },
  { k:'endless-15', n:'Endless Hunger', d:'Score 15+ in Endless mode', icon:'Infinity', xp:300, check:s=>s.bestEndless>=15 },
  { k:'survivor', n:'Survivor', d:'Clear Survival mode with lives left', icon:'Heart', xp:300, check:s=>s.survivalWins>=1 },
  { k:'boss-slayer', n:'Boss Slayer', d:'Clear a Boss Round', icon:'Swords', xp:500, check:s=>s.bossClears>=1 },
  { k:'letter-ace', n:'Letter Ace', d:'Score 500+ in Letter Rush', icon:'CaseSensitive', xp:300, check:s=>s.bestLetterRush>=500 },
  { k:'memory-master', n:'Memory Master', d:'Clear Texture Memory perfectly', icon:'BrainCircuit', xp:350, check:s=>s.memoryPerfect>=1 },
  { k:'voter', n:'Voice of the People', d:'Vote in 10 fun battles', icon:'Vote', xp:150, check:s=>s.votes>=10 },
  { k:'night-owl', n:'Night Owl', d:'Play after midnight (local)', icon:'Moon', xp:100, secret:true, check:()=>{const h=new Date().getHours();return h<5;} },
  { k:'misclick', n:'Too Fast', d:'Answer in under 0.5s', icon:'Rabbit', xp:80, secret:true, check:(_s,c)=>(c.speedMs??99999)<500&&(c.speedMs??0)>0 },
  { k:'comeback', n:'Comeback Kid', d:'Win after dropping to 1 life in Survival', icon:'HeartPulse', xp:400, secret:true, check:s=>s.comebackWins>=1 },
];

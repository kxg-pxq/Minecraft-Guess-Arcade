// TOURNAMENT engine: 8-contender single-elim bracket with advancing rounds.

import { useMemo, useState } from 'react';
import { byCat } from '../data/entities';
import type { Cat } from '../data/entities';
import { recordGame, addXp, getState, usePlayer, shuffle } from '../lib/store';
import { playUI } from '../lib/audio';
import PixelSprite from '../components/PixelSprite';
import Icon from '../components/Icon';
import { checkAchievements, Toast } from '../components/Achievements';

const CRITERIA = ['Personal Favorite', 'Most Useful', 'Best Looking', 'Community Love'];

export default function TourneyEngine({ gameId, mode }: { gameId: string; mode: string }) {
  const player = usePlayer();
  const pool: Cat = mode === 'mob' ? 'mob' : 'block';
  const [criterion] = useState(() => CRITERIA[Math.floor(Math.random() * CRITERIA.length)]);
  const [contenders] = useState(() => shuffle(byCat(pool)).slice(0, 8));
  const [roundIdx, setRoundIdx] = useState(0); // 0=quarters,1=semis,2=final
  const [matchIdx, setMatchIdx] = useState(0);
  const [winners, setWinners] = useState<string[]>([]);
  const [champion, setChampion] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const current: string[] = useMemo(() => {
    if (roundIdx === 0) return contenders.map(c => c.id);
    return winners;
  }, [roundIdx, winners, contenders]);

  const a = current[matchIdx * 2];
  const b = current[matchIdx * 2 + 1];
  const ea = contenders.concat(byCat(pool)).find(e => e.id === a) ?? byCat(pool).find(e => e.id === a);
  const eb = contenders.concat(byCat(pool)).find(e => e.id === b) ?? byCat(pool).find(e => e.id === b);

  const pick = (id: string) => {
    playUI('click', player.sound ? player.volume : 0);
    const w = [...winners, id];
    const matchesInRound = current.length / 2;
    if (matchIdx + 1 >= matchesInRound) {
      if (current.length <= 2) {
        setChampion(id);
        const s = getState();
        import('../lib/store').then(m => {
          m.setState({ tournaments: s.tournaments + 1 });
          m.addXp(150); m.recordGame(gameId, 1000, 7, 7);
        });
        checkAchievements({ game: gameId });
        setToast('tournament-champ');
      } else {
        setWinners(w); setRoundIdx(r => r + 1); setMatchIdx(0);
      }
    } else { setWinners(w); setMatchIdx(m => m + 1); }
  };

  const roundName = roundIdx === 0 ? 'QUARTERFINAL' : roundIdx === 1 ? 'SEMIFINAL' : 'GRAND FINAL';

  if (champion) {
    const e = byCat(pool).find(x => x.id === champion)!;
    return (
      <div className="mc-panel p-6 text-center">
        <Toast msg={toast} onDone={() => setToast(null)} />
        <div className="font-pixel text-xl text-[#ffd94f]">🏆 CHAMPION 🏆</div>
        <div className="mx-auto mt-3 w-fit rounded-lg border-4 border-[#ffd94f] bg-black/40 p-3">
          <PixelSprite id={e.id} pal={e.pal} size={16} pixelSize={8} />
        </div>
        <div className="mt-2 text-2xl font-black text-white">{e.name}</div>
        <div className="text-sm text-white/60">Criterion: {criterion} · +150 XP</div>
        <div className="mt-4 flex justify-center gap-2">
          <button className="mc-btn" onClick={() => window.location.reload()}>NEW BRACKET</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="mc-chip">{roundName}</span>
        <span className="mc-chip !bg-[#7a4fb0]">Criterion: {criterion}</span>
        <span className="mc-chip">Match {matchIdx + 1}/{current.length / 2}</span>
      </div>
      {/* bracket progress */}
      <div className="mc-panel flex flex-wrap justify-center gap-1 p-2">
        {contenders.map(c => {
          const alive = current.includes(c.id);
          const isW = winners.includes(c.id);
          return (
            <div key={c.id} title={c.name} className={`rounded border-2 p-0.5 ${!alive && !isW ? 'border-black/40 opacity-25 grayscale' : isW ? 'border-[#6abe30]' : 'border-black/60'}`}>
              <PixelSprite id={c.id} pal={c.pal} size={8} pixelSize={3} />
            </div>
          );
        })}
      </div>
      <div className="grid gap-3 sm:grid-cols-[1fr_auto_1fr]">
        {[ea, eb].map((e, i) => e && (
          <button key={e.id + i} onClick={() => pick(e.id)} className="mc-panel group p-4 text-center transition-transform hover:scale-[1.02]">
            <PixelSprite id={e.id} pal={e.pal} size={16} pixelSize={6} />
            <div className="mt-2 text-lg font-black text-white">{e.name}</div>
            <div className="text-xs text-white/50">{e.sub}</div>
            <div className="mc-btn mx-auto mt-2 !bg-[#2e7d32]">CHOOSE</div>
          </button>
        ))}
        <div className="hidden items-center font-pixel text-2xl text-[#ffd94f] sm:flex">VS</div>
      </div>
      <p className="text-center text-xs text-white/40">Bracket advances after every choice. Winner takes the crown!</p>
    </div>
  );
}

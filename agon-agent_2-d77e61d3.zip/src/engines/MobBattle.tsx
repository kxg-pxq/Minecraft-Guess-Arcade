// MOB VS MOB BATTLE ARENA: pick 2 mobs, watch them fight with real-ish stats.
// HP + attack from the Minecraft Wiki (Normal difficulty). Dodge/armor/delay
// are arena tuning. Full battle log of hits & dodges, synth damage sounds.

import { useEffect, useRef, useState } from 'react';
import { byId, byCat, type Entity } from '../data/entities';
import { MOB_STATS } from '../data/mobstats';
import { DIFFS, type Diff } from '../lib/difficulty';
import { recordGame, addXp, setRecord, getState, usePlayer } from '../lib/store';
import { playBattleHit, playBattleDodge, playBattleDie, playBattleHeal, playUI } from '../lib/audio';
import PixelSprite from '../components/PixelSprite';
import Icon from '../components/Icon';
import { ScoreHUD } from '../components/GameUI';
import { checkAchievements, Toast } from '../components/Achievements';

interface Props { gameId: string; }

interface LogLine { n: number; text: string; kind: 'hit' | 'dodge' | 'block' | 'heal' | 'die' | 'info' | 'boom'; }

interface Fighter {
  ent: Entity; maxHp: number; hp: number; atk: number; delay: number;
  nextAt: number; dodge: number; armor: number; usedBoom: boolean;
  stung: boolean; healed: boolean; hurtTick: number;
}

const SUFFIX = ['BATTLE', 'REMATCH', 'SHOWDOWN', 'CLASH', 'RUMBLE'];

export default function MobBattle({ gameId }: Props) {
  const player = usePlayer();
  const mobs = byCat('mob');
  const [idA, setIdA] = useState('creeper');
  const [idB, setIdB] = useState('zombie');
  const [picking, setPicking] = useState<1 | 2 | null>(1);
  const [phase, setPhase] = useState<'select' | 'fight' | 'over'>('select');
  const [fighters, setFighters] = useState<[Fighter, Fighter] | null>(null);
  const [log, setLog] = useState<LogLine[]>([]);
  const [winner, setWinner] = useState<0 | 1 | 2>(0); // 0 none, 1 A, 2 B, 3 draw handled via 0+over
  const [draw, setDraw] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [battles, setBattles] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const timer = useRef<number>(0);
  const clock = useRef(0);
  const lineNo = useRef(0);
  const logRef = useRef<HTMLDivElement>(null);
  const vol = player.sound && !muted ? player.volume : 0;

  const mk = (id: string): Fighter => {
    const ent = byId(id)!;
    const s = MOB_STATS[id] ?? { hp: 20, atk: 2, delay: 1, dodge: 0, armor: 0, note: '' };
    return { ent, maxHp: s.hp, hp: s.hp, atk: s.atk, delay: s.delay, nextAt: s.delay, dodge: s.dodge, armor: s.armor, usedBoom: false, stung: false, healed: false, hurtTick: 0 };
  };

  const pushLog = (text: string, kind: LogLine['kind']) => {
    lineNo.current += 1;
    setLog(l => [...l.slice(-60), { n: lineNo.current, text, kind }]);
  };

  const startFight = (a?: string, b?: string) => {
    const A = a ?? idA, B = b ?? idB;
    if (A === B) { pushLog('Pick two DIFFERENT mobs!', 'info'); return; }
    window.clearInterval(timer.current);
    lineNo.current = 0; clock.current = 0;
    const f: [Fighter, Fighter] = [mk(A), mk(B)];
    setFighters(f); setLog([]); setWinner(0); setDraw(false);
    setPhase('fight');
    const ea = byId(A)!, eb = byId(B)!;
    setTimeout(() => {
      pushLog(`⚔️ ${ea.name} (${f[0].maxHp} HP, ${f[0].atk} dmg) VS ${eb.name} (${f[1].maxHp} HP, ${f[1].atk} dmg) — FIGHT!`, 'info');
      if (f[0].atk === 0 && f[1].atk === 0) pushLog('Two passive mobs… they stare at each other warmly. Longest hug wins?', 'info');
    }, 30);
  };

  // fight loop
  useEffect(() => {
    if (phase !== 'fight' || !fighters) return;
    timer.current = window.setInterval(() => {
      clock.current += 0.1 * speed;
      setFighters(prev => {
        if (!prev) return prev;
        const [A, B] = prev.map(f => ({ ...f })) as [Fighter, Fighter];
        const events: { t: string; k: LogLine['kind']; snd: 'hit' | 'dodge' | 'die' | 'heal' | 'heavy' | null; sndF: Fighter | null }[] = [];
        const strike = (atk: Fighter, def: Fighter, atkIdx: number) => {
          // Creeper kamikaze: explodes on first attack
          if (atk.ent.id === 'creeper' && !atk.usedBoom) {
            atk.usedBoom = true;
            const dmg = 32;
            def.hp = Math.max(0, def.hp - dmg);
            def.hurtTick++;
            events.push({ t: `💥 ${atk.ent.name} EXPLODES for ${dmg} damage! ${def.ent.name} → ${def.hp}/${def.maxHp} HP`, k: 'boom', snd: 'heavy', sndF: def });
            atk.hp = 0; // creeper dies in blast
            events.push({ t: `☠️ ${atk.ent.name} was destroyed in its own blast!`, k: 'die', snd: 'die', sndF: null });
            return;
          }
          if (atk.hp <= 0) return;
          if (atk.atk === 0) { // passive: skip quietly (nudge clock to avoid spam)
            atk.nextAt = clock.current + atk.delay;
            return;
          }
          // bee sting death chance after stinging
          if (Math.random() < def.dodge) {
            events.push({ t: `💨 ${def.ent.name} DODGED ${atk.ent.name}'s attack!`, k: 'dodge', snd: 'dodge', sndF: null });
            atk.nextAt = clock.current + atk.delay;
            return;
          }
          const blocked = Math.min(def.armor, atk.atk);
          const dmg = Math.max(1, atk.atk - def.armor);
          def.hp = Math.max(0, def.hp - dmg);
          def.hurtTick++;
          events.push({
            t: `🗡️ ${atk.ent.name} hits ${def.ent.name} for ${dmg}${blocked ? ` (${blocked} blocked by armor!)` : ''} → ${def.hp}/${def.maxHp} HP`,
            k: blocked ? 'block' : 'hit', snd: dmg >= 10 ? 'heavy' : 'hit', sndF: def,
          });
          if (atk.ent.id === 'bee' && !atk.stung && Math.random() < 0.5) {
            atk.stung = true; atk.hp = 0;
            events.push({ t: `🐝 ${atk.ent.name} died after its sting! (like real bees)`, k: 'die', snd: 'die', sndF: null });
          }
          // witch drinks healing once when hurt badly
          if (def.ent.id === 'witch' && !def.healed && def.hp > 0 && def.hp < def.maxHp * 0.4) {
            def.healed = true;
            def.hp = Math.min(def.maxHp, def.hp + 8);
            events.push({ t: `🧪 ${def.ent.name} chugs a healing potion! +8 HP → ${def.hp}/${def.maxHp}`, k: 'heal', snd: 'heal', sndF: null });
          }
          atk.nextAt = clock.current + atk.delay;
        };
        if (clock.current >= A.nextAt && A.hp > 0 && B.hp > 0) strike(A, B, 0);
        if (clock.current >= B.nextAt && B.hp > 0 && A.hp > 0) strike(B, A, 1);
        // sounds + logs (side effects outside setState ideally, but fine here at 100ms cadence)
        setTimeout(() => {
          events.forEach(e => {
            pushLog(e.t, e.k);
            if (e.snd === 'hit') playBattleHit(vol, false);
            else if (e.snd === 'heavy') playBattleHit(vol, true);
            else if (e.snd === 'dodge') playBattleDodge(vol);
            else if (e.snd === 'die') playBattleDie(vol);
            else if (e.snd === 'heal') playBattleHeal(vol);
          });
        }, 0);
        return [A, B];
      });
    }, 100);
    return () => window.clearInterval(timer.current);
  }, [phase, speed]); // eslint-disable-line

  // watch for end
  useEffect(() => {
    if (phase !== 'fight' || !fighters) return;
    const [A, B] = fighters;
    if (A.hp <= 0 || B.hp <= 0) {
      window.clearInterval(timer.current);
      const isDraw = A.hp <= 0 && B.hp <= 0;
      const w = isDraw ? 0 : A.hp > 0 ? 1 : 2;
      setDraw(isDraw); setWinner(w as 0 | 1 | 2);
      setPhase('over');
      const wName = isDraw ? 'DRAW' : (w === 1 ? A : B).ent.name;
      setTimeout(() => {
        pushLog(isDraw ? `🤝 DOUBLE KO! Both mobs fell. It's a draw!` : `🏆 ${(w === 1 ? A : B).ent.name} WINS with ${(w === 1 ? A : B).hp} HP left!`, 'info');
        playUI(isDraw ? 'reveal' : 'win', vol);
        // scoring: battles played + winner HP bonus
        const leftHp = isDraw ? 0 : (w === 1 ? A : B).hp;
        const pts = 120 + Math.min(300, leftHp * 4);
        const gained = 25;
        setScore(s => s + pts); setXp(x => x + gained); addXp(gained);
        setBattles(b => {
          const nb = b + 1;
          recordGame(gameId, score + pts, nb, nb);
          const s = getState();
          import('../lib/store').then(m => m.setState({ votes: s.votes + 1 }));
          return nb;
        });
        setRecord(`${gameId}-best-battle`, pts);
        checkAchievements({ game: gameId });
      }, 350);
    }
  }, [fighters, phase]); // eslint-disable-line

  useEffect(() => { logRef.current?.scrollTo({ top: 99999 }); }, [log.length]);
  useEffect(() => () => window.clearInterval(timer.current), []);

  const pick = (id: string) => {
    playUI('click', vol);
    if (picking === 1) { setIdA(id); setPicking(2); }
    else { setIdB(id); setPicking(null); }
  };

  const diff: Diff = 'Medium';

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={0} q={Math.max(1, battles + (phase === 'select' ? 0 : 1))} total={99} xp={xp} />
        <span className="mc-chip !bg-[#2e7ab8]">📊 FACTUAL STATS (WIKI HP/ATK)</span>
        <button onClick={() => setMuted(m => !m)} className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs">
          <Icon name={muted ? 'VolumeX' : 'Volume2'} size={14} /> {muted ? 'UNMUTE' : 'MUTE'}
        </button>
      </div>

      {phase === 'select' && (
        <div className="mc-panel space-y-3 p-4">
          <div className="text-center">
            <h2 className="font-pixel text-base text-[#ffd94f]">⚔️ MOB VS MOB ARENA</h2>
            <p className="mt-1 text-sm text-white/70">
              {picking === 1 ? '👆 Choose the 1ST mob (left corner):' : picking === 2 ? '👆 Now choose the 2ND mob (right corner):' : '✅ Both corners filled — review stats, then FIGHT!'}
            </p>
            {/* selected corners */}
            <div className="mx-auto mt-2 grid max-w-lg grid-cols-[1fr_auto_1fr] items-center gap-2">
              <CornerPick n={1} id={idA} active={picking === 1} onClick={() => setPicking(1)} />
              <span className="font-pixel text-xl text-[#ffd94f]">VS</span>
              <CornerPick n={2} id={idB} active={picking === 2} onClick={() => setPicking(2)} />
            </div>
          </div>
          {/* stat preview */}
          <div className="mx-auto grid max-w-lg grid-cols-2 gap-2 text-xs">
            {[idA, idB].map((id, i) => {
              const s = MOB_STATS[id]!;
              return (
                <div key={i} className="rounded-lg border border-white/10 bg-black/30 p-2 text-white/80">
                  <div className="font-bold text-white">{byId(id)!.name}</div>
                  <div>❤️ {s.hp} HP · 🗡️ {s.atk} dmg · ⏱ {s.delay}s</div>
                  <div>💨 {Math.round(s.dodge * 100)}% dodge · 🛡️ {s.armor} armor</div>
                </div>
              );
            })}
          </div>
          {/* mob picker grid — NOT auto-added; explicit 1st/2nd slot buttons */}
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-5">
            {mobs.map(m => {
              const sel = m.id === idA || m.id === idB;
              const slot = m.id === idA ? '1ST' : m.id === idB ? '2ND' : null;
              return (
                <button key={m.id} onClick={() => pick(m.id)}
                  className={`relative rounded-lg border-2 p-1.5 text-center transition-transform hover:scale-105 ${sel ? 'border-[#ffd94f] bg-[#3b2a55]' : 'border-black/60 bg-black/30'}`}>
                  {slot && <span className="absolute -top-2 left-1/2 -translate-x-1/2 rounded bg-[#ffd94f] px-1 text-[9px] font-black text-black">{slot}</span>}
                  <PixelSprite id={m.id} pal={m.pal} size={10} pixelSize={4} />
                  <div className="mt-0.5 truncate text-[10px] font-bold text-white">{m.name}</div>
                  <div className="text-[9px] text-white/50">{MOB_STATS[m.id]?.hp ?? '?'}❤ {(MOB_STATS[m.id]?.atk ?? '?')}🗡</div>
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            <button onClick={() => startFight()} disabled={idA === idB} className="mc-btn !bg-[#c93a2b] !px-8 !py-3">
              <Icon name="Swords" size={18} /> FIGHT!
            </button>
            <button onClick={() => { const a = mobs[Math.floor(Math.random() * mobs.length)]; let b = a; while (b.id === a.id) b = mobs[Math.floor(Math.random() * mobs.length)]; setIdA(a.id); setIdB(b.id); setPicking(null); }} className="mc-btn mc-btn-gray">
              <Icon name="Dices" size={16} /> RANDOM
            </button>
          </div>
        </div>
      )}

      {(phase === 'fight' || phase === 'over') && fighters && (
        <div className="space-y-3">
          <div className="mc-panel grid grid-cols-[1fr_auto_1fr] items-stretch gap-2 p-3 sm:p-4">
            <FighterCard f={fighters[0]} side="left" winner={winner === 1} over={phase === 'over'} />
            <div className="flex flex-col items-center justify-center gap-1">
              <span className="font-pixel text-xl text-[#ffd94f] sm:text-2xl">VS</span>
              <span className="mc-chip !text-[10px]">⏱ {clock.current.toFixed(1)}s</span>
              <div className="flex gap-1">
                {[1, 2, 4].map(s => (
                  <button key={s} onClick={() => setSpeed(s)} className={`mc-btn !px-1.5 !py-0.5 !text-[10px] ${speed === s ? '' : 'mc-btn-gray'}`}>{s}x</button>
                ))}
              </div>
            </div>
            <FighterCard f={fighters[1]} side="right" winner={winner === 2} over={phase === 'over'} />
          </div>

          {/* BATTLE LOG */}
          <div className="mc-panel p-3">
            <h3 className="mb-1 font-pixel text-xs text-[#ffd94f]">📜 BATTLE LOG — hits & defenses</h3>
            <div ref={logRef} className="h-44 space-y-0.5 overflow-y-auto rounded border border-white/10 bg-black/40 p-2 text-xs sm:h-52">
              {log.length === 0 && <div className="text-white/40">The battle begins…</div>}
              {log.map(l => (
                <div key={l.n} className={
                  l.kind === 'hit' ? 'text-white/90' : l.kind === 'boom' ? 'font-bold text-orange-400' :
                  l.kind === 'dodge' ? 'text-sky-300' : l.kind === 'block' ? 'text-[#ffd94f]' :
                  l.kind === 'heal' ? 'text-green-300' : l.kind === 'die' ? 'text-red-400' : 'font-bold text-[#ffd94f]'
                }>#{l.n} {l.text}</div>
              ))}
            </div>
          </div>

          {phase === 'over' && (
            <div className="mc-panel space-y-2 p-4 text-center">
              <div className="font-pixel text-lg text-[#ffd94f]">
                {draw ? '🤝 DOUBLE KO — DRAW!' : `🏆 ${(winner === 1 ? fighters[0] : fighters[1]).ent.name} WINS!`}
              </div>
              <div className="flex flex-wrap justify-center gap-2">
                <button onClick={() => startFight()} className="mc-btn"><Icon name="RotateCcw" size={16} /> REMATCH ({SUFFIX[battles % SUFFIX.length]})</button>
                <button onClick={() => { setPhase('select'); setPicking(1); }} className="mc-btn mc-btn-blue"><Icon name="Swords" size={16} /> CHANGE MOBS</button>
                <button onClick={() => window.history.back()} className="mc-btn mc-btn-gray">BACK</button>
              </div>
            </div>
          )}
        </div>
      )}

      <p className="text-center text-[11px] text-white/40">
        HP & attack = Normal-difficulty values from the Minecraft Wiki · Dodge / armor / attack delay tuned for arena pace · Creeper explodes once (kamikaze) · Bee may die stinging · Witch heals once
      </p>
    </div>
  );
}

function CornerPick({ n, id, active, onClick }: { n: number; id: string; active: boolean; onClick: () => void }) {
  const e = byId(id)!;
  const s = MOB_STATS[id]!;
  return (
    <button onClick={onClick} className={`rounded-lg border-2 p-2 ${active ? 'border-[#ffd94f] bg-[#3b2a55]' : 'border-black/60 bg-black/30'}`}>
      <div className="text-[10px] font-black text-[#ffd94f]">{n === 1 ? '1ST MOB' : '2ND MOB'}</div>
      <PixelSprite id={e.id} pal={e.pal} size={12} pixelSize={4} />
      <div className="text-xs font-bold text-white">{e.name}</div>
      <div className="text-[10px] text-white/55">{s.hp} HP · {s.atk} ATK · {s.delay}s</div>
    </button>
  );
}

function FighterCard({ f, side, winner, over }: { f: Fighter; side: 'left' | 'right'; winner: boolean; over: boolean }) {
  const pct = Math.max(0, (f.hp / f.maxHp) * 100);
  const dead = f.hp <= 0;
  return (
    <div className={`rounded-lg border-2 p-2 text-center sm:p-3 ${winner && over ? 'border-[#ffd94f] bg-[#ffd94f]/10' : 'border-black/60 bg-black/30'} ${dead ? 'opacity-70' : ''}`}>
      {winner && over && <div className="text-lg">👑</div>}
      <div key={f.hurtTick} className={f.hurtTick > 0 && !dead ? 'animate-ping-once' : ''} style={side === 'right' ? { transform: 'scaleX(-1)' } : undefined}>
        <PixelSprite id={f.ent.id} pal={f.ent.pal} size={16} pixelSize={5} grayscale={dead} />
      </div>
      <div className="mt-1 text-sm font-black text-white sm:text-base">{dead ? `☠️ ${f.ent.name}` : f.ent.name}</div>
      <div className="mx-auto mt-1 h-3.5 max-w-[220px] overflow-hidden rounded border border-black/60 bg-black/60">
        <div className={`h-full transition-all ${pct > 50 ? 'bg-[#6abe30]' : pct > 25 ? 'bg-amber-400' : 'bg-red-500'}`} style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-0.5 text-[11px] font-bold text-white">❤️ {f.hp}/{f.maxHp} HP</div>
      <div className="mt-0.5 flex flex-wrap justify-center gap-1 text-[10px] text-white/60">
        <span className="mc-chip !text-[9px]">🗡️{f.atk}</span>
        <span className="mc-chip !text-[9px]">⏱{f.delay}s</span>
        <span className="mc-chip !text-[9px]">💨{Math.round(f.dodge * 100)}%</span>
        <span className="mc-chip !text-[9px]">🛡️{f.armor}</span>
      </div>
    </div>
  );
}

// Universal GUESS engine: powers all 18 guess games.
// Clue styles: full, crop, silhouette, recipe, use-clue, sound — by difficulty + mode.

import { useEffect, useMemo, useRef, useState } from 'react';
import { ENTITIES, byCat, matchAnswer, type Cat, type Entity } from '../data/entities';
import { DIFFS, HINTS, calcScore, xpForAnswer, type Diff } from '../lib/difficulty';
import { bumpCombo, recordAnswer, recordGame, discover, addXp, addMastery, setRecord, getState, usePlayer } from '../lib/store';
import { playEntitySound, describeSound, playUI } from '../lib/audio';
import { shuffle } from '../lib/store';
import PixelSprite from '../components/PixelSprite';
import Icon from '../components/Icon';
import { TimerBar, ScoreHUD, ResultCard, DifficultyPicker, ChoiceGrid, type ResultInfo } from '../components/GameUI';
import { checkAchievements, Toast } from '../components/Achievements';

interface Props { gameId: string; pool: string; mode?: string; rounds?: number; fixedDiff?: Diff; onFinish?: (score: number, correct: number, total: number) => void; }

type ClueStyle = 'full' | 'crop' | 'tiny' | 'silhouette' | 'grayscale' | 'rotated' | 'recipe' | 'use' | 'sound' | 'drops' | 'location';

const POOL_ALIASES: Record<string, Cat[]> = {
  block: ['block'], item: ['item', 'food'], tool: ['tool'], armor: ['armor'],
  mob: ['mob'], biome: ['biome'], structure: ['structure'], dimension: ['dimension'],
  enchant: ['enchant'], potion: ['potion'], update: ['update'], character: ['character'],
};

function clueStylesFor(diff: Diff, mode?: string): ClueStyle[] {
  if (mode === 'sound') return ['sound'];
  if (mode === 'recipe') return ['recipe'];
  if (mode === 'drops') return ['drops'];
  if (mode === 'location') return ['location'];
  if (mode === 'texture') {
    if (diff === 'Easy') return ['crop'];
    if (diff === 'Medium') return ['crop', 'grayscale'];
    if (diff === 'Hard') return ['tiny', 'grayscale', 'rotated'];
    return ['tiny', 'grayscale', 'rotated'];
  }
  if (mode === 'screenshot') return diff === 'Easy' ? ['full'] : diff === 'Medium' ? ['crop'] : ['tiny'];
  if (diff === 'Easy') return ['full'];
  if (diff === 'Medium') return ['full', 'crop', 'silhouette'];
  if (diff === 'Hard') return ['crop', 'silhouette', 'grayscale', 'use'];
  if (diff === 'Insane') return ['tiny', 'silhouette', 'use', 'rotated'];
  return ['tiny', 'use', 'sound'];
}

const RECIPE_LINES: Record<string, string> = {};
function recipeText(e: Entity): string {
  const rel = Object.entries(e.rel).map(([k, v]) => `${k}: ${v}`).join(' · ');
  return rel || e.clues[2];
}

export default function GuessEngine({ gameId, pool, mode, rounds = 8, fixedDiff, onFinish }: Props) {
  const player = usePlayer();
  const [diff, setDiff] = useState<Diff>(fixedDiff ?? 'Medium');
  const rule = DIFFS[diff];
  const poolCats = POOL_ALIASES[pool] ?? ['block'];
  const entities = useMemo(() => ENTITIES.filter(e => poolCats.includes(e.cat)), [pool]);

  const [round, setRound] = useState(0);
  const [order, setOrder] = useState<Entity[]>(() => shuffle(entities).slice(0, rounds));
  const [style, setStyle] = useState<ClueStyle>('full');
  const [choices, setChoices] = useState<Entity[]>([]);
  const [picked, setPicked] = useState<number | null>(null);
  const [typed, setTyped] = useState('');
  const [result, setResult] = useState<ResultInfo | null>(null);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [clueIdx, setClueIdx] = useState(0);
  const [hintsUsed, setHintsUsed] = useState<string[]>([]);
  const [removed, setRemoved] = useState<number[]>([]);
  const [revealBoost, setRevealBoost] = useState(0);
  const [finished, setFinished] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [replays, setReplays] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const startRef = useRef<number>(Date.now());
  const [qKey, setQKey] = useState(0);

  const cur = order[round % order.length];

  const startRound = (r: number, list: Entity[]) => {
    const styles = clueStylesFor(diff, mode);
    setStyle(styles[Math.floor(Math.random() * styles.length)]);
    const target = list[r % list.length];
    const distract = shuffle(list.filter(e => e.id !== target.id)).slice(0, rule.choices - 1);
    setChoices(shuffle([target, ...distract]));
    setPicked(null); setTyped(''); setResult(null);
    setClueIdx(rule.clueLevel >= 2 ? 2 : rule.clueLevel >= 1 ? 1 : 0);
    setHintsUsed([]); setRemoved([]); setRevealBoost(0); setReplays(0);
    startRef.current = Date.now(); setQKey(k => k + 1);
  };

  useEffect(() => { setOrder(shuffle(entities).slice(0, rounds)); setRound(0); setScore(0); setXp(0); setCorrectCount(0); setFinished(false); }, [diff, gameId]); // eslint-disable-line
  useEffect(() => { if (order.length) startRound(round, order); }, [round, order, diff]); // eslint-disable-line

  if (!cur || !order.length) return <div className="mc-panel p-6">Loading…</div>;
  const answerIdx = choices.findIndex(c => c.id === cur.id);

  const hintCostTotal = hintsUsed.reduce((s, id) => s + (HINTS.find(h => h.id === id)?.cost ?? 0), 0);

  const submit = (ok: boolean, pickedIdx: number | null) => {
    if (result) return;
    const elapsed = Date.now() - startRef.current;
    const combo = bumpCombo(ok);
    recordAnswer(ok, elapsed);
    const { points, breakdown } = calcScore({ correct: ok, diff, elapsedMs: elapsed, timeLimit: rule.time, combo: getState().currentCombo, hintsUsed: hintsUsed.length, hintCostTotal, clueIndex: clueIdx });
    const gainedXp = xpForAnswer(ok, elapsed ? diff : diff);
    if (ok) { setScore(s => s + points); setXp(x => x + gainedXp); addXp(gainedXp); setCorrectCount(c => c + 1); addMastery(pool, 1); }
    discover(cur.id);
    const newRecords: string[] = [];
    if (ok && setRecord(`${gameId}-best-round`, points)) newRecords.push(`${points} pts in one round`);
    setPicked(pickedIdx);
    setResult({ correct: ok, answerId: cur.id, fact: cur.fact, points, breakdown, xp: gainedXp, combo: getState().currentCombo, hintsUsed: hintsUsed.length, newRecords });
    const fresh = checkAchievements({ combo: getState().currentCombo, speedMs: elapsed, game: gameId, diff });
    if (fresh.length) setToast(fresh[0]);
  };

  const pickChoice = (i: number) => { playUI('click', player.sound && !muted ? player.volume : 0); submit(choices[i].id === cur.id, i); };
  const submitTyped = () => { if (!typed.trim() || result) return; submit(matchAnswer(typed, cur), null); };

  const useHint = (id: string) => {
    if (result || hintsUsed.includes(id)) return;
    const allowed = player.hardcore ? 0 : rule.hints;
    if (hintsUsed.length >= allowed) return;
    if (id === 'remove' && !rule.typed) {
      const wrong = choices.map((c, i) => (c.id !== cur.id ? i : -1)).filter(i => i >= 0 && !removed.includes(i));
      setRemoved(r => [...r, ...shuffle(wrong).slice(0, 2)]);
    }
    if (id === 'clue') setClueIdx(c => Math.min(2, c + 1));
    if (id === 'image') setRevealBoost(b => b + 0.35);
    setHintsUsed(h => [...h, id]);
  };

  const next = () => {
    if (round + 1 >= rounds) {
      const perfect = recordGame(gameId, score, correctCount, rounds);
      if (diff === 'Insane' && correctCount >= Math.ceil(rounds / 2)) { const s = getState(); import('../lib/store').then(m => m.setState({ insaneClears: s.insaneClears + 1 })); }
      if (diff === 'Nightmare' && correctCount >= Math.ceil(rounds / 2)) { const s = getState(); import('../lib/store').then(m => m.setState({ nightmareClears: s.nightmareClears + 1 })); }
      checkAchievements({ perfect, combo: getState().bestCombo, game: gameId, diff });
      setRecord(`${gameId}-best`, score);
      setFinished(true);
      onFinish?.(score, correctCount, rounds);
    } else setRound(r => r + 1);
  };
  const retry = () => startRound(round, order);

  const visBase = style === 'full' ? 1 : style === 'crop' ? 0.62 : style === 'tiny' ? 0.22 : 1;
  const visibility = Math.min(1, (style === 'full' ? 1 : visBase * (0.6 + rule.visibility)) + revealBoost);
  const showImage = !['recipe', 'use', 'sound', 'drops', 'location'].includes(style);

  if (finished) {
    return (
      <div className="mc-panel p-6 text-center">
        <div className="font-pixel text-xl text-[#ffd94f]">GAME COMPLETE!</div>
        <div className="mt-2 text-4xl font-black text-white">{score} <span className="text-base text-white/50">pts</span></div>
        <div className="mt-1 text-white/70">{correctCount}/{rounds} correct · +{xp} XP</div>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <button className="mc-btn" onClick={() => { setOrder(shuffle(entities).slice(0, rounds)); setRound(0); setScore(0); setXp(0); setCorrectCount(0); setFinished(false); }}>PLAY AGAIN</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  const vol = player.sound && !muted ? player.volume : 0;

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={player.currentCombo} q={round + 1} total={rounds} xp={xp} />
        {!fixedDiff && <DifficultyPicker value={diff} onChange={d => setDiff(d as Diff)} />}
      </div>
      <TimerBar total={rule.time} running={!result} onExpire={() => submit(false, null)} resetKey={qKey} />

      {!result ? (
        <div className="mc-panel space-y-3 p-4">
          <div className="text-center text-sm font-bold uppercase tracking-wide text-white/60">
            Round {round + 1} · {style === 'sound' ? 'Listen' : style === 'recipe' ? 'Recipe riddle' : style === 'use' ? 'Use clue' : style === 'drops' ? 'Whose loot?' : style === 'location' ? 'Where am I?' : 'What is this?'}
          </div>

          {/* Clue display */}
          {style === 'sound' && (
            <div className="mx-auto max-w-md rounded-lg border-2 border-black/60 bg-black/40 p-4 text-center">
              <button className="mc-btn mx-auto" onClick={() => { playEntitySound(cur.id, vol); setReplays(r => r + 1); }}>
                <Icon name="Volume2" size={18} /> PLAY SOUND ({replays} plays)
              </button>
              <div className="mt-2 flex items-center justify-center gap-2">
                <button className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs" onClick={() => setMuted(m => !m)}>
                  <Icon name={muted ? 'VolumeX' : 'Volume2'} size={14} /> {muted ? 'UNMUTE' : 'MUTE'}
                </button>
                <span className="text-xs text-white/50">Text alternative: “{describeSound(cur.id)}”</span>
              </div>
              <p className="mt-2 text-xs text-white/60">Backup clue: {cur.clues[clueIdx]} (sound is never the only way!)</p>
            </div>
          )}
          {style === 'recipe' && (
            <div className="mx-auto max-w-md rounded-lg border-2 border-black/60 bg-black/40 p-4 text-center text-sm text-white/85">
              <div className="font-bold text-[#ffd94f]">🔨 RECIPE RIDDLE</div>
              <p className="mt-1">{recipeText(cur)}</p>
              <p className="mt-1 text-white/60">Which item do these ingredients & uses describe?</p>
            </div>
          )}
          {style === 'use' && (
            <div className="mx-auto max-w-md rounded-lg border-2 border-black/60 bg-black/40 p-4 text-center text-sm text-white/85">
              <div className="font-bold text-[#ffd94f]">❓ USE CLUE</div>
              <p className="mt-1">“{cur.clues[0]}”</p>
              <p className="mt-1 text-white/60">Category: {cur.sub}</p>
            </div>
          )}
          {style === 'drops' && (
            <div className="mx-auto max-w-md rounded-lg border-2 border-black/60 bg-black/40 p-4 text-center text-sm text-white/85">
              <div className="font-bold text-[#ffd94f]">🎁 WHO DROPS THIS?</div>
              <p className="mt-1">{cur.rel['Drops'] ? `Drops: ${cur.rel['Drops']}` : cur.clues[1]}</p>
              <p className="mt-1 text-white/60">{cur.desc}</p>
            </div>
          )}
          {style === 'location' && (
            <div className="mx-auto max-w-md rounded-lg border-2 border-black/60 bg-black/40 p-4 text-center text-sm text-white/85">
              <div className="font-bold text-[#ffd94f]">📍 WHERE AM I?</div>
              <p className="mt-1">“{cur.clues[clueIdx]}”</p>
              <p className="mt-1 text-white/60">Version scope: {cur.ver}</p>
            </div>
          )}
          {showImage && (
            <div className="mx-auto w-fit rounded-lg border-2 border-black/60 bg-black/40 p-3">
              <PixelSprite id={cur.id} pal={cur.pal} size={16} pixelSize={style === 'tiny' ? 10 : 7}
                crop={visibility} silhouette={style === 'silhouette'}
                grayscale={style === 'grayscale'} rotate={style === 'rotated' ? 25 : 0} />
            </div>
          )}
          {showImage && clueIdx >= 1 && (
            <p className="text-center text-sm text-white/70">💬 “{cur.clues[clueIdx === 2 ? 2 : 1]}”</p>
          )}

          {/* Hints */}
          {!player.hardcore && (
            <div className="flex flex-wrap justify-center gap-1.5">
              {HINTS.map(h => {
                const used = hintsUsed.includes(h.id);
                const left = rule.hints - hintsUsed.length;
                return (
                  <button key={h.id} disabled={used || left <= 0 || !!result} onClick={() => useHint(h.id)}
                    title={`${h.desc} (−${h.cost} pts)`}
                    className={`mc-btn !px-2 !py-1 !text-[11px] ${used ? '!bg-[#2e7d32]' : 'mc-btn-gray'}`}>
                    <Icon name="Lightbulb" size={12} /> {h.name} −{h.cost}
                  </button>
                );
              })}
            </div>
          )}
          {hintsUsed.includes('category') && <p className="text-center text-xs text-[#ffd94f]">📂 Category: {cur.cat} / {cur.sub}</p>}
          {hintsUsed.includes('letter') && <p className="text-center text-xs text-[#ffd94f]">🔤 Starts with “{cur.name[0]}”</p>}
          {hintsUsed.includes('wiki') && <p className="text-center text-xs text-[#ffd94f]">📖 {cur.desc}</p>}
          {hintsUsed.includes('clue') && <p className="text-center text-xs text-[#ffd94f]">💬 Extra: “{cur.clues[2]}”</p>}

          {/* Answer input */}
          {rule.typed ? (
            <div className="mx-auto flex max-w-md gap-2">
              <input value={typed} onChange={e => setTyped(e.target.value)} autoFocus
                onKeyDown={e => e.key === 'Enter' && submitTyped()}
                placeholder="Type the name…" className="mc-input flex-1" />
              <button className="mc-btn" onClick={submitTyped}>GUESS</button>
            </div>
          ) : (
            <VisibleGuessChoices choices={choices} removed={removed} picked={picked} answerId={cur.id} onPick={pickChoice} disabled={!!result} />
          )}
          {removed.length > 0 && <p className="text-center text-[11px] text-white/40">Some wrong options were removed by hint.</p>}
        </div>
      ) : (
        <ResultCard r={result} gameId={gameId} onNext={next} onRetry={retry} isLast={round + 1 >= rounds} />
      )}
    </div>
  );
}

function VisibleGuessChoices({ choices, removed, picked, answerId, onPick, disabled }: {
  choices: Entity[]; removed: number[]; picked: number | null; answerId: string;
  onPick: (i: number) => void; disabled: boolean;
}) {
  const vis = choices.map((c, k) => ({ c, k })).filter(({ k }) => !removed.includes(k));
  const answerVis = vis.findIndex(({ c }) => c.id === answerId);
  const pickedVis = picked === null ? null : vis.findIndex(({ k }) => k === picked);
  return (
    <ChoiceGrid choices={vis.map(v => v.c.name)} picked={pickedVis} answerIdx={answerVis}
      onPick={(i) => onPick(vis[i].k)} disabled={disabled} />
  );
}

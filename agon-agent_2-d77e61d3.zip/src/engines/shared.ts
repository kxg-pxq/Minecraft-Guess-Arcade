// Shared re-exports to avoid circular imports in engines.
export { ENTITIES, byId, byCat } from '../data/entities';
export const TRIVIA_Q = true;

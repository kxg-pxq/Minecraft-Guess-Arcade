// FUN CHALLENGES engine: survival/draft/oneitem/resource/crafting/racer/mobvote/predict/impossible/build/escape/rush.

import { useEffect, useMemo, useRef, useState } from 'react';
import { ENTITIES, byId, byCat } from '../data/entities';
import { DIFFS } from '../lib/difficulty';
import type { Diff } from '../lib/difficulty';
import { recordGame, addXp, setRecord, getState, usePlayer, shuffle, seeded } from '../lib/store';
import { playUI } from '../lib/audio';
import PixelSprite from '../components/PixelSprite';
import Icon from '../components/Icon';
import { ScoreHUD, DifficultyPicker, TimerBar } from '../components/GameUI';
import { checkAchievements, Toast } from '../components/Achievements';
import MobBattle from './MobBattle';

interface Props { gameId: string; mode: string; fixedDiff?: Diff; rounds?: number; onFinish?: (s: number, c: number, t: number) => void; }

interface Scenario { title: string; story: string; options: { label: string; sub?: string; correct?: boolean; votes?: number; entityId?: string }[]; explain: string; factual: boolean; }

function scenarioPools(mode: string): Scenario[] {
  const E = (id: string) => byId(id)!;
  const pick = (n: number, cat?: string) => shuffle(ENTITIES.filter(e => !cat || e.cat === cat)).slice(0, n);
  switch (mode) {
    case 'survival': case 'escape': return [
      { title: 'Night One Panic', story: 'The sun is setting, you have 3 dirt and a dream. What saves you?', options: [{ label: 'Dig into a hillside', correct: true }, { label: 'Fight everything' }, { label: 'Swim in circles' }, { label: 'Stare at Endermen' }], explain: 'A dirt hole keeps you safe on night one. Classic!', factual: false },
      { title: 'Creeper in the doorway!', story: 'You hear the dreaded hiss behind you. React!', options: [{ label: 'Shield up & back away', correct: true }, { label: 'Hug it' }, { label: 'Punch it closer' }, { label: 'Offer it a flower' }], explain: 'Shields block the blast. Distance saves diamonds.', factual: true },
      { title: 'Out of food!', story: 'Half a heart of hunger. The sun is up. Best move?', options: [{ label: 'Kelp speedrun diet' }, { label: 'Hunt & cook meat', correct: true }, { label: 'Eat rotten flesh feast' }, { label: 'Starve stylishly' }], explain: 'Cooked meat restores the most hunger safely.', factual: true },
      { title: 'Lost in a cave', story: 'Torches gone. You hear spiders. Move?', options: [{ label: 'Block in & dig up safely', correct: true }, { label: 'Sprint into the dark' }, { label: 'Dig straight down' }, { label: 'Log out forever' }], explain: 'Never dig straight down — or sprint blind. Fort up!', factual: false },
      { title: 'Lava lake crossing', story: 'Fortress is across the lava. No bridge blocks?!', options: [{ label: 'Ender pearl Yeet', correct: true }, { label: 'Swim in style' }, { label: 'Cry (valid)' }, { label: 'Boat over lava' }], explain: 'Pearls teleport across. Boats burn. Lava hurts.', factual: true },
      { title: 'Phantom ambush', story: 'Three nights no sleep. The sky screeches.', options: [{ label: 'Sleep immediately', correct: true }, { label: 'Befriend them' }, { label: 'Hide under 1 block (smart!)', correct: true }, { label: 'Ignore the screaming' }], explain: 'Sleep resets the timer; 1-block cover also foils swoops.', factual: true },
    ];
    case 'draft': case 'oneitem': case 'resource': {
      const quest = mode === 'draft' ? 'Draft 5 items for: DEFEAT THE ENDER DRAGON' : mode === 'oneitem' ? 'ONE item for the whole Nether trip:' : 'Spend 10 diamonds FIRST on:';
      const good = ['diamond_pickaxe', 'bow', 'bucket', 'ender_pearl', 'shield', 'golden_apple', 'torch', 'ender_pearl'];
      const bad = ['cookie', 'string', 'book', 'stick'];
      return [{
        title: quest, story: 'Tap items to draft. Choose the strongest kit!', factual: false, explain: 'Utility + damage + mobility wins every quest.',
        options: shuffle([...good.slice(0, 6), ...bad.slice(0, 2)]).map(id => ({ label: E(id).name, entityId: id, correct: good.includes(id) })),
      }];
    }
    case 'crafting': case 'racer': return [
      { title: 'Craft a Shield', story: 'Which ingredients make a shield?', options: [{ label: '6 planks + 1 iron', correct: true }, { label: '8 cobblestone' }, { label: '3 iron + 2 sticks' }, { label: '5 wool + 3 string' }], explain: 'Shields need 6 planks and 1 iron ingot.', factual: true },
      { title: 'Craft a Bucket', story: 'Bucket recipe?', options: [{ label: '3 iron ingots (V shape)', correct: true }, { label: '5 iron blocks' }, { label: '8 planks' }, { label: '1 iron + 1 stick' }], explain: 'Three ingots in a V.', factual: true },
      { title: 'Craft TNT', story: 'Boom recipe?', options: [{ label: '5 gunpowder + 4 sand', correct: true }, { label: '9 redstone' }, { label: '4 coal + 5 gravel' }, { label: '8 flint' }], explain: 'Gunpowder X with sand corners.', factual: true },
      { title: 'Craft a Compass', story: 'Pointy recipe?', options: [{ label: '4 iron + 1 redstone', correct: true }, { label: '8 gold' }, { label: '1 diamond + sticks' }, { label: '9 lapis' }], explain: 'Iron ring around redstone.', factual: true },
      { title: 'Craft a Cake', story: 'Tasty recipe?', options: [{ label: '3 milk + 2 sugar + egg + 3 wheat', correct: true }, { label: '9 cookies' }, { label: '5 apples + honey' }, { label: '1 pumpkin + eggs' }], explain: 'The classic layered recipe.', factual: true },
      { title: 'Craft an Anvil', story: 'Heavy recipe?', options: [{ label: '3 iron blocks + 4 ingots', correct: true }, { label: '9 iron ingots' }, { label: '5 obsidian' }, { label: '8 stone' }], explain: 'Blocks on top, ingots below.', factual: true },
    ];
    case 'predict': case 'impossible': case 'build': {
      const mobs = pick(8, 'mob');
      const pairs: Scenario[] = [];
      for (let i = 0; i < mobs.length; i += 2) {
        const a = mobs[i], b = mobs[i + 1] ?? mobs[0];
        const rand = seeded(a.id + b.id)();
        pairs.push({
          title: mode === 'impossible' ? 'IMPOSSIBLE CHOICE' : mode === 'build' ? 'BUILD DECISION — cutest base defender?' : 'MOB VS MOB — who wins?',
          story: mode === 'impossible'
            ? `You may only keep ONE in your world forever. The other is deleted from the game.`
            : mode === 'build' ? `Judge ONLY by the criterion. No other stats matter!` : `A ${a.name} meets a ${b.name} in the arena…`,
          factual: mode === 'predict',
          explain: mode === 'predict' ? `Stat check: ${a.attrs[0]?.[1] ?? '?'} vs ${b.attrs[0]?.[1] ?? '?'} — but arena chaos decides!` : `The crowd has spoken. ${Math.round(rand * 40 + 30)}% backed ${a.name}!`,
          options: [
            { label: a.name, entityId: a.id, votes: Math.round(rand * 100) },
            { label: b.name, entityId: b.id, votes: Math.round((1 - rand) * 100) },
          ],
        });
      }
      return pairs;
    }
    case 'rush': return [
      { title: 'Loot room!', story: 'Grab the GOOD stuff only. Leave junk!', factual: true, explain: 'Diamonds > dirt. Always.',
        options: [{ label: 'Diamond', correct: true }, { label: 'Dirt' }, { label: 'Nether Star', correct: true }, { label: 'Stick' }, { label: 'Golden Apple', correct: true }, { label: 'Cobblestone' }] },
    ];
    default: return [];
  }
}

export default function FunEngine({ gameId, mode, fixedDiff, rounds = 6, onFinish }: Props) {
  const player = usePlayer();
  const [diff, setDiff] = useState<Diff>(fixedDiff ?? 'Medium');
  const rule = DIFFS[diff];
  const pool = useMemo(() => scenarioPools(mode), [mode]);
  const [order] = useState(() => shuffle(pool).slice(0, mode === 'rush' ? 1 : rounds));
  const [round, setRound] = useState(0);
  const [picked, setPicked] = useState<number[]>([]);
  const [reveal, setReveal] = useState(false);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [qKey, setQKey] = useState(0);
  const [rushHits, setRushHits] = useState(0);
  const startRef = useRef(Date.now());
  const vol = player.sound ? player.volume : 0;

  const cur = order[round % Math.max(1, order.length)];
  const multi = ['draft', 'oneitem', 'resource', 'rush'].includes(mode);
  const maxPicks = mode === 'draft' ? 5 : mode === 'oneitem' ? 1 : mode === 'resource' ? 1 : 99;

  useEffect(() => { setPicked([]); setReveal(false); setQKey(k => k + 1); startRef.current = Date.now(); }, [round]);

  // Shuffle ALL option positions every round so the correct answer can land
  // in any slot (A/B/C/D) instead of fixed data order. Grading uses the
  // shuffled copy via each option's `correct` flag, never its position.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const options = useMemo(() => shuffle(cur?.options ?? []), [round, cur]);

  if (!cur) return <div className="mc-panel p-6">Loading challenge…</div>;

  // Mob vs Mob is a full battle simulator (own engine) — placed after hooks.
  if (mode === 'mobvote') return <MobBattle gameId={gameId} />;

  const confirm = () => {
    if (reveal || !picked.length) return;
    const elapsed = Date.now() - startRef.current;
    let ok: boolean;
    if (cur.factual || ['survival', 'escape', 'crafting', 'racer', 'rush'].includes(mode)) {
      const correctIdx = options.map((o, i) => (o.correct ? i : -1)).filter(i => i >= 0);
      ok = picked.length === correctIdx.length && picked.every(p => correctIdx.includes(p)) ||
        (mode !== 'rush' && picked.some(p => options[p]?.correct));
      if (mode === 'rush') ok = picked.some(p => options[p]?.correct);
    } else {
      ok = true; // subjective votes always "score" — it's about participation
      const s = getState(); import('../lib/store').then(m => m.setState({ votes: s.votes + 1 }));
    }
    const pts = ok ? Math.round((100 + Math.max(0, 60 - elapsed / 300)) * rule.mult) : 0;
    const gained = ok ? Math.round(10 * rule.mult) : 2;
    if (ok) { setScore(s => s + pts); setXp(x => x + gained); addXp(gained); setCorrectCount(c => c + 1); }
    playUI(ok ? 'correct' : 'wrong', vol);
    setReveal(true);
    const fresh = checkAchievements({ combo: getState().currentCombo, speedMs: elapsed, game: gameId });
    if (fresh.length) setToast(fresh[0]);
  };

  const tap = (i: number) => {
    if (reveal) return;
    playUI('click', vol);
    if (!multi) { setPicked([i]); return; }
    setPicked(p => p.includes(i) ? p.filter(x => x !== i) : p.length >= maxPicks ? p : [...p, i]);
    if (mode === 'rush' && options[i]?.correct) setRushHits(h => h + 1);
  };

  const next = () => {
    if (round + 1 >= order.length) {
      const perfect = recordGame(gameId, score, correctCount, order.length);
      setRecord(`${gameId}-best`, score);
      checkAchievements({ perfect, combo: getState().bestCombo, game: gameId });
      setFinished(true); onFinish?.(score, correctCount, order.length);
    } else setRound(r => r + 1);
  };

  if (finished) {
    return (
      <div className="mc-panel p-6 text-center">
        <div className="font-pixel text-xl text-[#ffd94f]">CHALLENGE COMPLETE!</div>
        <div className="mt-2 text-4xl font-black text-white">{score} <span className="text-base text-white/50">pts</span></div>
        <div className="mt-1 text-white/70">{correctCount}/{order.length} · +{xp} XP</div>
        <div className="mt-4 flex justify-center gap-2">
          <button className="mc-btn" onClick={() => window.location.reload()}>PLAY AGAIN</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={player.currentCombo} q={round + 1} total={order.length} xp={xp} />
        {!fixedDiff && <DifficultyPicker value={diff} onChange={d => setDiff(d as Diff)} />}
      </div>
      <TimerBar total={mode === 'rush' ? 45 : rule.time} running={!reveal} onExpire={() => { if (!picked.length) setPicked([0]); confirm(); }} resetKey={qKey} />
      <div className="mc-panel space-y-3 p-4">
        <div className="text-center">
          <span className={`mc-chip ${cur.factual ? '!bg-[#2e7ab8]' : '!bg-[#7a4fb0]'}`}>{cur.factual ? '📊 FACTUAL' : '💜 SUBJECTIVE VOTE'}</span>
          <h2 className="mt-1 font-pixel text-base text-[#ffd94f]">{cur.title}</h2>
          <p className="mx-auto mt-1 max-w-lg text-sm text-white/80">{cur.story}</p>
          {multi && <p className="mt-1 text-xs text-white/50">Pick {maxPicks === 99 ? 'all the good ones' : `${maxPicks}`} ({picked.length} selected)</p>}
        </div>
        <div className={`grid gap-2 ${options.length > 4 ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}>
          {options.map((o, i) => {
            const sel = picked.includes(i);
            const e = o.entityId ? byId(o.entityId) : undefined;
            let cls = 'mc-choice !items-center text-center';
            if (reveal && o.correct) cls += ' !border-[#6abe30] !bg-[#2e7d32]';
            else if (reveal && sel && !o.correct && cur.factual) cls += ' !border-red-500 !bg-[#7d2a2a]';
            else if (sel) cls += ' !border-[#ffd94f] !bg-[#3b2a55]';
            return (
              <button key={i} onClick={() => tap(i)} disabled={reveal} className={cls}>
                {e && <PixelSprite id={e.id} pal={e.pal} size={10} pixelSize={4} />}
                <div className="font-bold">{o.label}</div>
                {o.sub && <div className="text-xs opacity-70">{o.sub}</div>}
                {reveal && !cur.factual && o.votes !== undefined && (
                  <div className="mt-1 h-2 w-full overflow-hidden rounded bg-black/40">
                    <div className="h-full bg-[#7a4fb0]" style={{ width: `${o.votes}%` }} />
                  </div>
                )}
                {reveal && !cur.factual && o.votes !== undefined && <div className="text-xs text-white/60">{o.votes}% of players</div>}
              </button>
            );
          })}
        </div>
        {!reveal ? (
          <button className="mc-btn mx-auto" disabled={!picked.length} onClick={confirm}>CONFIRM {multi && picked.length > 0 && `(${picked.length})`}</button>
        ) : (
          <div className="rounded-lg border-2 border-black/60 bg-black/30 p-3 text-center">
            <p className="text-sm text-white/85">💡 {cur.explain}</p>
            <button className="mc-btn mx-auto mt-2" onClick={next} autoFocus>{round + 1 >= order.length ? 'FINISH' : 'NEXT'} <Icon name="ChevronRight" size={16} /></button>
          </div>
        )}
      </div>
    </div>
  );
}

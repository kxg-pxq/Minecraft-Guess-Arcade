// ARCADE MODES engine: endless/survival/speedrun/perfect/sudden/marathon/random/master/daily/weekly/boss.
// Mixed-question gauntlets with lives, clocks, and fixed competitive rules.

import { useEffect, useMemo, useRef, useState } from 'react';
import { ENTITIES, TRIVIA_Q } from './shared';
import { TRIVIA } from '../data/trivia';
import { DIFFS } from '../lib/difficulty';
import type { Diff } from '../lib/difficulty';
import { bumpCombo, recordAnswer, recordGame, addXp, setRecord, getState, usePlayer, shuffle, seeded, todayKey, weekKey, touchDaily } from '../lib/store';
import { playUI } from '../lib/audio';
import PixelSprite from '../components/PixelSprite';
import Icon from '../components/Icon';
import { ScoreHUD, TimerBar, ChoiceGrid } from '../components/GameUI';
import { checkAchievements, Toast } from '../components/Achievements';

interface Props { gameId: string; mode: string; onFinish?: (s: number, c: number, t: number) => void; }
interface Q { kind: 'entity' | 'trivia'; prompt: string; sub?: string; choices: string[]; answer: number; entityId?: string; fact: string; }

function buildEntityQ(diff: Diff, rand: () => number, cat?: string): Q {
  const pool = cat && cat !== 'mixed' ? ENTITIES.filter(e => e.cat === cat) : ENTITIES;
  const target = pool[Math.floor(rand() * pool.length)];
  const distract = shuffle(pool.filter(e => e.id !== target.id), rand).slice(0, DIFFS[diff].choices - 1);
  const choices = shuffle([target, ...distract], rand);
  const styles = diff === 'Easy' ? ['full'] : diff === 'Medium' ? ['full', 'crop'] : ['crop', 'tiny'];
  const st = styles[Math.floor(rand() * styles.length)];
  return {
    kind: 'entity', prompt: 'What is this?', sub: `clue:${st}`,
    choices: choices.map(c => c.name), answer: choices.findIndex(c => c.id === target.id),
    entityId: target.id, fact: target.fact,
  };
}
function buildTriviaQ(diff: Diff, rand: () => number): Q {
  const pool = TRIVIA.filter(q => q.t !== 'tf' || diff !== 'Easy');
  const q = pool[Math.floor(rand() * pool.length)];
  // Shuffle ALL answer positions so the correct answer lands randomly
  // (A/B/C/D or TRUE/FALSE order) instead of fixed data order.
  if (q.t === 'tf') {
    const opts = shuffle([0, 1], rand); // 0=TRUE, 1=FALSE
    return { kind: 'trivia', prompt: q.q, choices: opts.map(v => (v === 0 ? 'TRUE' : 'FALSE')), answer: opts.findIndex(v => v === (q.a === 1 ? 0 : 1)), fact: q.e };
  }
  const ord = shuffle((q.c ?? []).map((_, i) => i), rand);
  return { kind: 'trivia', prompt: q.q, choices: ord.map(i => q.c![i]), answer: ord.findIndex(i => i === Number(q.a)), fact: q.e };
}

const MODE_CFG: Record<string, { diff: Diff; lives: number; count: number; time: number; total?: number; competitive?: boolean }> = {
  endless: { diff: 'Medium', lives: 1, count: 999, time: 20 },
  survival: { diff: 'Medium', lives: 3, count: 999, time: 20 },
  speedrun: { diff: 'Easy', lives: 999, count: 15, time: 999, total: 180 },
  perfect: { diff: 'Hard', lives: 1, count: 10, time: 15 },
  sudden: { diff: 'Insane', lives: 1, count: 999, time: 12 },
  marathon: { diff: 'Medium', lives: 999, count: 25, time: 25 },
  random: { diff: 'Medium', lives: 999, count: 10, time: 20 },
  master: { diff: 'Hard', lives: 999, count: 12, time: 18 },
  daily: { diff: 'Medium', lives: 999, count: 5, time: 20, competitive: true },
  weekly: { diff: 'Hard', lives: 999, count: 10, time: 18, competitive: true },
  boss: { diff: 'Nightmare', lives: 3, count: 5, time: 10 },
};

export default function ArcadeEngine({ gameId, mode, onFinish }: Props) {
  const player = usePlayer();
  const cfg = MODE_CFG[mode] ?? MODE_CFG.endless;
  const [qs, setQs] = useState<Q[]>([]);
  const [round, setRound] = useState(0);
  const [lives, setLives] = useState(cfg.lives);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const [picked, setPicked] = useState<number | null>(null);
  const [reveal, setReveal] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [totalLeft, setTotalLeft] = useState(cfg.total ?? 0);
  const [qKey, setQKey] = useState(0);
  const [masterCat] = useState(() => shuffle(['block', 'mob', 'item', 'biome', 'enchant', 'tool'])[0]);
  const startRef = useRef(Date.now());
  const vol = player.sound ? player.volume : 0;

  useEffect(() => {
    const rand = mode === 'daily' ? seeded('daily-' + todayKey()) : mode === 'weekly' ? seeded('weekly-' + weekKey()) : Math.random;
    const list: Q[] = [];
    for (let i = 0; i < Math.min(cfg.count, 60); i++) {
      if (mode === 'master') list.push(buildEntityQ(cfg.diff, rand, masterCat));
      else if (mode === 'daily') {
        // fixed 5-pack: block, mob, visual-ish, trivia, letter-style(entity)
        const cats = ['block', 'mob', 'block', 'mixed', 'item'];
        if (i === 3) list.push(buildTriviaQ(cfg.diff, rand));
        else list.push(buildEntityQ(cfg.diff, rand, cats[i]));
      }
      else list.push(rand() < 0.6 ? buildEntityQ(cfg.diff, rand) : buildTriviaQ(cfg.diff, rand));
    }
    setQs(list);
  }, [mode]); // eslint-disable-line

  useEffect(() => { setPicked(null); setReveal(false); startRef.current = Date.now(); setQKey(k => k + 1); }, [round]);
  useEffect(() => {
    if (!cfg.total || finished) return;
    if (totalLeft <= 0) { finish(); return; }
    const t = setTimeout(() => setTotalLeft(l => l - 1), 1000);
    return () => clearTimeout(t);
  }, [totalLeft, finished]); // eslint-disable-line

  const q = qs[round];
  if (!q) return <div className="mc-panel p-6">Loading arcade…</div>;

  const submit = (idx: number | null) => {
    if (reveal || finished) return;
    const ok = idx === q.answer;
    const elapsed = Date.now() - startRef.current;
    bumpCombo(ok); recordAnswer(ok, elapsed);
    const combo = getState().currentCombo;
    const pts = ok ? Math.round((100 * DIFFS[cfg.diff].mult + Math.max(0, 60 - elapsed / 300)) + Math.min(combo, 15) * 5) : 0;
    const gained = ok ? Math.round(10 * DIFFS[cfg.diff].mult) : 2;
    if (ok) { setScore(s => s + pts); setXp(x => x + gained); addXp(gained); setCorrectCount(c => c + 1); }
    else {
      const nl = lives - 1;
      setLives(nl);
      if (nl <= 0 && (mode === 'endless' || mode === 'survival' || mode === 'perfect' || mode === 'sudden' || mode === 'boss')) {
        setPicked(idx); setReveal(true);
        setTimeout(() => finish(), 1600);
        return;
      }
    }
    playUI(ok ? 'correct' : 'wrong', vol);
    setPicked(idx); setReveal(true);
    const fresh = checkAchievements({ combo: getState().currentCombo, speedMs: elapsed, game: gameId, diff: cfg.diff });
    if (fresh.length) setToast(fresh[0]);
  };

  const finish = () => {
    const total = Math.max(1, reveal ? round + 1 : round);
    const s = getState();
    if (mode === 'endless') import('../lib/store').then(m => m.setState({ bestEndless: Math.max(s.bestEndless, correctCount) }));
    if (mode === 'survival') {
      import('../lib/store').then(m => m.setState({
        survivalWins: s.survivalWins + (lives > 0 && reveal ? 1 : 0),
        comebackWins: s.comebackWins + (lives === 1 ? 1 : 0),
      }));
    }
    if (mode === 'boss' && correctCount >= 3) import('../lib/store').then(m => m.setState({ bossClears: s.bossClears + 1 }));
    if (mode === 'daily') {
      touchDaily(todayKey());
      import('../lib/store').then(m => m.setState({ bestDaily: Math.max(getState().bestDaily, score) }));
      submitScore('daily', score, todayKey());
    }
    if (mode === 'weekly') {
      import('../lib/store').then(m => m.setState({ bestWeekly: Math.max(getState().bestWeekly, score) }));
      submitScore('weekly', score, weekKey());
    }
    if (!cfg.competitive) submitScore('alltime', score, gameId);
    const perfect = recordGame(gameId, score, correctCount, total);
    checkAchievements({ perfect, combo: getState().bestCombo, game: gameId, diff: cfg.diff });
    setRecord(`${gameId}-best`, score);
    setFinished(true);
    onFinish?.(score, correctCount, total);
  };

  const next = () => {
    if (mode !== 'endless' && mode !== 'survival' && mode !== 'sudden' && round + 1 >= cfg.count) finish();
    else setRound(r => r + 1);
  };

  if (finished) {
    return (
      <div className="mc-panel p-6 text-center">
        <div className="font-pixel text-xl text-[#ffd94f]">{modeLabel(mode)} COMPLETE!</div>
        <div className="mt-2 text-4xl font-black text-white">{score} <span className="text-base text-white/50">pts</span></div>
        <div className="mt-1 text-white/70">{correctCount} correct · +{xp} XP · {lives < 900 ? `${lives} lives left` : ''}</div>
        {cfg.competitive && <div className="mt-1 text-xs text-[#6abe30]">✓ Score submitted to the {mode} leaderboard (fixed rules, validated).</div>}
        <div className="mt-4 flex justify-center gap-2">
          <button className="mc-btn" onClick={() => window.location.reload()}>PLAY AGAIN</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  const ent = q.entityId ? ENTITIES.find(e => e.id === q.entityId) : undefined;
  const clueStyle = q.sub?.startsWith('clue:') ? q.sub.slice(5) : 'full';
  const crop = clueStyle === 'full' ? 1 : clueStyle === 'crop' ? 0.55 : 0.22;

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={player.currentCombo} q={round + 1} total={cfg.count > 60 ? 99 : cfg.count} xp={xp} />
        <span className="mc-chip">{modeLabel(mode)} · {cfg.diff.toUpperCase()}</span>
        {cfg.lives < 900 && <span className="mc-chip !bg-red-500/80">{'❤'.repeat(Math.max(0, lives)) || '💀'}</span>}
        {cfg.total ? <span className="mc-chip !bg-red-500/80">⏱ {totalLeft}s total</span> : null}
      </div>
      {!cfg.total && <TimerBar total={cfg.time} running={!reveal} onExpire={() => submit(null)} resetKey={qKey} />}
      <div className="mc-panel space-y-3 p-4">
        <h2 className="text-center text-lg font-bold text-white">{q.prompt}</h2>
        {ent && (
          <div className="mx-auto w-fit rounded-lg border-2 border-black/60 bg-black/40 p-2">
            <PixelSprite id={ent.id} pal={ent.pal} size={16} pixelSize={6} crop={crop} />
          </div>
        )}
        {!reveal ? (
          <ChoiceGrid choices={q.choices} picked={picked} answerIdx={q.answer}
            onPick={i => { playUI('click', vol); submit(i); }} disabled={reveal} />
        ) : (
          <div className={`rounded-lg border-2 p-3 text-center ${picked === q.answer ? 'border-[#6abe30] bg-[#2e7d32]/30' : 'border-red-500 bg-[#7d2a2a]/30'}`}>
            <div className={`font-pixel text-sm ${picked === q.answer ? 'text-[#6abe30]' : 'text-red-400'}`}>
              {picked === q.answer ? '✓ CORRECT!' : `✗ ANSWER: ${q.choices[q.answer]}`}
            </div>
            <p className="mx-auto mt-1 max-w-md text-sm text-white/80">💡 {q.fact}</p>
            <button className="mc-btn mx-auto mt-2" onClick={next} autoFocus>NEXT <Icon name="ChevronRight" size={16} /></button>
          </div>
        )}
      </div>
    </div>
  );
}

function modeLabel(m: string) {
  return { endless: 'ENDLESS', survival: 'SURVIVAL', speedrun: 'SPEEDRUN', perfect: 'PERFECT RUN', sudden: 'SUDDEN DEATH', marathon: 'MARATHON', random: 'RANDOMIZER', master: 'CATEGORY MASTER', daily: 'DAILY PACK', weekly: 'WEEKLY CUP', boss: 'BOSS ROUND' }[m] ?? m.toUpperCase();
}

async function submitScore(board: string, score: number, scope: string) {
  try {
    const s = getState();
    if (!s.showOnBoards) return;
    await fetch('/api/scores', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ board, score, scope, name: s.name, avatar: s.avatar, title: s.activeTitle }),
    });
  } catch { /* offline — ignore */ }
}

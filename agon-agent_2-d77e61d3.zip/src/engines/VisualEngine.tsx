// VISUAL GAME LAB: 12 arcade mini-games.
// spot | zoom | silhouette | reveal | memory | hidden | broken | match | find | sequence | odd | color

import { useEffect, useMemo, useRef, useState } from 'react';
import { ENTITIES, byId } from '../data/entities';
import { DIFFS, type Diff } from '../lib/difficulty';
import { bumpCombo, recordAnswer, recordGame, addXp, setRecord, getState, usePlayer, shuffle } from '../lib/store';
import { playUI } from '../lib/audio';
import PixelSprite, { spriteGrid } from '../components/PixelSprite';
import Icon from '../components/Icon';
import { ScoreHUD, DifficultyPicker, TimerBar } from '../components/GameUI';
import { checkAchievements, Toast } from '../components/Achievements';

interface Props { gameId: string; mode: string; fixedDiff?: Diff; rounds?: number; onFinish?: (s: number, c: number, t: number) => void; }

export default function VisualEngine({ gameId, mode, fixedDiff, rounds = 6, onFinish }: Props) {
  const player = usePlayer();
  const [diff, setDiff] = useState<Diff>(fixedDiff ?? 'Medium');
  const rule = DIFFS[diff];
  const [round, setRound] = useState(0);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [stage, setStage] = useState(0); // round-internal progress
  const [reveal, setReveal] = useState(false);
  const [punish, setPunish] = useState(0);
  const [qKey, setQKey] = useState(0);
  const startRef = useRef(Date.now());
  const vol = player.sound ? player.volume : 0;

  const targets = useMemo(() => shuffle(ENTITIES).slice(0, rounds), [gameId]); // eslint-disable-line
  const cur = targets[round % targets.length];

  useEffect(() => { startRef.current = Date.now(); setReveal(false); setStage(0); setPunish(0); setQKey(k => k + 1); }, [round]);

  const grade = (ok: boolean, bonus = 0) => {
    const elapsed = Date.now() - startRef.current;
    bumpCombo(ok); recordAnswer(ok, elapsed);
    const pts = ok ? Math.round(90 * rule.mult + Math.max(0, 60 - elapsed / 400) + bonus - punish * 10) : 0;
    const gained = ok ? Math.round(10 * rule.mult) : 2;
    if (ok) { setScore(s => s + Math.max(10, pts)); setXp(x => x + gained); addXp(gained); setCorrectCount(c => c + 1); }
    playUI(ok ? 'correct' : 'wrong', vol);
    const fresh = checkAchievements({ combo: getState().currentCombo, speedMs: elapsed, game: gameId });
    if (fresh.length) setToast(fresh[0]);
    return ok;
  };

  const next = () => {
    if (round + 1 >= rounds) {
      const perfect = recordGame(gameId, score, correctCount, rounds);
      setRecord(`${gameId}-best`, score);
      checkAchievements({ perfect, combo: getState().bestCombo, game: gameId });
      setFinished(true); onFinish?.(score, correctCount, rounds);
    } else setRound(r => r + 1);
  };

  if (finished) {
    return (
      <div className="mc-panel p-6 text-center">
        <div className="font-pixel text-xl text-[#ffd94f]">VISUAL LAB CLEAR!</div>
        <div className="mt-2 text-4xl font-black text-white">{score} <span className="text-base text-white/50">pts</span></div>
        <div className="mt-1 text-white/70">{correctCount}/{rounds} correct · +{xp} XP</div>
        <div className="mt-4 flex justify-center gap-2">
          <button className="mc-btn" onClick={() => window.location.reload()}>PLAY AGAIN</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={player.currentCombo} q={round + 1} total={rounds} xp={xp} />
        {!fixedDiff && <DifficultyPicker value={diff} onChange={d => setDiff(d as Diff)} />}
      </div>
      <TimerBar total={rule.time} running={!reveal} onExpire={() => { grade(false); setReveal(true); }} resetKey={qKey} />
      <div className="mc-panel p-4">
        {mode === 'spot' && <SpotMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'zoom' && <ZoomMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'silhouette' && <SilhouetteMode key={round} cur={cur} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'reveal' && <RevealMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'memory' && <MemoryMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} stage={stage} setStage={setStage} />}
        {mode === 'hidden' && <HiddenMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'broken' && <BrokenMode key={round} cur={cur} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'match' && <MatchMode key={round} cur={cur} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'find' && <FindMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} stage={stage} setStage={setStage} />}
        {mode === 'sequence' && <SequenceMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} stage={stage} setStage={setStage} />}
        {mode === 'odd' && <OddMode key={round} cur={cur} reveal={reveal} setReveal={setReveal} grade={grade} />}
        {mode === 'color' && <ColorMode key={round} cur={cur} diff={diff} reveal={reveal} setReveal={setReveal} grade={grade} stage={stage} setStage={setStage} />}
        {reveal && (
          <button className="mc-btn mx-auto mt-4" onClick={next} autoFocus>{round + 1 >= rounds ? 'FINISH' : 'NEXT'} <Icon name="ChevronRight" size={16} /></button>
        )}
      </div>
    </div>
  );
}

type MG = { cur: (typeof ENTITIES)[number]; diff?: Diff; reveal: boolean; setReveal: (b: boolean) => void; grade: (ok: boolean, bonus?: number) => boolean; stage?: number; setStage?: (n: number) => void };

// ---- SPOT THE DIFFERENCE ----
function SpotMode({ cur, diff, reveal, setReveal, grade }: MG) {
  const n = diff === 'Easy' ? 3 : diff === 'Medium' ? 4 : 5;
  const [diffIdx] = useState(() => Math.floor(Math.random() * n * n));
  const [found, setFound] = useState(false);
  const grid = useMemo(() => spriteGrid(cur.id, n * 2), [cur.id]);
  const tap = (i: number) => {
    if (reveal) return;
    if (i === diffIdx) { setFound(true); grade(true); setReveal(true); } else grade(false);
  };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">Tap the tile that differs between the two scenes. Look closely…</p>
      <div className="mt-2 flex flex-wrap justify-center gap-4">
        {[0, 1].map(side => (
          <div key={side} className="grid gap-0.5 rounded border-2 border-black/60 bg-black/40 p-1" style={{ gridTemplateColumns: `repeat(${n}, 1fr)` }}>
            {Array.from({ length: n * n }).map((_, i) => {
              const changed = side === 1 && i === diffIdx;
              const isFound = reveal && i === diffIdx;
              return (
                <button key={i} onClick={() => tap(i)} disabled={reveal}
                  className={`h-10 w-10 sm:h-12 sm:w-12 ${isFound ? 'outline outline-4 outline-[#6abe30]' : ''}`}
                  style={{ background: changed ? cur.pal[3] : cur.pal[(grid[i % grid.length]?.[i % grid.length] ?? 0) % 4] }}>
                </button>
              );
            })}
          </div>
        ))}
      </div>
      {reveal && <p className="mt-2 text-sm font-bold text-white">{found ? '✓ Spotted!' : `✗ The odd tile is highlighted. It was ${cur.name}.`}</p>}
    </div>
  );
}

// ---- ZOOM IN ----
function ZoomMode({ cur, diff, reveal, setReveal, grade }: MG) {
  const [zoom, setZoom] = useState(diff === 'Easy' ? 3 : diff === 'Medium' ? 2 : 1.4);
  const [choices] = useState(() => shuffle([cur, ...shuffle(ENTITIES.filter(e => e.id !== cur.id)).slice(0, 3)]));
  useEffect(() => {
    if (reveal) return;
    const t = setInterval(() => setZoom(z => Math.max(0.8, z - 0.25)), 700);
    return () => clearInterval(t);
  }, [reveal]);
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">Zooming out… buzz in early for bonus points!</p>
      <div className="mx-auto mt-2 w-fit overflow-hidden rounded-lg border-2 border-black/60 bg-black/40 p-2">
        <div style={{ transform: `scale(${zoom})`, transformOrigin: 'center', width: 128, height: 128 }} className="grid place-items-center overflow-hidden">
          <PixelSprite id={cur.id} pal={cur.pal} size={16} pixelSize={8} />
        </div>
      </div>
      <div className="mx-auto mt-2 grid max-w-md grid-cols-2 gap-2">
        {choices.map(c => (
          <button key={c.id} disabled={reveal} onClick={() => { grade(c.id === cur.id, Math.round(zoom * 20)); setReveal(true); }} className="mc-choice !text-sm">{c.name}</button>
        ))}
      </div>
      {reveal && <p className="mt-2 text-sm font-bold text-white">It was {cur.name}!</p>}
    </div>
  );
}

// ---- SILHOUETTE ----
function SilhouetteMode({ cur, reveal, setReveal, grade }: MG) {
  const [choices] = useState(() => shuffle([cur, ...shuffle(ENTITIES.filter(e => e.cat === cur.cat && e.id !== cur.id)).slice(0, 3)]));
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">Name the shadow! ({cur.cat})</p>
      <div className="mx-auto mt-2 w-fit rounded-lg border-2 border-black/60 bg-gradient-to-b from-[#2a1c3d] to-black p-3">
        <PixelSprite id={cur.id} pal={cur.pal} size={16} pixelSize={7} silhouette />
      </div>
      <div className="mx-auto mt-2 grid max-w-md grid-cols-2 gap-2">
        {choices.map(c => (
          <button key={c.id} disabled={reveal} onClick={() => { grade(c.id === cur.id); setReveal(true); }} className="mc-choice !text-sm">{c.name}</button>
        ))}
      </div>
      {reveal && <div className="mt-2"><PixelSprite id={cur.id} pal={cur.pal} size={12} pixelSize={5} /><p className="text-sm font-bold text-white">{cur.name}</p></div>}
    </div>
  );
}

// ---- PIXEL REVEAL ----
function RevealMode({ cur, diff, reveal, setReveal, grade }: MG) {
  const total = diff === 'Easy' ? 9 : 16;
  const [shown, setShown] = useState(2);
  const [choices] = useState(() => shuffle([cur, ...shuffle(ENTITIES.filter(e => e.id !== cur.id)).slice(0, 3)]));
  useEffect(() => {
    if (reveal) return;
    const t = setInterval(() => setShown(s => Math.min(total, s + 1)), 800);
    return () => clearInterval(t);
  }, [reveal, total]);
  const order = useMemo(() => shuffle(Array.from({ length: total }).map((_, i) => i)), [cur.id]);
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">Tiles uncover over time — guess fast for more points!</p>
      <div className="mx-auto mt-2 grid w-fit gap-0.5 rounded border-2 border-black/60 bg-black/40 p-1" style={{ gridTemplateColumns: `repeat(${Math.sqrt(total)}, 1fr)` }}>
        {Array.from({ length: total }).map((_, i) => {
          const vis = order.indexOf(i) < shown;
          return <div key={i} className="h-12 w-12 sm:h-14 sm:w-14" style={{ background: vis ? cur.pal[i % 4] : '#0d0a16' }} />;
        })}
      </div>
      <div className="mx-auto mt-2 grid max-w-md grid-cols-2 gap-2">
        {choices.map(c => (
          <button key={c.id} disabled={reveal} onClick={() => { grade(c.id === cur.id, (total - shown) * 8); setReveal(true); }} className="mc-choice !text-sm">{c.name}</button>
        ))}
      </div>
      {reveal && <p className="mt-2 text-sm font-bold text-white">It was {cur.name}!</p>}
    </div>
  );
}

// ---- TEXTURE MEMORY ----
function MemoryMode({ diff, reveal, setReveal, grade, stage = 0, setStage }: MG) {
  const pairs = diff === 'Easy' ? 4 : diff === 'Medium' ? 6 : 8;
  const [deck] = useState(() => shuffle(shuffle(ENTITIES).slice(0, pairs).flatMap(e => [e, e])));
  const [open, setOpen] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const flip = (i: number) => {
    if (reveal || open.includes(i) || matched.includes(i) || open.length >= 2) return;
    const no = [...open, i];
    setOpen(no);
    if (no.length === 2) {
      setMoves(m => m + 1);
      setTimeout(() => {
        if (deck[no[0]].id === deck[no[1]].id) {
          const nm = [...matched, ...no];
          setMatched(nm);
          if (nm.length === deck.length) {
            const perfect = moves + 1 <= pairs + 1;
            if (perfect) { const s = getState(); import('../lib/store').then(m => m.setState({ memoryPerfect: s.memoryPerfect + 1 })); }
            grade(true, Math.max(0, (pairs * 3 - moves) * 10));
            setReveal(true);
          }
        }
        setOpen([]);
      }, 600);
    }
  };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">Match all {pairs} pairs! Moves: {moves}</p>
      <div className="mx-auto mt-2 grid w-fit gap-1.5" style={{ gridTemplateColumns: `repeat(4, 1fr)` }}>
        {deck.map((e, i) => {
          const face = open.includes(i) || matched.includes(i);
          return (
            <button key={i} onClick={() => flip(i)} disabled={reveal}
              className={`h-16 w-16 rounded border-2 sm:h-20 sm:w-20 ${matched.includes(i) ? 'border-[#6abe30]' : 'border-black/60'} bg-black/40`}>
              {face ? <PixelSprite id={e.id} pal={e.pal} size={10} pixelSize={5} style={{ width: '100%', height: '100%' }} /> : <span className="text-2xl">❓</span>}
            </button>
          );
        })}
      </div>
      {reveal && <p className="mt-2 font-bold text-[#6abe30]">✓ Cleared in {moves} moves!</p>}
    </div>
  );
}

// ---- HIDDEN MOB ----
function HiddenMode({ cur, diff, reveal, setReveal, grade }: MG) {
  const n = diff === 'Easy' ? 16 : diff === 'Medium' ? 25 : 36;
  const [hideIdx] = useState(() => Math.floor(Math.random() * n));
  const [decoys] = useState(() => shuffle(ENTITIES.filter(e => e.cat === 'block')).slice(0, 3));
  const tap = (i: number) => { if (!reveal) { grade(i === hideIdx); setReveal(true); } };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">One <b>{cur.name}</b> hides among the blocks. Tap it!</p>
      <div className="mx-auto mt-2 grid w-fit gap-0.5 rounded border-2 border-black/60 bg-black/40 p-1" style={{ gridTemplateColumns: `repeat(${Math.sqrt(n)}, 1fr)` }}>
        {Array.from({ length: n }).map((_, i) => (
          <button key={i} onClick={() => tap(i)} disabled={reveal}
            className={`h-12 w-12 sm:h-14 sm:w-14 ${reveal && i === hideIdx ? 'outline outline-4 outline-[#6abe30]' : ''}`}>
            {i === hideIdx
              ? <PixelSprite id={cur.id} pal={cur.pal} size={8} pixelSize={5} style={{ width: '100%', height: '100%' }} />
              : <PixelSprite id={decoys[i % decoys.length].id} pal={decoys[i % decoys.length].pal} size={8} pixelSize={5} style={{ width: '100%', height: '100%' }} />}
          </button>
        ))}
      </div>
      {reveal && <p className="mt-2 text-sm font-bold text-white">There it was!</p>}
    </div>
  );
}

// ---- BROKEN TEXTURE ----
function BrokenMode({ cur, reveal, setReveal, grade }: MG) {
  const n = 25;
  const [bad] = useState(() => Math.floor(Math.random() * n));
  const tap = (i: number) => { if (!reveal) { grade(i === bad); setReveal(true); } };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">One tile is corrupted. Find the glitch!</p>
      <div className="mx-auto mt-2 grid w-fit gap-0.5 rounded border-2 border-black/60 bg-black/40 p-1" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>
        {Array.from({ length: n }).map((_, i) => (
          <button key={i} onClick={() => tap(i)} disabled={reveal}
            className={`h-12 w-12 sm:h-14 sm:w-14 ${reveal && i === bad ? 'outline outline-4 outline-red-500' : ''}`}>
            <PixelSprite id={cur.id} pal={cur.pal} size={6} pixelSize={7} glitch={i === bad} seed={i === bad ? 'glitch' : 'ok'} style={{ width: '100%', height: '100%' }} />
          </button>
        ))}
      </div>
      {reveal && <p className="mt-2 text-sm font-bold text-white">Glitch located!</p>}
    </div>
  );
}

// ---- SCREENSHOT MATCH ----
function MatchMode({ cur, reveal, setReveal, grade }: MG) {
  const [left] = useState(() => shuffle([cur, ...shuffle(ENTITIES.filter(e => e.id !== cur.id)).slice(0, 2)]));
  const [sel, setSel] = useState<string | null>(null);
  const tap = (id: string) => { if (reveal) return; setSel(id); grade(id === cur.id); setReveal(true); };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">Match the scene to its name — fast!</p>
      <div className="mx-auto mt-2 w-fit rounded-lg border-2 border-black/60 bg-black/40 p-2">
        <PixelSprite id={cur.id} pal={cur.pal} size={16} pixelSize={6} crop={0.85} />
      </div>
      <div className="mx-auto mt-2 grid max-w-md grid-cols-3 gap-2">
        {left.map(e => (
          <button key={e.id} disabled={reveal} onClick={() => tap(e.id)}
            className={`mc-choice !text-xs ${reveal && e.id === cur.id ? '!border-[#6abe30] !bg-[#2e7d32]' : ''} ${sel === e.id && e.id !== cur.id ? '!border-red-500 !bg-[#7d2a2a]' : ''}`}>{e.name}</button>
        ))}
      </div>
    </div>
  );
}

// ---- FIND THE BLOCK ----
function FindMode({ cur, diff, reveal, setReveal, grade, stage = 0, setStage }: MG) {
  const total = diff === 'Easy' ? 5 : diff === 'Medium' ? 8 : 12;
  const need = stage;
  const [cells, setCells] = useState(() => spawnFind(cur.id, total));
  const [hits, setHits] = useState(0);
  function spawnFind(id: string, count: number) {
    const cells: { id: string; isTarget: boolean }[] = [];
    for (let i = 0; i < 12; i++) cells.push({ id: shuffle(ENTITIES.filter(e => e.id !== id)).slice(0, 1)[0].id, isTarget: false });
    for (let k = 0; k < 3; k++) { const i = Math.floor(Math.random() * 12); cells[i] = { id, isTarget: true }; }
    return cells;
  }
  const tap = (i: number) => {
    if (reveal) return;
    if (cells[i].isTarget) {
      const h = hits + 1;
      setHits(h);
      if (h >= total) { grade(true, 50); setReveal(true); }
      else setCells(spawnFind(cur.id, total));
    } else grade(false);
  };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">Tap <b>{hits}/{total}</b> of the target block:</p>
      <div className="mx-auto mt-1 w-fit rounded border-2 border-[#ffd94f] bg-black/40 p-1">
        <PixelSprite id={cur.id} pal={cur.pal} size={8} pixelSize={5} />
      </div>
      <div className="mx-auto mt-2 grid w-fit grid-cols-4 gap-1.5">
        {cells.map((c, i) => { const e = byId(c.id)!; return (
          <button key={i} onClick={() => tap(i)} disabled={reveal} className="h-16 w-16 rounded border-2 border-black/60 bg-black/40 sm:h-20 sm:w-20">
            <PixelSprite id={e.id} pal={e.pal} size={8} pixelSize={6} style={{ width: '100%', height: '100%' }} />
          </button>); })}
      </div>
    </div>
  );
}

// ---- VISUAL SEQUENCE ----
function SequenceMode({ cur, diff, reveal, setReveal, grade, stage = 0, setStage }: MG) {
  const len = diff === 'Easy' ? 3 : diff === 'Medium' ? 4 : 5;
  const [seq] = useState(() => Array.from({ length: len }).map(() => Math.floor(Math.random() * 4)));
  const [show, setShow] = useState(true);
  const [flash, setFlash] = useState(-1);
  const [pos, setPos] = useState(0);
  useEffect(() => {
    let i = 0;
    setShow(true);
    const t = setInterval(() => {
      if (i >= seq.length) { clearInterval(t); setShow(false); setFlash(-1); return; }
      setFlash(seq[i]); i++;
      setTimeout(() => setFlash(-1), 350);
    }, 600);
    return () => clearInterval(t);
  }, [cur.id]); // eslint-disable-line
  const tap = (i: number) => {
    if (reveal || show) return;
    if (i === seq[pos]) {
      if (pos + 1 >= seq.length) { grade(true); setReveal(true); } else setPos(p => p + 1);
    } else { grade(false); setReveal(true); }
  };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">{show ? 'Watch the pattern…' : `Repeat it! (${pos + 1}/${seq.length})`}</p>
      <div className="mx-auto mt-2 grid w-fit grid-cols-2 gap-2">
        {[0, 1, 2, 3].map(i => (
          <button key={i} onClick={() => tap(i)} disabled={reveal || show}
            className="h-20 w-20 rounded-lg border-4 border-black/60 sm:h-24 sm:w-24"
            style={{ background: flash === i ? '#ffd94f' : cur.pal[i], opacity: show && flash !== i ? 0.5 : 1 }} />
        ))}
      </div>
      {reveal && <p className="mt-2 text-sm font-bold text-white">Sequence complete!</p>}
    </div>
  );
}

// ---- ODD TEXTURE OUT ----
function OddMode({ cur, reveal, setReveal, grade }: MG) {
  const [odd] = useState(() => Math.floor(Math.random() * 9));
  const tap = (i: number) => { if (!reveal) { grade(i === odd); setReveal(true); } };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">9 tiles. 1 impostor. 3 seconds of glory!</p>
      <div className="mx-auto mt-2 grid w-fit grid-cols-3 gap-1.5">
        {Array.from({ length: 9 }).map((_, i) => (
          <button key={i} onClick={() => tap(i)} disabled={reveal}
            className={`h-20 w-20 rounded border-2 sm:h-24 sm:w-24 ${reveal && i === odd ? 'border-[#6abe30] outline outline-4 outline-[#6abe30]' : 'border-black/60'} bg-black/40`}>
            <PixelSprite id={cur.id} pal={cur.pal} size={10} pixelSize={6} grayscale={i === odd} style={{ width: '100%', height: '100%' }} />
          </button>
        ))}
      </div>
      {reveal && <p className="mt-2 text-sm font-bold text-white">The grayscale tile was the odd one!</p>}
    </div>
  );
}

// ---- COLOR MEMORY ----
function ColorMode({ cur, diff, reveal, setReveal, grade, stage = 0, setStage }: MG) {
  const len = diff === 'Easy' ? 3 : 4;
  const [order] = useState(() => shuffle([0, 1, 2, 3]).slice(0, len));
  const [phase, setPhase] = useState<'show' | 'ask'>('show');
  const [pos, setPos] = useState(0);
  useEffect(() => { const t = setTimeout(() => setPhase('ask'), 2200); return () => clearTimeout(t); }, []);
  const tap = (i: number) => {
    if (reveal || phase !== 'ask') return;
    if (i === order[pos]) {
      if (pos + 1 >= order.length) { grade(true); setReveal(true); } else setPos(p => p + 1);
    } else { grade(false); setReveal(true); }
  };
  return (
    <div className="text-center">
      <p className="text-sm text-white/70">{phase === 'show' ? 'Memorize this palette order!' : `Repeat the order! (${pos + 1}/${order.length})`}</p>
      {phase === 'show' ? (
        <div className="mx-auto mt-2 flex w-fit gap-2">
          {order.map((c, i) => <div key={i} className="h-16 w-16 rounded-lg border-4 border-black/60" style={{ background: cur.pal[c] }} />)}
        </div>
      ) : (
        <div className="mx-auto mt-2 grid w-fit grid-cols-4 gap-2">
          {[0, 1, 2, 3].map(c => (
            <button key={c} onClick={() => tap(c)} disabled={reveal} className="h-16 w-16 rounded-lg border-4 border-black/60" style={{ background: cur.pal[c] }} />
          ))}
        </div>
      )}
      {reveal && <p className="mt-2 text-sm font-bold text-white">Palette mastered!</p>}
    </div>
  );
}

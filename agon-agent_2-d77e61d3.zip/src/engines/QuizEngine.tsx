// TRIVIA engine: mc/tf/odd/hl/order/truths/complete/whoami + rapid/millionaire/ladder/duel/dailyq.

import { useEffect, useRef, useState } from 'react';
import { TRIVIA, type TriviaQ } from '../data/trivia';
import { ENTITIES } from '../data/entities';
import { DIFFS, calcScore, xpForAnswer, type Diff } from '../lib/difficulty';
import { bumpCombo, recordAnswer, recordGame, addXp, setRecord, getState, usePlayer, shuffle, seeded, todayKey } from '../lib/store';
import { playUI } from '../lib/audio';
import PixelSprite from '../components/PixelSprite';
import Icon from '../components/Icon';
import { TimerBar, ScoreHUD, DifficultyPicker, ChoiceGrid } from '../components/GameUI';
import { checkAchievements, Toast } from '../components/Achievements';

interface Props { gameId: string; mode: string; rounds?: number; fixedDiff?: Diff; singleQ?: TriviaQ; onFinish?: (score: number, correct: number, total: number) => void; }

const MODE_FILTER: Record<string, string[]> = {
  mc: ['mc'], tf: ['tf'], truths: ['truths'], order: ['order'], odd: ['odd'],
  hl: ['hl'], complete: ['complete'], whoami: ['whoami'], rapid: ['mc', 'tf', 'odd', 'hl', 'whoami'],
  millionaire: ['mc', 'odd', 'hl', 'complete', 'order', 'truths', 'whoami'],
  ladder: ['mc', 'tf', 'odd', 'hl', 'complete', 'whoami', 'truths'],
  duel: ['mc', 'whoami', 'odd', 'hl'], dailyq: ['mc', 'tf', 'odd', 'whoami'],
};

export default function QuizEngine({ gameId, mode, rounds = 8, fixedDiff, singleQ, onFinish }: Props) {
  const player = usePlayer();
  const [diff, setDiff] = useState<Diff>(fixedDiff ?? 'Medium');
  const [qs, setQs] = useState<TriviaQ[]>([]);
  const [round, setRound] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [reveal, setReveal] = useState(false);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [clueUsed, setClueUsed] = useState(0);
  const [lifelines, setLifelines] = useState<string[]>([]);
  const [removed, setRemoved] = useState<number[]>([]);
  const [orderMap, setOrderMap] = useState<number[]>([]); // display position -> original choice index
  const [tfOrder, setTfOrder] = useState<number[]>([0, 1]); // shuffled TRUE/FALSE positions
  const [rapidLeft, setRapidLeft] = useState(60);
  const [qKey, setQKey] = useState(0);
  const startRef = useRef(Date.now());
  const lastQ = useRef<TriviaQ | null>(null);

  const isRapid = mode === 'rapid';
  const isMillionaire = mode === 'millionaire';
  const ladderDiff: Diff = mode === 'ladder' ? (round < 3 ? 'Easy' : round < 6 ? 'Medium' : round < 9 ? 'Hard' : 'Insane') : diff;
  const rule = DIFFS[ladderDiff];
  const timeLimit = isRapid ? 999 : isMillionaire ? 45 : rule.time;

  useEffect(() => {
    let pool = TRIVIA.filter(q => (MODE_FILTER[mode] ?? ['mc']).includes(q.t));
    if (singleQ) pool = [singleQ];
    let list: TriviaQ[];
    if (mode === 'dailyq') {
      const rand = seeded('dailyq-' + todayKey());
      list = [pool[Math.floor(rand() * pool.length)]];
    } else {
      list = shuffle(pool).slice(0, isRapid ? 40 : isMillionaire ? 8 : rounds);
    }
    if (!list.length) list = shuffle(TRIVIA).slice(0, rounds);
    setQs(list); setRound(0); setScore(0); setXp(0); setCorrectCount(0);
    setFinished(false); setRapidLeft(60);
  }, [mode, gameId]); // eslint-disable-line

  useEffect(() => {
    setPicked(null); setReveal(false); setClueUsed(0); setRemoved([]);
    // Shuffle ALL answer positions every round so the correct answer
    // lands randomly in A, B, C, or D (grading still uses original indices).
    const qq = qs[round];
    setOrderMap(qq?.c?.length ? shuffle(qq.c.map((_, i) => i)) : []);
    setTfOrder(shuffle([0, 1]));
    startRef.current = Date.now(); setQKey(k => k + 1);
  }, [round, qs.length, gameId, mode]);

  useEffect(() => {
    if (!isRapid || finished) return;
    if (rapidLeft <= 0) { finish(); return; }
    const t = setTimeout(() => setRapidLeft(l => l - 1), 1000);
    return () => clearTimeout(t);
  }, [rapidLeft, finished]); // eslint-disable-line

  const q = qs[round];
  if (!q) return <div className="mc-panel p-6">Loading questions…</div>;
  if (mode === 'dailyq') rounds = 1;
  const total = isRapid ? qs.length : mode === 'dailyq' ? 1 : (isMillionaire ? 8 : rounds);

  const submit = (idx: number | null) => {
    if (reveal) return;
    const ok = idx === q.a;
    const elapsed = Date.now() - startRef.current;
    bumpCombo(ok); recordAnswer(ok, elapsed);
    const { points, breakdown } = calcScore({ correct: ok, diff: ladderDiff, elapsedMs: elapsed, timeLimit, combo: getState().currentCombo, hintsUsed: clueUsed + lifelines.length, hintCostTotal: clueUsed * 20, clueIndex: clueUsed });
    const gained = xpForAnswer(ok, ladderDiff);
    if (ok) { setScore(s => s + points); setXp(x => x + gained); addXp(gained); setCorrectCount(c => c + 1); }
    lastQ.current = q;
    setPicked(idx); setReveal(true);
    const fresh = checkAchievements({ combo: getState().currentCombo, speedMs: elapsed, game: gameId, diff: ladderDiff });
    if (fresh.length) setToast(fresh[0]);
    if (isMillionaire && !ok) { setTimeout(() => finish(), 1800); }
  };

  const finish = () => {
    const perfect = recordGame(gameId, score, correctCount, Math.max(1, round + (reveal ? 1 : 0)));
    setRecord(`${gameId}-best`, score);
    checkAchievements({ perfect, combo: getState().bestCombo, game: gameId, diff });
    setFinished(true);
    onFinish?.(score, correctCount, Math.max(1, round + 1));
  };

  const next = () => {
    if (round + 1 >= total) finish();
    else setRound(r => r + 1);
  };

  if (finished) {
    const totalQ = Math.max(1, round + 1);
    return (
      <div className="mc-panel p-6 text-center">
        <div className="font-pixel text-xl text-[#ffd94f]">{isMillionaire ? '💰 MILLIONAIRE RUN OVER' : isRapid ? '⏱ TIME!' : 'TRIVIA COMPLETE!'}</div>
        <div className="mt-2 text-4xl font-black text-white">{score} <span className="text-base text-white/50">pts</span></div>
        <div className="mt-1 text-white/70">{correctCount}/{totalQ} correct · +{xp} XP</div>
        {isRapid && setRecordSilent() && null}
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <button className="mc-btn" onClick={() => window.location.reload()}>PLAY AGAIN</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  const vol = player.sound ? player.volume : 0;
  const entity = ENTITIES.find(e => q.q.toLowerCase().includes(e.name.toLowerCase().split(' ')[0].toLowerCase()) && e.name.length > 4);
  const ladderVal = isMillionaire ? [100, 200, 400, 800, 1600, 3200, 6400, 10000][round] : 0;

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={player.currentCombo} q={round + 1} total={total} xp={xp} />
        {!fixedDiff && mode !== 'ladder' && <DifficultyPicker value={diff} onChange={d => setDiff(d as Diff)} />}
        {mode === 'ladder' && <span className="mc-chip">LADDER: {ladderDiff.toUpperCase()}</span>}
        {isRapid && <span className="mc-chip !bg-red-500/80">⏱ {rapidLeft}s</span>}
        {isMillionaire && <span className="mc-chip !bg-[#ffd94f] !text-black">💰 {ladderVal}</span>}
      </div>
      {!isRapid && <TimerBar total={timeLimit} running={!reveal} onExpire={() => submit(null)} resetKey={qKey} />}

      <div className="mc-panel space-y-3 p-4">
        <div className="flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wide text-white/60">
          <span className="mc-chip">{q.cat}</span>
          <span>{modeLabel(mode)}</span>
          {mode === 'whoami' && !reveal && <span className="mc-chip !bg-[#7a4fb0]">Clue {clueUsed + 1}/3</span>}
        </div>
        <h2 className="text-center text-lg font-bold text-white sm:text-xl">{q.q}</h2>
        {entity && (
          <div className="mx-auto w-fit rounded-lg border-2 border-black/60 bg-black/40 p-2">
            <PixelSprite id={entity.id} pal={entity.pal} size={12} pixelSize={4} />
          </div>
        )}
        {mode === 'whoami' && !reveal && (
          <div className="mx-auto max-w-md space-y-1 text-center text-sm text-white/70">
            <p>💬 {whoClue(q, clueUsed, orderMap)}</p>
            {clueUsed < 2 && <button className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs" onClick={() => setClueUsed(c => c + 1)}>REVEAL NEXT CLUE (−20 pts)</button>}
          </div>
        )}
        {isMillionaire && !reveal && (
          <div className="flex justify-center gap-2">
            <button disabled={lifelines.includes('5050')} onClick={() => {
              const wrong = (q.c ?? []).map((_, i) => i).filter(i => i !== q.a);
              setRemoved(shuffle(wrong).slice(0, 2)); setLifelines(l => [...l, '5050']);
            }} className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs">50:50</button>
            <button disabled={lifelines.includes('skip')} onClick={() => { setLifelines(l => [...l, 'skip']); next(); }} className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs">SKIP</button>
          </div>
        )}

        {!reveal ? (
          q.t === 'tf' ? (
            <div className="mx-auto grid max-w-md grid-cols-2 gap-2">
              {tfOrder.map(v => (v === 0 ? 'TRUE' : 'FALSE')).map(t => (
                <button key={t} onClick={() => { playUI('click', vol); submit(t === 'TRUE' ? 1 : 0); }}
                  className={`mc-btn py-4 text-lg ${t === 'TRUE' ? '!bg-[#2e7d32]' : '!bg-[#7d2a2a]'}`}>{t}</button>
              ))}
            </div>
          ) : (
            <VisibleChoices
              choices={q.c ?? []}
              removed={removed}
              picked={picked}
              answer={Number(q.a)}
              order={orderMap}
              onPick={(real) => { playUI('click', vol); submit(real); }}
              disabled={reveal}
            />
          )
        ) : (
          <div className={`rounded-lg border-2 p-3 text-center ${picked === q.a ? 'border-[#6abe30] bg-[#2e7d32]/30' : 'border-red-500 bg-[#7d2a2a]/30'}`}>
            <div className={`font-pixel text-sm ${picked === q.a ? 'text-[#6abe30]' : 'text-red-400'}`}>
              {picked === q.a ? '✓ CORRECT!' : `✗ ANSWER: ${(q.t === 'tf' ? ['FALSE', 'TRUE'] : q.c ?? [])[Number(q.a)]}`}
            </div>
            <p className="mx-auto mt-1 max-w-md text-sm text-white/80">💡 {q.e}</p>
            <button className="mc-btn mx-auto mt-3" onClick={next} autoFocus>{round + 1 >= total ? 'FINISH' : 'NEXT'} <Icon name="ChevronRight" size={16} /></button>
          </div>
        )}
      </div>
    </div>
  );
}

function setRecordSilent() { return false; }

function VisibleChoices({ choices, removed, picked, answer, order, onPick, disabled }: {
  choices: string[]; removed: number[]; picked: number | null; answer: number; order: number[];
  onPick: (realIdx: number) => void; disabled: boolean;
}) {
  const ord = order.length === choices.length ? order : choices.map((_, k) => k);
  const visible = ord.filter(k => !removed.includes(k)).map(k => ({ c: choices[k], k }));
  const answerVis = visible.findIndex(({ k }) => k === answer);
  const pickedVis = picked === null ? null : visible.findIndex(({ k }) => k === picked);
  return <ChoiceGrid choices={visible.map(v => v.c)} picked={pickedVis} answerIdx={answerVis} onPick={(i) => onPick(visible[i].k)} disabled={disabled} />;
}

function modeLabel(m: string) {
  return { mc: 'Multiple choice', tf: 'True / False', truths: 'Two truths & a lie', order: 'Which came first?', odd: 'Odd one out', hl: 'Higher or lower', complete: 'Complete the fact', whoami: 'Who am I?', rapid: 'Rapid fire', millionaire: 'Millionaire', ladder: 'Trivia ladder', duel: 'Category duel', dailyq: 'Daily question' }[m] ?? m;
}

function whoClue(q: TriviaQ, i: number, order?: number[]): string {
  const list = order?.length === (q.c?.length ?? 0) ? order.map(k => (q.c ?? [])[k]) : (q.c ?? []);
  const parts = [q.q, q.e, `It is one of: ${list.join(', ')}`];
  return parts[Math.min(i, 2)];
}

// LETTER engine: starts/rush/combo/alphabet/run/chain/forbidden/catchain/exact/boss/scramble/missing/both.

import { useEffect, useMemo, useRef, useState } from 'react';
import { ENTITIES, byId, CATS } from '../data/entities';
import { DIFFS, xpForAnswer, type Diff } from '../lib/difficulty';
import { bumpCombo, recordAnswer, recordGame, addXp, setRecord, getState, usePlayer, shuffle } from '../lib/store';
import { playUI } from '../lib/audio';
import PixelSprite from '../components/PixelSprite';
import Icon from '../components/Icon';
import { ScoreHUD, DifficultyPicker } from '../components/GameUI';
import { checkAchievements, Toast } from '../components/Achievements';

interface Props { gameId: string; mode: string; fixedDiff?: Diff; onFinish?: (s: number, c: number, t: number) => void; }

const norm = (v: string) => v.trim().toLowerCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
const ALL_NAMES = () => ENTITIES.flatMap(e => [e.name, ...e.aliases]);

export default function LetterEngine({ gameId, mode, fixedDiff, onFinish }: Props) {
  const player = usePlayer();
  const [diff, setDiff] = useState<Diff>(fixedDiff ?? 'Medium');
  const rule = DIFFS[diff];
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [found, setFound] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const [msg, setMsg] = useState('');
  const [finished, setFinished] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(60);
  const [target] = useState(() => initTarget(mode, diff));
  const [round, setRound] = useState(0);
  const [puzzle] = useState(() => initPuzzle(mode));
  const startRef = useRef(Date.now());

  const need = target.need;
  const timeTotal = target.time;

  useEffect(() => { startRef.current = Date.now(); }, []);
  useEffect(() => {
    if (finished || !target.timed) return;
    if (timeLeft <= 0) { finish(); return; }
    const t = setTimeout(() => setTimeLeft(l => l - 1), 1000);
    return () => clearTimeout(t);
  }, [timeLeft, finished]); // eslint-disable-line

  useEffect(() => { setTimeLeft(target.time); }, [target.time]);

  const accept = (raw: string): { ok: boolean; why: string; entityId?: string } => {
    const n = norm(raw);
    if (!n) return { ok: false, why: 'Type an answer first.' };
    const ent = ENTITIES.find(e => norm(e.name) === n || e.aliases.some(a => norm(a) === n) || norm(e.id.replace(/_/g, ' ')) === n);
    if (!ent) return { ok: false, why: `"${raw.trim()}" is not a known Minecraft thing.` };
    if (found.includes(ent.id)) return { ok: false, why: 'Already given — no duplicates!' };
    if (mode === 'starts' || mode === 'rush' || mode === 'boss') {
      if (target.letter && !ent.name.toLowerCase().startsWith(target.letter.toLowerCase()))
        return { ok: false, why: `Must start with “${target.letter.toUpperCase()}”.` };
      if (target.cat && ent.cat !== target.cat) return { ok: false, why: `Must be a ${target.cat}.` };
    }
    if (mode === 'combo') {
      if (!ent.name.toLowerCase().startsWith(target.letter.toLowerCase())) return { ok: false, why: `Must start with “${target.letter.toUpperCase()}”.` };
      if (ent.cat !== target.cat) return { ok: false, why: `Must be a ${target.cat}.` };
    }
    if (mode === 'run') {
      const want = String.fromCharCode(65 + found.length);
      if (!ent.name.toUpperCase().startsWith(want)) return { ok: false, why: `Letter ${found.length + 1} must start with “${want}”.` };
    }
    if (mode === 'chain' && found.length) {
      const prev = byId(found[found.length - 1])!;
      const last = prev.name.replace(/[^a-z]/gi, '').slice(-1).toLowerCase();
      if (!ent.name.toLowerCase().startsWith(last)) return { ok: false, why: `Must start with “${last.toUpperCase()}” (last letter of ${prev.name}).` };
    }
    if (mode === 'forbidden' && ent.name.toLowerCase().includes(target.letter.toLowerCase()))
      return { ok: false, why: `Contains the forbidden letter “${target.letter.toUpperCase()}”!` };
    if (mode === 'catchain' && found.length) {
      const prev = byId(found[found.length - 1])!;
      if (prev.cat === ent.cat) return { ok: false, why: `Category must alternate (last was ${prev.cat}).` };
    }
    if (mode === 'both') {
      if (!ent.name.toLowerCase().startsWith(target.letter.toLowerCase()) || !ent.name.toLowerCase().endsWith(target.letter2!.toLowerCase()))
        return { ok: false, why: `Must start with “${target.letter}” AND end with “${target.letter2}”.` };
    }
    return { ok: true, why: '', entityId: ent.id };
  };

  const submit = () => {
    if (finished || !input.trim()) return;
    const r = accept(input);
    const elapsed = Date.now() - startRef.current;
    if (!r.ok) { setMsg(r.why); bumpCombo(false); recordAnswer(false, elapsed); playUI('wrong', player.sound ? player.volume : 0); setInput(''); return; }
    const combo = bumpCombo(true); recordAnswer(true, elapsed);
    const pts = Math.round(60 * rule.mult + Math.min(combo, 15) * 5);
    const gained = xpForAnswer(true, diff);
    setScore(s => s + pts); setXp(x => x + gained); addXp(gained);
    setFound(f => [...f, r.entityId!]);
    setMsg(`+${pts} — ${byId(r.entityId!)!.name}!`);
    playUI('correct', player.sound ? player.volume : 0);
    setInput('');
    const fresh = checkAchievements({ combo: getState().currentCombo, speedMs: elapsed, game: gameId });
    if (fresh.length) setToast(fresh[0]);
    if (mode !== 'rush' && mode !== 'boss' && found.length + 1 >= need) finish(found.length + 1);
  };

  const finish = (count?: number) => {
    const c = count ?? found.length;
    const perfect = recordGame(gameId, score, c, need);
    setRecord(`${gameId}-best`, score);
    if (mode === 'rush') { const s = getState(); import('../lib/store').then(m => m.setState({ bestLetterRush: Math.max(s.bestLetterRush, score) })); }
    checkAchievements({ perfect: mode !== 'rush' && c >= need, combo: getState().bestCombo, game: gameId });
    setFinished(true);
    onFinish?.(score, c, need);
  };

  // Special sub-modes with fixed puzzles
  if (mode === 'scramble' || mode === 'missing' || mode === 'alphabet') {
    return <PuzzleMode gameId={gameId} mode={mode} diff={diff} onDiff={setDiff} fixedDiff={fixedDiff} onFinish={onFinish} />;
  }

  const progress = mode === 'rush' || mode === 'boss' ? found.length : Math.min(found.length, need);

  if (finished) {
    return (
      <div className="mc-panel p-6 text-center">
        <div className="font-pixel text-xl text-[#ffd94f]">LETTER GAME OVER!</div>
        <div className="mt-2 text-4xl font-black text-white">{score} <span className="text-base text-white/50">pts</span></div>
        <div className="mt-1 text-white/70">{found.length} valid answers · +{xp} XP</div>
        <div className="mx-auto mt-3 flex max-w-md flex-wrap justify-center gap-1.5">
          {found.map(id => { const e = byId(id)!; return <span key={id} className="mc-chip">{e.name}</span>; })}
        </div>
        <div className="mt-4 flex justify-center gap-2">
          <button className="mc-btn" onClick={() => window.location.reload()}>PLAY AGAIN</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Toast msg={toast} onDone={() => setToast(null)} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={player.currentCombo} q={progress} total={mode === 'rush' || mode === 'boss' ? 99 : need} xp={xp} />
        {!fixedDiff && <DifficultyPicker value={diff} onChange={d => setDiff(d as Diff)} />}
        {target.timed && <span className="mc-chip !bg-red-500/80">⏱ {timeLeft}s</span>}
      </div>
      <div className="mc-panel space-y-3 p-4">
        <div className="text-center">
          <div className="font-pixel text-sm text-[#ffd94f]">{target.title}</div>
          <p className="mt-1 text-sm text-white/70">{target.desc}</p>
          {(mode === 'run' || mode === 'chain' || mode === 'catchain') && found.length > 0 && (
            <p className="mt-1 text-xs text-white/60">Chain: {found.map(id => byId(id)!.name).join(' → ')}</p>
          )}
          {mode === 'run' && <p className="mt-1 font-bold text-white">Next letter: {String.fromCharCode(65 + found.length)}</p>}
          {mode === 'chain' && found.length > 0 && (
            <p className="mt-1 font-bold text-white">Next must start with “{byId(found[found.length - 1])!.name.replace(/[^a-z]/gi, '').slice(-1).toUpperCase()}”</p>
          )}
        </div>
        {/* progress */}
        {mode !== 'rush' && mode !== 'boss' && (
          <div className="mx-auto max-w-md">
            <div className="mb-1 text-center text-xs text-white/60">{found.length}/{need}</div>
            <div className="h-3 overflow-hidden rounded border-2 border-black/60 bg-black/50">
              <div className="h-full bg-[#6abe30]" style={{ width: `${(found.length / need) * 100}%` }} />
            </div>
          </div>
        )}
        <div className="mx-auto flex max-w-md gap-2">
          <input value={input} onChange={e => setInput(e.target.value)} autoFocus
            onKeyDown={e => e.key === 'Enter' && submit()}
            placeholder="Type a Minecraft name…" className="mc-input flex-1" />
          <button className="mc-btn" onClick={submit}>GO</button>
        </div>
        {msg && <p className={`text-center text-sm ${msg.startsWith('+') ? 'text-[#6abe30]' : 'text-red-400'}`}>{msg}</p>}
        <div className="mx-auto flex max-w-lg flex-wrap justify-center gap-1.5">
          {found.map(id => { const e = byId(id)!; return (
            <span key={id} className="flex items-center gap-1 rounded border border-black/60 bg-black/40 px-1.5 py-0.5 text-xs text-white">
              <PixelSprite id={e.id} pal={e.pal} size={8} pixelSize={2} /> {e.name}
            </span>); })}
        </div>
        {target.timed && <button className="mc-btn mc-btn-gray mx-auto !text-xs" onClick={() => finish()}>FINISH EARLY</button>}
      </div>
    </div>
  );
}

function initTarget(mode: string, diff: Diff) {
  const letters = 'ABCDEFGHIMNOPSTWZ';
  const L = letters[Math.floor(Math.random() * letters.length)];
  const cats = ['block', 'mob', 'item', 'biome', 'tool', 'food'] as const;
  const C = cats[Math.floor(Math.random() * cats.length)];
  const hard = diff === 'Hard' || diff === 'Insane' || diff === 'Nightmare';
  switch (mode) {
    case 'starts': return { title: `NAME ${hard ? 8 : 5} THINGS STARTING WITH “${L}”`, desc: `Progress counts up as you go. No duplicates!`, need: hard ? 8 : 5, timed: false, time: 0, letter: L };
    case 'rush': return { title: 'LETTER RUSH — 60 SECONDS', desc: `Type as many valid Minecraft names starting with “${L}” as you can!`, need: 99, timed: true, time: 60, letter: L };
    case 'combo': return { title: `LETTER + CATEGORY`, desc: `Name ${hard ? 6 : 4} ${C}s starting with “${L}”.`, need: hard ? 6 : 4, timed: false, time: 0, letter: L, cat: C };
    case 'run': return { title: 'ALPHABET RUN A→Z', desc: 'Chain valid names from A to Z in order. How far can you go?', need: 12, timed: true, time: 120, letter: 'A' };
    case 'chain': return { title: 'LAST LETTER CHAIN', desc: 'Each answer must start with the last letter of the previous one.', need: 8, timed: false, time: 0, letter: '' };
    case 'forbidden': return { title: `FORBIDDEN LETTER: “${L}”`, desc: 'Name valid things WITHOUT using that letter anywhere.', need: hard ? 8 : 5, timed: false, time: 0, letter: L };
    case 'catchain': return { title: 'CATEGORY CHAIN', desc: 'Alternate categories with every answer. Same category twice = rejected!', need: 8, timed: false, time: 0, letter: '' };
    case 'exact': return { title: `EXACT COUNT: ${hard ? 7 : 5}`, desc: 'Name EXACTLY that many valid things, then hit Finish.', need: hard ? 7 : 5, timed: true, time: 90, letter: '' };
    case 'boss': return { title: 'LETTER BOSS — 45 SECONDS', desc: `Only ${C}s starting with “${L}”. Brutal.`, need: 99, timed: true, time: 45, letter: L, cat: C };
    case 'both': return { title: `STARTS “${L}” + ENDS “${'AEIORST'[Math.floor(Math.random() * 7)]}”`, desc: 'Names that start AND end with the given letters.', need: 4, timed: false, time: 0, letter: L, letter2: 'AEIORST'[Math.floor(Math.random() * 7)] };
    default: return { title: 'LETTER GAME', desc: '', need: 5, timed: false, time: 0, letter: L };
  }
}

function initPuzzle(_mode: string) { return { round: 0 }; }

// Scramble / Missing-letters / Alphabet picker
function PuzzleMode({ gameId, mode, diff, onDiff, fixedDiff, onFinish }: { gameId: string; mode: string; diff: Diff; onDiff: (d: Diff) => void; fixedDiff?: Diff; onFinish?: (s: number, c: number, t: number) => void }) {
  const player = usePlayer();
  const [list] = useState(() => shuffle(ENTITIES).slice(0, mode === 'alphabet' ? 10 : 8));
  const [round, setRound] = useState(0);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [input, setInput] = useState('');
  const [reveal, setReveal] = useState(false);
  const [wasOk, setWasOk] = useState(false);
  const [finished, setFinished] = useState(false);
  const [picked, setPicked] = useState<number | null>(null);
  const startRef = useRef(Date.now());
  const rule = DIFFS[diff];
  const cur = list[round];
  const [alphaChoices, setAlphaChoices] = useState(() => shuffle(ENTITIES.filter(e => e.name[0].toUpperCase() !== list[0].name[0].toUpperCase())).slice(0, 3));

  useEffect(() => { setInput(''); setReveal(false); setPicked(null); startRef.current = Date.now();
    setAlphaChoices(shuffle(ENTITIES.filter(e => e.name[0].toUpperCase() !== list[round].name[0].toUpperCase())).slice(0, 3));
  }, [round]); // eslint-disable-line

  const scrambled = useMemo(() => {
    const w = cur.name.replace(/[^a-z]/gi, '');
    return shuffle(w.split('')).join(' ').toUpperCase();
  }, [cur]);
  const masked = useMemo(() => {
    const frac = diff === 'Easy' ? 0.3 : diff === 'Medium' ? 0.45 : 0.6;
    return cur.name.split('').map(ch => (/[a-z]/i.test(ch) && Math.random() < frac ? '_' : ch)).join('');
  }, [cur, diff]);

  const submitText = () => {
    if (reveal) return;
    const ok = norm(input) === norm(cur.name) || cur.aliases.some(a => norm(a) === norm(input));
    grade(ok);
  };
  const grade = (ok: boolean) => {
    const elapsed = Date.now() - startRef.current;
    bumpCombo(ok); recordAnswer(ok, elapsed);
    const gained = xpForAnswer(ok, diff);
    const pts = ok ? Math.round(80 * rule.mult + Math.max(0, 40 - elapsed / 500)) : 0;
    if (ok) { setScore(s => s + pts); setXp(x => x + gained); addXp(gained); setCorrectCount(c => c + 1); }
    setWasOk(ok); setReveal(true);
    playUI(ok ? 'correct' : 'wrong', player.sound ? player.volume : 0);
  };
  const next = () => {
    if (round + 1 >= list.length) {
      const perfect = recordGame(gameId, score, correctCount, list.length);
      setRecord(`${gameId}-best`, score);
      checkAchievements({ perfect, combo: getState().bestCombo, game: gameId });
      setFinished(true); onFinish?.(score, correctCount, list.length);
    } else setRound(r => r + 1);
  };

  if (finished) {
    return (
      <div className="mc-panel p-6 text-center">
        <div className="font-pixel text-xl text-[#ffd94f]">COMPLETE!</div>
        <div className="mt-2 text-4xl font-black text-white">{score} <span className="text-base text-white/50">pts</span></div>
        <div className="mt-1 text-white/70">{correctCount}/{list.length} correct · +{xp} XP</div>
        <div className="mt-4 flex justify-center gap-2">
          <button className="mc-btn" onClick={() => window.location.reload()}>PLAY AGAIN</button>
          <button className="mc-btn mc-btn-gray" onClick={() => window.history.back()}>BACK</button>
        </div>
      </div>
    );
  }

  const alphaAll = useMemo(() => shuffle([cur, ...alphaChoices]), [cur, alphaChoices]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ScoreHUD score={score} combo={player.currentCombo} q={round + 1} total={list.length} xp={xp} />
        {!fixedDiff && <DifficultyPicker value={diff} onChange={d => onDiff(d as Diff)} />}
      </div>
      <div className="mc-panel space-y-3 p-4 text-center">
        {mode === 'scramble' && <>
          <div className="text-xs font-bold uppercase text-white/60">Unscramble the name</div>
          <div className="font-pixel text-2xl tracking-widest text-[#ffd94f]">{scrambled}</div>
          <div className="text-xs text-white/50">Hint: {cur.cat} · {cur.desc}</div>
        </>}
        {mode === 'missing' && <>
          <div className="text-xs font-bold uppercase text-white/60">Fill the missing letters</div>
          <div className="font-pixel text-2xl tracking-widest text-white">{masked}</div>
          <div className="text-xs text-white/50">Hint: {cur.cat} · {cur.clues[1]}</div>
        </>}
        {mode === 'alphabet' && <>
          <div className="text-xs font-bold uppercase text-white/60">Which one starts with “{cur.name[0].toUpperCase()}”?</div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {alphaAll.map(e => (
              <button key={e.id} disabled={reveal} onClick={() => { setPicked(alphaAll.indexOf(e)); grade(e.id === cur.id); }}
                className={`rounded-lg border-2 border-black/60 bg-black/40 p-2 ${reveal && e.id === cur.id ? '!border-[#6abe30]' : ''} ${picked !== null && alphaAll[picked]?.id === e.id && e.id !== cur.id ? '!border-red-500' : ''}`}>
                <PixelSprite id={e.id} pal={e.pal} size={10} pixelSize={4} />
                <div className="mt-1 text-xs font-bold text-white">{e.name}</div>
              </button>
            ))}
          </div>
        </>}
        {mode !== 'alphabet' && !reveal && (
          <div className="mx-auto flex max-w-md gap-2">
            <input value={input} onChange={e => setInput(e.target.value)} autoFocus
              onKeyDown={e => e.key === 'Enter' && submitText()} placeholder="Your answer…" className="mc-input flex-1" />
            <button className="mc-btn" onClick={submitText}>GO</button>
          </div>
        )}
        {reveal && (
          <div className={`rounded-lg border-2 p-3 ${wasOk ? 'border-[#6abe30] bg-[#2e7d32]/30' : 'border-red-500 bg-[#7d2a2a]/30'}`}>
            <div className="font-bold text-white">{wasOk ? '✓ Correct!' : `✗ It was: ${cur.name}`}</div>
            <div className="mx-auto mt-2 w-fit"><PixelSprite id={cur.id} pal={cur.pal} size={10} pixelSize={5} /></div>
            <button className="mc-btn mx-auto mt-2" onClick={next} autoFocus>{round + 1 >= list.length ? 'FINISH' : 'NEXT'}</button>
          </div>
        )}
      </div>
    </div>
  );
}

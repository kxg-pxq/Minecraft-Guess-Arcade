// Original synthesized sound effects via WebAudio — no copyrighted audio.
// Each entity gets a deterministic little "voice" from its id hash.

let ctx: AudioContext | null = null;
function ac(): AudioContext {
  if (!ctx) ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  return ctx;
}

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function tone(freq: number, t0: number, dur: number, type: OscillatorType, vol: number, slide = 0) {
  const c = ac();
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g); g.connect(c.destination);
  o.start(t0); o.stop(t0 + dur + 0.05);
}

export function playEntitySound(id: string, volume = 0.6) {
  try {
    const c = ac();
    if (c.state === 'suspended') void c.resume();
    const h = hashStr(id);
    const t0 = c.currentTime + 0.02;
    const base = 180 + (h % 500);
    const kind = h % 4;
    const vol = 0.25 * volume + 0.05;
    if (kind === 0) { // chirp-chirp
      tone(base, t0, 0.12, 'square', vol, base * 0.5);
      tone(base * 1.2, t0 + 0.16, 0.14, 'square', vol, -base * 0.3);
    } else if (kind === 1) { // low growl
      tone(base * 0.4, t0, 0.35, 'sawtooth', vol, -40);
      tone(base * 0.42, t0 + 0.1, 0.3, 'sawtooth', vol * 0.7, -60);
    } else if (kind === 2) { // bubble arp
      for (let i = 0; i < 4; i++) tone(base * (1 + i * 0.25), t0 + i * 0.11, 0.1, 'sine', vol, 120);
    } else { // thump-whistle
      tone(120, t0, 0.15, 'triangle', vol);
      tone(base * 1.5, t0 + 0.18, 0.25, 'sine', vol, -200);
    }
  } catch { /* audio unavailable */ }
}

export function playUI(kind: 'click' | 'correct' | 'wrong' | 'win' | 'tick' | 'reveal', volume = 0.6) {
  try {
    const c = ac();
    if (c.state === 'suspended') void c.resume();
    const t0 = c.currentTime + 0.01;
    const v = 0.2 * volume + 0.03;
    if (kind === 'click') tone(660, t0, 0.07, 'square', v);
    else if (kind === 'tick') tone(880, t0, 0.05, 'square', v * 0.6);
    else if (kind === 'correct') { tone(523, t0, 0.12, 'sine', v); tone(784, t0 + 0.1, 0.18, 'sine', v); }
    else if (kind === 'wrong') { tone(220, t0, 0.2, 'sawtooth', v); tone(155, t0 + 0.12, 0.25, 'sawtooth', v); }
    else if (kind === 'win') { [523, 659, 784, 1046].forEach((f, i) => tone(f, t0 + i * 0.12, 0.16, 'triangle', v)); }
    else if (kind === 'reveal') { tone(392, t0, 0.1, 'triangle', v); tone(587, t0 + 0.08, 0.15, 'triangle', v); }
  } catch { /* ignore */ }
}

// ---- Mob vs Mob battle sounds (original synth, per-attack damage audio) ----
export function playBattleHit(volume = 0.6, heavy = false) {
  try {
    const c = ac();
    if (c.state === 'suspended') void c.resume();
    const t0 = c.currentTime + 0.01;
    const v = 0.28 * volume + 0.05;
    const p = 0.9 + Math.random() * 0.25; // pitch varies every swing
    tone((heavy ? 110 : 170) * p, t0, 0.11, 'triangle', v, -60);
    tone((heavy ? 75 : 130) * p, t0, heavy ? 0.28 : 0.16, 'sawtooth', v * 0.7, -35);
    if (heavy) tone(52, t0 + 0.02, 0.32, 'sine', v, -12);
  } catch { /* ignore */ }
}

export function playBattleDodge(volume = 0.6) {
  try {
    const c = ac();
    if (c.state === 'suspended') void c.resume();
    tone(300, c.currentTime + 0.01, 0.16, 'sine', 0.18 * volume + 0.03, 420); // whoosh
  } catch { /* ignore */ }
}

export function playBattleDie(volume = 0.6) {
  try {
    const c = ac();
    if (c.state === 'suspended') void c.resume();
    const t0 = c.currentTime + 0.01;
    const v = 0.22 * volume + 0.04;
    tone(330, t0, 0.16, 'square', v, -120);
    tone(220, t0 + 0.14, 0.22, 'square', v, -140);
    tone(110, t0 + 0.3, 0.34, 'triangle', v, -60);
  } catch { /* ignore */ }
}

export function playBattleHeal(volume = 0.6) {
  try {
    const c = ac();
    if (c.state === 'suspended') void c.resume();
    const t0 = c.currentTime + 0.01;
    const v = 0.18 * volume + 0.03;
    [440, 554, 659].forEach((f, i) => tone(f, t0 + i * 0.09, 0.12, 'sine', v));
  } catch { /* ignore */ }
}

// Text alternative describing the synthesized clue (accessibility).
export function describeSound(id: string): string {
  const h = hashStr(id);
  const kinds = [
    'Two quick rising chirps (high pitch)',
    'A low wavering growl that falls in pitch',
    'Four bubbly rising notes in a row',
    'A soft thump followed by a falling whistle',
  ];
  return kinds[h % 4];
}

// Central player store: stats, XP, levels, combos, streaks, achievements, settings.
// Persisted to localStorage; synced to Supabase leaderboard via API.

import { useSyncExternalStore, useCallback } from 'react';

export interface PlayerStats {
  games: number; correct: number; answered: number;
  xp: number; level: number;
  bestCombo: number; currentCombo: number;
  streak: number; bestStreak: number; lastDaily: string;
  dailyDone: number; wikiViews: number; discovered: number;
  tournaments: number; insaneClears: number; nightmareClears: number;
  bestEndless: number; survivalWins: number; bossClears: number;
  bestLetterRush: number; memoryPerfect: number; votes: number; comebackWins: number;
  perfectRuns: number; fastestMs: number;
  bestDaily: number; bestWeekly: number;
  achievements: string[];
  discoveredIds: string[];
  history: { game: string; score: number; correct: number; total: number; date: number }[];
  favorites: string[];
  recentGames: string[];
  recentWiki: string[];
  mastery: Record<string, number>;
  records: Record<string, number>;
  titles: string[]; activeTitle: string;
  frames: string[]; activeFrame: string;
  name: string; avatar: string;
  publicProfile: boolean; showOnBoards: boolean;
  sound: boolean; volume: number; reducedMotion: boolean; hardcore: boolean;
  theme: string; colorUI: boolean;
}

const KEY = 'mcga-player-v1';

export const xpForLevel = (lvl: number) => 100 + (lvl - 1) * 75;
export const levelFromXp = (xp: number): { level: number; into: number; need: number } => {
  let level = 1, rem = xp;
  for (;;) { const need = xpForLevel(level); if (rem < need) return { level, into: rem, need }; rem -= need; level++; }
};

const DEFAULTS: PlayerStats = {
  games: 0, correct: 0, answered: 0, xp: 0, level: 1,
  bestCombo: 0, currentCombo: 0, streak: 0, bestStreak: 0, lastDaily: '',
  dailyDone: 0, wikiViews: 0, discovered: 0,
  tournaments: 0, insaneClears: 0, nightmareClears: 0,
  bestEndless: 0, survivalWins: 0, bossClears: 0,
  bestLetterRush: 0, memoryPerfect: 0, votes: 0, comebackWins: 0,
  perfectRuns: 0, fastestMs: 0, bestDaily: 0, bestWeekly: 0,
  achievements: [], discoveredIds: [], history: [], favorites: [],
  recentGames: [], recentWiki: [], mastery: {}, records: {},
  titles: ['Rookie'], activeTitle: 'Rookie', frames: ['default'], activeFrame: 'default',
  name: 'Player' + Math.floor(1000 + Math.random() * 9000), avatar: '⛏️',
  publicProfile: true, showOnBoards: true,
  sound: true, volume: 0.6, reducedMotion: false, hardcore: false, theme: 'overworld', colorUI: true,
};

function load(): PlayerStats {
  try {
    const raw = localStorage.getItem(KEY);
    // Pre-colorify backup: default theme was 'overworld'. Restoring it
    // returns the site to the exact pre-gold look (see /tmp/*.pre-colorify.bak).
    if (raw) return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return { ...DEFAULTS };
}

let state: PlayerStats = load();
const listeners = new Set<() => void>();

function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
}

export function getState(): PlayerStats { return state; }
export function setState(patch: Partial<PlayerStats>) {
  state = { ...state, ...patch };
  // recompute level
  const { level } = levelFromXp(state.xp);
  state.level = level;
  save();
  listeners.forEach(l => l());
}
function subscribe(fn: () => void) { listeners.add(fn); return () => { listeners.delete(fn); }; }

export function usePlayer(): PlayerStats {
  return useSyncExternalStore(subscribe, () => state, () => state);
}

// ---------- actions ----------
export function addXp(n: number) { setState({ xp: Math.max(0, state.xp + n) }); }

export function bumpCombo(ok: boolean): number {
  const currentCombo = ok ? state.currentCombo + 1 : 0;
  const bestCombo = Math.max(state.bestCombo, currentCombo);
  setState({ currentCombo, bestCombo });
  return currentCombo;
}

export function recordAnswer(ok: boolean, speedMs: number) {
  setState({
    answered: state.answered + 1,
    correct: state.correct + (ok ? 1 : 0),
    fastestMs: ok ? (state.fastestMs === 0 ? speedMs : Math.min(state.fastestMs, speedMs)) : state.fastestMs,
  });
}

export function recordGame(game: string, score: number, correct: number, total: number) {
  const history = [{ game, score, correct, total, date: Date.now() }, ...state.history].slice(0, 50);
  const recentGames = [game, ...state.recentGames.filter(g => g !== game)].slice(0, 8);
  const perfect = total > 0 && correct === total;
  setState({
    games: state.games + 1,
    history, recentGames,
    perfectRuns: state.perfectRuns + (perfect ? 1 : 0),
  });
  return perfect;
}

export function touchDaily(dateKey: string): { streak: number; isNew: boolean } {
  if (state.lastDaily === dateKey) return { streak: state.streak, isNew: false };
  const y = new Date(); y.setDate(y.getDate() - 1);
  const yKey = y.toISOString().slice(0, 10);
  const streak = state.lastDaily === yKey ? state.streak + 1 : 1;
  const bestStreak = Math.max(state.bestStreak, streak);
  setState({ streak, bestStreak, lastDaily: dateKey, dailyDone: state.dailyDone + 1 });
  return { streak, isNew: true };
}

export function discover(id: string) {
  if (state.discoveredIds.includes(id)) return;
  const discoveredIds = [...state.discoveredIds, id];
  setState({ discoveredIds, discovered: discoveredIds.length });
}

export function addMastery(cat: string, n: number) {
  setState({ mastery: { ...state.mastery, [cat]: (state.mastery[cat] ?? 0) + n } });
}

export function setRecord(key: string, value: number): boolean {
  if ((state.records[key] ?? -Infinity) >= value) return false;
  setState({ records: { ...state.records, [key]: value } });
  return true;
}

export function unlockAchievement(k: string, xp: number): boolean {
  if (state.achievements.includes(k)) return false;
  setState({ achievements: [...state.achievements, k], xp: state.xp + xp });

  // cosmetic unlocks
  const titles: Record<string, string> = {
    'arcade-legend': 'Arcade Legend', 'scholar': 'Block Scholar', 'streak-7': 'Week Warrior',
    'nightmare-clear': 'Nightmare Fuel', 'boss-slayer': 'Boss Slayer', 'collector-all': 'Completionist',
  };
  if (titles[k] && !state.titles.includes(titles[k])) {
    setState({ titles: [...state.titles, titles[k]] });
  }
  const frames: Record<string, string> = {
    'perfectionist': 'gold', 'insane-clear': 'nether', 'nightmare-clear': 'end',
    'tournament-x5': 'diamond', 'streak-30': 'emerald',
    'flawless-x3': 'ruby', 'lightning': 'frost', 'combo-20': 'shadow',
    'boss-slayer': 'lava', 'collector-all': 'slime', 'arcade-legend': 'royal',
    'streak-7': 'rainbow', 'scholar': 'animated',
  };
  if (frames[k] && !state.frames.includes(frames[k])) {
    setState({ frames: [...state.frames, frames[k]] });
  }
  return true;
}

export function useSettings() {
  const s = usePlayer();
  const update = useCallback((p: Partial<PlayerStats>) => setState(p), []);
  return { settings: s, update };
}

// Daily key helpers
export const todayKey = () => new Date().toISOString().slice(0, 10);
export const weekKey = () => {
  const d = new Date();
  const oneJan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil((((d.getTime() - oneJan.getTime()) / 86400000) + oneJan.getDay() + 1) / 7);
  return `${d.getFullYear()}-W${week}`;
};
// Seeded RNG (mulberry32) for deterministic daily/weekly content
export function seeded(str: string): () => number {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909);
    return ((h ^= h >>> 16) >>> 0) / 4294967296;
  };
}
export const shuffle = <T,>(arr: T[], rand: () => number = Math.random): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1));[a[i], a[j]] = [a[j], a[i]]; }
  return a;
};

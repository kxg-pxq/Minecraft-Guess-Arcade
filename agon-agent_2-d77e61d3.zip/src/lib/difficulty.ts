// Difficulty rules: timers, choices, hints, clue strength, visibility.
// Competitive modes (daily/weekly/leaderboard runs) use fixed rules.

export type Diff = 'Easy' | 'Medium' | 'Hard' | 'Insane' | 'Nightmare';

export interface DiffRule {
  choices: number; time: number; hints: number;
  typed: boolean; clueLevel: 0 | 1 | 2; visibility: number; mult: number;
}

export const DIFFS: Record<Diff, DiffRule> = {
  Easy: { choices: 4, time: 30, hints: 3, typed: false, clueLevel: 2, visibility: 1, mult: 1 },
  Medium: { choices: 4, time: 20, hints: 2, typed: false, clueLevel: 1, visibility: 0.7, mult: 1.5 },
  Hard: { choices: 6, time: 15, hints: 1, typed: true, clueLevel: 1, visibility: 0.4, mult: 2.2 },
  Insane: { choices: 6, time: 12, hints: 1, typed: true, clueLevel: 0, visibility: 0.18, mult: 3.2 },
  Nightmare: { choices: 8, time: 10, hints: 0, typed: true, clueLevel: 0, visibility: 0.1, mult: 5 },
};

export const DIFF_LIST: Diff[] = ['Easy', 'Medium', 'Hard', 'Insane', 'Nightmare'];

export interface HintDef { id: string; name: string; cost: number; desc: string }
export const HINTS: HintDef[] = [
  { id: 'category', name: 'Category Hint', cost: 15, desc: 'Reveal the entity category' },
  { id: 'letter', name: 'First Letter', cost: 20, desc: 'Reveal the first letter' },
  { id: 'remove', name: 'Remove Choices', cost: 25, desc: 'Remove two wrong options' },
  { id: 'image', name: 'Reveal Image', cost: 35, desc: 'Show more of the hidden visual' },
  { id: 'clue', name: 'Extra Clue', cost: 20, desc: 'Unlock the next clue line' },
  { id: 'wiki', name: 'Wiki Hint', cost: 30, desc: 'Show a fact excerpt' },
];

// score = base(100) * diff mult * speed bonus + combo bonus - hint costs
export function calcScore(opts: {
  correct: boolean; diff: Diff; elapsedMs: number; timeLimit: number;
  combo: number; hintsUsed: number; hintCostTotal: number; clueIndex?: number;
}): { points: number; breakdown: string[] } {
  const { correct, diff, elapsedMs, timeLimit, combo, hintCostTotal, clueIndex = 0 } = opts;
  if (!correct) return { points: 0, breakdown: ['Incorrect — no points'] };
  const rule = DIFFS[diff];
  const base = 100;
  const diffPts = Math.round(base * rule.mult);
  const speedFrac = Math.max(0, 1 - elapsedMs / (timeLimit * 1000));
  const speedPts = Math.round(50 * rule.mult * speedFrac);
  const comboPts = Math.min(combo, 20) * 5;
  const cluePts = Math.max(0, (2 - clueIndex)) * 10;
  const total = Math.max(10, diffPts + speedPts + comboPts + cluePts - hintCostTotal);
  const breakdown = [
    `Base ${base} × ${rule.mult} (${diff})`,
    `Speed +${speedPts}`,
    `Combo x${combo} +${comboPts}`,
  ];
  if (cluePts) breakdown.push(`Early-clue bonus +${cluePts}`);
  if (hintCostTotal) breakdown.push(`Hints −${hintCostTotal}`);
  return { points: total, breakdown };
}

export const xpForAnswer = (correct: boolean, diff: Diff) =>
  correct ? Math.round(10 * DIFFS[diff].mult) : 2;

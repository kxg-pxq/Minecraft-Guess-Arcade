import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../components/Icon';
import { usePlayer, todayKey, weekKey } from '../lib/store';
import ArcadeEngine from '../engines/ArcadeEngine';
import QuizEngine from '../engines/QuizEngine';
import { TRIVIA } from '../data/trivia';
import { seeded } from '../lib/store';

export default function Daily() {
  const p = usePlayer();
  const [tab, setTab] = useState<'pack' | 'question' | 'cup'>('pack');
  const done = p.lastDaily === todayKey();
  const dailyQ = TRIVIA[Math.floor(seeded('dailyq-' + todayKey())() * TRIVIA.filter(q => ['mc', 'tf', 'odd', 'whoami'].includes(q.t)).length)];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="font-pixel text-xl text-white">📅 DAILY & WEEKLY</h1>
        <div className="flex gap-2 text-xs">
          <span className="mc-chip">🔥 {p.streak}d streak (best {p.bestStreak})</span>
          <span className="mc-chip">Best daily: {p.bestDaily}</span>
        </div>
      </div>
      <div className="flex gap-1.5">
        {([['pack', 'DAILY PACK'], ['question', 'DAILY QUESTION'], ['cup', 'WEEKLY CUP']] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`mc-btn !text-xs ${tab === k ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{l}</button>
        ))}
      </div>
      {tab === 'pack' && (
        <div className="space-y-2">
          <div className="mc-panel p-3 text-center text-xs text-white/60">
            {done ? `✓ Completed today! Streak: ${p.streak} days. Come back tomorrow.` : `Today's shared pack (${todayKey()}): 5 fixed challenges, same for everyone.`} Competitive rules: Medium, 20s/question, no hints.
          </div>
          <ArcadeEngine key={todayKey()} gameId="daily-pack" mode="daily" />
        </div>
      )}
      {tab === 'question' && (
        <div className="space-y-2">
          <div className="mc-panel p-3 text-center text-xs text-white/60">One shared question for the whole arcade. Answer once!</div>
          <QuizEngine gameId="daily-question" mode="dailyq" singleQ={dailyQ} fixedDiff="Medium" />
        </div>
      )}
      {tab === 'cup' && (
        <div className="space-y-2">
          <div className="mc-panel p-3 text-center text-xs text-white/60">Week {weekKey()}: 10 fixed Hard questions. Resets Monday. Best: {p.bestWeekly}</div>
          <ArcadeEngine key={weekKey()} gameId="weekly-cup" mode="weekly" />
        </div>
      )}
      <Link to="/leaderboards" className="mc-btn mx-auto w-fit"><Icon name="Chart" size={16} /> VIEW LEADERBOARDS</Link>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Icon from '../components/Icon';
import PixelSprite from '../components/PixelSprite';
import { ENTITIES, CATS, byId, searchEntities, byCat } from '../data/entities';
import { GAMES } from '../data/games';
import { usePlayer, getState, setState, shuffle } from '../lib/store';

export function WikiIndex() {
  const p = usePlayer();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const results = q.trim() ? searchEntities(q) : [];
  const list = cat === 'all' ? ENTITIES : byCat(cat as never);
  const recent = p.recentWiki.map(byId).filter(Boolean);
  const featured = shuffle(ENTITIES).slice(0, 4);

  return (
    <div className="space-y-4">
      <h1 className="font-pixel text-xl text-white">📚 WIKI <span className="text-sm text-white/50">({ENTITIES.length} entries)</span></h1>
      <div className="flex items-center gap-2 rounded-md border-2 border-black/60 bg-[#120b1a] px-3 py-2.5">
        <Icon name="Search" size={18} className="text-white/50" />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search blocks, mobs, biomes, enchants…"
          className="w-full bg-transparent text-white outline-none placeholder:text-white/35" />
      </div>
      {q.trim() ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {results.map(e => <WikiCard key={e.id} id={e.id} />)}
          {results.length === 0 && <p className="text-white/60">No matches.</p>}
        </div>
      ) : (
        <>
          {recent.length > 0 && (
            <section>
              <h2 className="mb-2 font-pixel text-xs text-white/70">🕘 RECENTLY VIEWED</h2>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{recent.slice(0, 4).map(e => e && <WikiCard key={e.id} id={e.id} />)}</div>
            </section>
          )}
          <section>
            <h2 className="mb-2 font-pixel text-xs text-white/70">⭐ FEATURED</h2>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{featured.map(e => <WikiCard key={e.id} id={e.id} />)}</div>
          </section>
          <div className="flex flex-wrap gap-1.5">
            <button onClick={() => setCat('all')} className={`mc-btn !px-2 !py-1 !text-xs ${cat === 'all' ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>ALL</button>
            {CATS.map(c => (
              <button key={c.id} onClick={() => setCat(c.id)} className={`mc-btn !px-2 !py-1 !text-xs ${cat === c.id ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{c.name.toUpperCase()}</button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
            {list.map(e => <WikiCard key={e.id} id={e.id} />)}
          </div>
        </>
      )}
    </div>
  );
}

export function WikiCard({ id }: { id: string }) {
  const e = byId(id)!;
  const discovered = getState().discoveredIds.includes(id);
  return (
    <Link to={`/wiki/${id}`} className="mc-panel block p-2.5 transition-transform hover:-translate-y-0.5">
      <div className="flex items-center gap-2">
        <PixelSprite id={e.id} pal={e.pal} size={10} pixelSize={4} grayscale={!discovered} />
        <div className="min-w-0">
          <div className="truncate text-sm font-bold text-white">{discovered ? e.name : '???'}</div>
          <span className="mc-chip !text-[9px]">{e.cat}</span>
        </div>
      </div>
    </Link>
  );
}

export function WikiDetail() {
  const { id } = useParams();
  const e = byId(id ?? '');
  const p = usePlayer();

  useEffect(() => {
    if (!e) return;
    const s = getState();
    if (!s.discoveredIds.includes(e.id)) {
      import('../lib/store').then(m => m.discover(e.id));
    }
    setState({ wikiViews: s.wikiViews + 1, recentWiki: [e.id, ...s.recentWiki.filter(x => x !== e.id)].slice(0, 8) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!e) return <div className="mc-panel p-6 text-white">Entry not found. <Link to="/wiki" className="text-[#ffd94f]">Back →</Link></div>;

  const challenge = GAMES.find(g => g.pool === e.cat) ?? GAMES.find(g => g.kind === 'quiz');
  const related = shuffle(ENTITIES.filter(x => x.cat === e.cat && x.id !== e.id)).slice(0, 4);
  const relEntities = Object.values(e.rel).map(v => ENTITIES.find(x => x.name.toLowerCase() === v.toLowerCase().split(',')[0].trim().toLowerCase())).filter(Boolean);

  return (
    <div className="space-y-4">
      <Link to="/wiki" className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs"><Icon name="ArrowLeft" size={14} /> WIKI</Link>
      <div className="mc-panel p-5">
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
          <div className="rounded-lg border-4 border-black/60 bg-black/40 p-3">
            <PixelSprite id={e.id} pal={e.pal} size={16} pixelSize={8} />
          </div>
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-wrap justify-center gap-1.5 sm:justify-start">
              <span className="mc-chip !bg-[#6abe30]">{e.cat.toUpperCase()}</span>
              <span className="mc-chip">{e.sub}</span>
              <span className="mc-chip !bg-[#3b2a55]">v{e.ver}</span>
            </div>
            <h1 className="mt-1 font-pixel text-2xl text-white">{e.name}</h1>
            <p className="mt-1 text-sm text-white/75">{e.desc}</p>
            <p className="mt-2 rounded border border-[#ffd94f]/30 bg-[#ffd94f]/10 p-2 text-sm text-[#ffd94f]">💡 {e.fact}</p>
            <div className="mt-3 flex flex-wrap justify-center gap-2 sm:justify-start">
              {challenge && <Link to={`/play/${challenge.id}`} className="mc-btn !bg-[#6abe30]"><Icon name="Play" size={16} /> PLAY CHALLENGE</Link>}
              <Link to={`/play/guess-${e.cat === 'food' ? 'item' : e.cat === 'character' ? 'character' : e.cat}`} className="mc-btn mc-btn-gray">GUESS THIS</Link>
            </div>
          </div>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <div className="rounded-lg border border-white/10 bg-black/30 p-3">
            <h3 className="font-pixel text-xs text-[#ffd94f]">ATTRIBUTES</h3>
            {e.attrs.map(([k, v]) => <div key={k} className="mt-1 flex justify-between text-xs text-white/75"><span>{k}</span><b className="text-white">{v}</b></div>)}
          </div>
          <div className="rounded-lg border border-white/10 bg-black/30 p-3">
            <h3 className="font-pixel text-xs text-[#ffd94f]">RELATIONSHIPS</h3>
            {Object.entries(e.rel).map(([k, v]) => <div key={k} className="mt-1 text-xs text-white/75"><span className="text-white/50">{k}:</span> <b className="text-white">{v}</b></div>)}
            {relEntities.length > 0 && <div className="mt-2 flex flex-wrap gap-1">{relEntities.map(r => r && <Link key={r.id} to={`/wiki/${r.id}`} className="mc-chip hover:!bg-[#6abe30]">{r.name} →</Link>)}</div>}
          </div>
          <div className="rounded-lg border border-white/10 bg-black/30 p-3">
            <h3 className="font-pixel text-xs text-[#ffd94f]">GAME CLUES</h3>
            {e.clues.map((c, i) => <div key={i} className="mt-1 text-xs text-white/75">Lv{i + 1}: “{c}”</div>)}
            <div className="mt-2 text-[11px] text-white/40">Aliases: {e.aliases.join(', ') || '—'} · ID: {e.id}</div>
          </div>
        </div>
      </div>
      <section>
        <h2 className="mb-2 font-pixel text-xs text-white/70">🔗 RELATED DISCOVERY</h2>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{related.map(r => <WikiCard key={r.id} id={r.id} />)}</div>
      </section>
    </div>
  );
}

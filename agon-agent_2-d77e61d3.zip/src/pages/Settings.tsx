import { useSettings } from '../lib/store';
import Icon from '../components/Icon';

export default function Settings() {
  const { settings: s, update } = useSettings();

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="font-pixel text-xl text-white">⚙️ SETTINGS</h1>

      <section className="mc-panel space-y-3 p-4">
        <h2 className="font-pixel text-xs text-[#ffd94f]">🔊 AUDIO</h2>
        <Row label="Sound effects" control={
          <button onClick={() => update({ sound: !s.sound })} className={`mc-btn !text-xs ${s.sound ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{s.sound ? 'ON' : 'OFF'}</button>
        } />
        <Row label={`Volume (${Math.round(s.volume * 100)}%)`} control={
          <input type="range" min={0} max={100} value={s.volume * 100} onChange={e => update({ volume: Number(e.target.value) / 100 })} className="w-40 accent-[#6abe30]" />
        } />
      </section>

      <section className="mc-panel space-y-3 p-4">
        <h2 className="font-pixel text-xs text-[#ffd94f]">🎮 GAMEPLAY</h2>
        <Row label="Hardcore (no hints, anywhere)" control={
          <button onClick={() => update({ hardcore: !s.hardcore })} className={`mc-btn !text-xs ${s.hardcore ? '!bg-red-500' : 'mc-btn-gray'}`}>{s.hardcore ? 'ON' : 'OFF'}</button>
        } />
        <Row label="Reduced motion" control={
          <button onClick={() => update({ reducedMotion: !s.reducedMotion })} className={`mc-btn !text-xs ${s.reducedMotion ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{s.reducedMotion ? 'ON' : 'OFF'}</button>
        } />
        <Row label="🌈 Colorful UI" control={
          <button onClick={() => update({ colorUI: s.colorUI === false })} className={`mc-btn !text-xs ${s.colorUI !== false ? '!bg-[#b04fd8]' : 'mc-btn-gray'}`}>{s.colorUI !== false ? 'ON' : 'OFF'}</button>
        } />
        <Row label="Theme" control={
          <div className="flex flex-wrap gap-1">
            {['overworld', 'nether', 'end', 'gold'].map(t => (
              <button key={t} onClick={() => update({ theme: t })} className={`mc-btn !px-2 !py-1 !text-xs ${s.theme === t ? (t === 'gold' ? '!bg-[#e8a800] !text-black' : '!bg-[#6abe30]') : 'mc-btn-gray'}`}>{t === 'gold' ? '⭐ GOLD' : t.toUpperCase()}</button>
            ))}
          </div>
        } />
      </section>

      <section className="mc-panel space-y-3 p-4">
        <h2 className="font-pixel text-xs text-[#ffd94f]">🔒 PRIVACY</h2>
        <Row label="Public profile" control={
          <button onClick={() => update({ publicProfile: !s.publicProfile })} className={`mc-btn !text-xs ${s.publicProfile ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{s.publicProfile ? 'ON' : 'OFF'}</button>
        } />
        <Row label="Show on leaderboards" control={
          <button onClick={() => update({ showOnBoards: !s.showOnBoards })} className={`mc-btn !text-xs ${s.showOnBoards ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{s.showOnBoards ? 'ON' : 'OFF'}</button>
        } />
      </section>

      <section className="mc-panel space-y-2 p-4">
        <h2 className="font-pixel text-xs text-[#ffd94f]">ℹ️ ABOUT</h2>
        <p className="text-xs text-white/60">Minecraft Guess Arcade is a fan project. Not affiliated with Mojang or Microsoft. All art is original & procedurally generated; all audio is synthesized in-browser. Progress is stored locally on your device; leaderboard scores are shared publicly (if enabled).</p>
        <button onClick={() => { if (confirm('Reset ALL progress? This cannot be undone.')) { localStorage.clear(); window.location.reload(); } }} className="mc-btn !bg-red-500 !text-xs">
          <Icon name="X" size={14} /> RESET ALL PROGRESS
        </button>
      </section>
    </div>
  );
}

function Row({ label, control }: { label: string; control: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2 text-sm text-white">
      <span>{label}</span>{control}
    </div>
  );
}

import { useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Icon from '../components/Icon';
import { GAMES, type GameCat } from '../data/games';
import { GameCard } from './Home';

const CATS: (GameCat | 'ALL')[] = ['ALL', 'GUESS', 'VISUAL', 'TRIVIA', 'LETTER', 'CHALLENGE', 'BATTLE', 'ARCADE'];

export default function Play() {
  const [sp, setSp] = useSearchParams();
  const cat = (sp.get('cat') as GameCat | 'ALL') || 'ALL';
  const list = useMemo(() => cat === 'ALL' ? GAMES : GAMES.filter(g => g.cat === cat), [cat]);
  const quick = GAMES[Math.floor(Math.random() * GAMES.length)];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="font-pixel text-xl text-white">🎮 GAME ARCADE <span className="text-sm text-white/50">({GAMES.length} games)</span></h1>
        <Link to={`/play/${quick.id}`} className="mc-btn mc-btn-purple !text-xs"><Icon name="Dices" size={16} /> QUICK PLAY</Link>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {CATS.map(c => (
          <button key={c} onClick={() => setSp(c === 'ALL' ? {} : { cat: c })}
            className={`mc-btn !px-3 !py-1.5 !text-xs ${(cat === c || (c === 'ALL' && !sp.get('cat'))) ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>
            {c}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
        {list.map(g => <GameCard key={g.id} id={g.id} />)}
      </div>
    </div>
  );
}

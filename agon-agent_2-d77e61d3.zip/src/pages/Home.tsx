import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../components/Icon';
import PixelSprite from '../components/PixelSprite';
import { GAMES, featuredGames, popularGames, gameById } from '../data/games';
import { ENTITIES, byId, CATS } from '../data/entities';
import { usePlayer, todayKey, seeded, getState } from '../lib/store';
import { TRIVIA } from '../data/trivia';

export default function Home() {
  const p = usePlayer();
  const nav = useNavigate();
  const rand = seeded('home-' + todayKey());
  const dailyQ = TRIVIA[Math.floor(rand() * TRIVIA.length)];
  const featured = featuredGames();
  const popular = popularGames();
  const recent = p.recentGames.map(gameById).filter(Boolean);
  const [wiki] = useState(() => ENTITIES[Math.floor(Math.random() * ENTITIES.length)]);
  const [tick, setTick] = useState(0);
  useEffect(() => { const t = setInterval(() => setTick(x => x + 1), 4000); return () => clearInterval(t); }, []);

  const surprise = () => {
    const g = GAMES[Math.floor(Math.random() * GAMES.length)];
    nav(`/play/${g.id}`);
  };
  const randomThing = () => {
    const e = ENTITIES[Math.floor(Math.random() * ENTITIES.length)];
    nav(`/wiki/${e.id}`);
  };

  return (
    <div className="space-y-6">
      {/* HERO */}
      <section className="mc-panel relative overflow-hidden p-6 text-center sm:p-10">
        <div className="pointer-events-none absolute inset-0 opacity-20">
          {Array.from({ length: 24 }).map((_, i) => {
            const e = ENTITIES[(i * 7 + tick) % ENTITIES.length];
            return <span key={i} className="absolute" style={{ left: `${(i * 37) % 100}%`, top: `${(i * 53) % 100}%`, transform: `scale(${0.5 + (i % 3) * 0.3})` }}>
              <PixelSprite id={e.id} pal={e.pal} size={8} pixelSize={3} />
            </span>;
          })}
        </div>
        <div className="relative">
          <div className="hero-title font-pixel text-3xl text-white sm:text-5xl">MINECRAFT<br /><span className="text-[#ffd94f]">GUESS ARCADE</span></div>
          <p className="mx-auto mt-2 max-w-xl text-sm text-white/70 sm:text-base">
            75 guessing games, visual puzzles, trivia, letter battles & tournaments.
            Play → Guess → Reveal → Score → XP → Achievements!
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-3">
            <Link to="/play/guess-block" className="mc-btn mc-btn-yellow !px-8 !py-3 !text-lg">
              <Icon name="Play" size={22} /> PLAY NOW
            </Link>
            <button onClick={surprise} className="mc-btn mc-btn-purple !px-6 !py-3 !text-lg">
              <Icon name="Dices" size={22} /> SURPRISE ME
            </button>
          </div>
          <div className="mt-3 flex flex-wrap justify-center gap-2 text-xs">
            <span className="mc-chip">🔥 {p.streak}-day streak</span>
            <span className="mc-chip">⭐ Level {p.level}</span>
            <span className="mc-chip">🎮 {p.games} games</span>
          </div>
        </div>
      </section>

      {/* DAILY + FEATURED */}
      <section className="grid gap-4 md:grid-cols-2">
        <div className="mc-panel p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-pixel text-sm text-[#ffd94f]">📅 DAILY CHALLENGE</h2>
            <span className="mc-chip">{p.lastDaily === todayKey() ? '✓ DONE' : '● LIVE'}</span>
          </div>
          <p className="mt-2 text-sm text-white/80">Today's pack: Block + Mob + Visual + Trivia + Letter. Same for everyone!</p>
          <div className="mt-2 rounded border border-white/10 bg-black/30 p-2 text-xs text-white/70">Q: {dailyQ.q}</div>
          <Link to="/daily" className="mc-btn mt-3 w-full justify-center">PLAY DAILY PACK</Link>
        </div>
        <div className="mc-panel p-4">
          <h2 className="font-pixel text-sm text-[#ffd94f]">⭐ FEATURED GAME</h2>
          <div className="mt-2 flex items-center gap-3">
            <span className="grid h-14 w-14 place-items-center rounded-lg border-2 border-black/60 bg-[#e07b1f]"><Icon name={featured[0].icon} size={28} /></span>
            <div>
              <div className="font-bold text-white">{featured[0].name}</div>
              <div className="text-xs text-white/60">{featured[0].desc}</div>
            </div>
          </div>
          <Link to={`/play/${featured[0].id}`} className="mc-btn mt-3 w-full justify-center !bg-[#e07b1f]">PLAY FEATURED</Link>
        </div>
      </section>

      {/* CATEGORY STRIP */}
      <section>
        <h2 className="mb-2 font-pixel text-sm text-white">BROWSE CATEGORIES</h2>
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-8">
          {['GUESS', 'VISUAL', 'TRIVIA', 'LETTER', 'CHALLENGE', 'BATTLE', 'ARCADE', 'WIKI'].map((c, i) => (
            <Link key={c} to={c === 'WIKI' ? '/wiki' : `/play?cat=${c}`}
              className="mc-panel cat-tile p-2 text-center text-[11px] font-bold text-white transition-transform hover:scale-105">
              <div className="text-2xl">{['🧱', '👁️', '❓', '🔤', '⚔️', '🏆', '🕹️', '📚'][i]}</div>{c}
            </Link>
          ))}
        </div>
      </section>

      {/* POPULAR */}
      <section>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-pixel text-sm text-white">🔥 POPULAR GAMES</h2>
          <Link to="/play" className="text-xs text-[#ffd94f] hover:underline">View all 75 →</Link>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {popular.map(g => <GameCard key={g.id} id={g.id} />)}
        </div>
      </section>

      {/* RECENT + WIKI */}
      <section className="grid gap-4 md:grid-cols-2">
        <div className="mc-panel p-4">
          <h2 className="font-pixel text-sm text-white">🕘 RECENTLY PLAYED</h2>
          {recent.length === 0 && <p className="mt-2 text-sm text-white/60">Nothing yet — press PLAY NOW!</p>}
          <div className="mt-2 grid grid-cols-2 gap-2">
            {recent.slice(0, 4).map(g => g && <GameCard key={g.id} id={g.id} />)}
          </div>
        </div>
        <div className="mc-panel p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-pixel text-sm text-white">📚 WIKI SPOTLIGHT</h2>
            <button onClick={randomThing} className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs">🎲 RANDOM THING</button>
          </div>
          <Link to={`/wiki/${wiki.id}`} className="mt-2 flex items-center gap-3 rounded-lg border border-white/10 bg-black/30 p-2 hover:bg-black/50">
            <PixelSprite id={wiki.id} pal={wiki.pal} size={12} pixelSize={5} />
            <div>
              <div className="font-bold text-white">{wiki.name}</div>
              <div className="text-xs text-white/60">{wiki.desc}</div>
              <span className="mc-chip mt-1">{wiki.cat}</span>
            </div>
          </Link>
        </div>
      </section>
    </div>
  );
}

export function GameCard({ id }: { id: string }) {
  const g = gameById(id)!;
  if (!g) return null;
  return (
    <Link to={`/play/${g.id}`} className="mc-panel group block p-3 transition-transform hover:-translate-y-0.5">
      <div className="flex items-start justify-between">
        <span className="grid h-10 w-10 place-items-center rounded-md border-2 border-black/60 bg-[#3b2a55] text-[#ffd94f]"><Icon name={g.icon} size={22} /></span>
        <span className="text-[10px] text-white/40">{(g.plays / 1000).toFixed(1)}k plays</span>
      </div>
      <div className="mt-2 text-sm font-bold text-white">{g.name}</div>
      <div className="line-clamp-2 text-xs text-white/55">{g.desc}</div>
      <span className="mc-chip mt-2">{g.cat}</span>
    </Link>
  );
}

import { useParams, Link } from 'react-router-dom';
import Icon from '../components/Icon';
import { gameById } from '../data/games';
import GuessEngine from '../engines/GuessEngine';
import QuizEngine from '../engines/QuizEngine';
import LetterEngine from '../engines/LetterEngine';
import VisualEngine from '../engines/VisualEngine';
import FunEngine from '../engines/FunEngine';
import TourneyEngine from '../engines/TourneyEngine';
import ArcadeEngine from '../engines/ArcadeEngine';
import { usePlayer, setState } from '../lib/store';
import { useState } from 'react';

export default function GamePage() {
  const { id } = useParams();
  const g = gameById(id ?? '');
  const p = usePlayer();
  const [fav, setFav] = useState(p.favorites.includes(id ?? ''));

  if (!g) return <div className="mc-panel p-6 text-center text-white">Game not found. <Link to="/play" className="text-[#ffd94f]">Back to arcade →</Link></div>;

  const toggleFav = () => {
    const f = fav ? p.favorites.filter(x => x !== id) : [...p.favorites, id!];
    setState({ favorites: f }); setFav(!fav);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Link to="/play" className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs"><Icon name="ArrowLeft" size={14} /> ARCADE</Link>
        <span className="grid h-9 w-9 place-items-center rounded-md border-2 border-black/60 bg-[#3b2a55] text-[#ffd94f]"><Icon name={g.icon} size={20} /></span>
        <div className="flex-1">
          <h1 className="font-pixel text-base text-white sm:text-lg">{g.name}</h1>
          <p className="text-xs text-white/55">{g.desc}</p>
        </div>
        <button onClick={toggleFav} className={`mc-btn !px-2 !py-1 !text-xs ${fav ? '!bg-[#e07b1f]' : 'mc-btn-gray'}`}>
          {fav ? '★ FAVED' : '☆ FAVORITE'}
        </button>
        <button onClick={() => {
          const txt = `I scored big in ${g.name} on Minecraft Guess Arcade!`;
          if (navigator.share) navigator.share({ title: g.name, text: txt }).catch(() => {});
          else { navigator.clipboard?.writeText(txt); alert('Result copied!'); }
        }} className="mc-btn mc-btn-gray !px-2 !py-1 !text-xs"><Icon name="Share2" size={14} /> SHARE</button>
      </div>
      {g.kind === 'guess' && <GuessEngine gameId={g.id} pool={g.pool!} mode={g.mode} />}
      {g.kind === 'quiz' && <QuizEngine gameId={g.id} mode={g.mode!} />}
      {g.kind === 'letter' && <LetterEngine gameId={g.id} mode={g.mode!} />}
      {g.kind === 'visual' && <VisualEngine gameId={g.id} mode={g.mode!} />}
      {g.kind === 'fun' && <FunEngine gameId={g.id} mode={g.mode!} />}
      {g.kind === 'tourney' && <TourneyEngine gameId={g.id} mode={g.mode!} />}
      {g.kind === 'arcade' && <ArcadeEngine gameId={g.id} mode={g.mode!} />}
    </div>
  );
}

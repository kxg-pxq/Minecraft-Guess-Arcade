import { useEffect, useState } from 'react';
import Icon from '../components/Icon';
import { usePlayer, todayKey, weekKey } from '../lib/store';

interface Row { id: number; board: string; scope: string; name: string; avatar: string; title: string; score: number; created_at: string; }

const BOARDS = [
  { id: 'daily', label: 'DAILY', scope: todayKey() },
  { id: 'weekly', label: 'WEEKLY', scope: weekKey() },
  { id: 'alltime', label: 'ALL-TIME', scope: 'all' },
];

export default function Leaderboards() {
  const p = usePlayer();
  const [tab, setTab] = useState('daily');
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const b = BOARDS.find(x => x.id === tab)!;
    setLoading(true);
    fetch(`/api/scores?board=${b.id}&scope=${encodeURIComponent(tab === 'alltime' ? '' : b.scope)}`)
      .then(r => r.json())
      .then(d => { setRows(Array.isArray(d) ? d : []); setLoading(false); })
      .catch(() => { setRows([]); setLoading(false); });
  }, [tab]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="font-pixel text-xl text-white">🏆 LEADERBOARDS</h1>
        <span className="text-xs text-white/50">Fixed competitive rules · validated server-side</span>
      </div>
      <div className="flex gap-1.5">
        {BOARDS.map(b => (
          <button key={b.id} onClick={() => setTab(b.id)} className={`mc-btn !text-xs ${tab === b.id ? '!bg-[#ffd94f] !text-black' : 'mc-btn-gray'}`}>{b.label}</button>
        ))}
      </div>
      <div className="mc-panel overflow-hidden">
        {loading && <div className="p-6 text-center text-white/60">Loading scores…</div>}
        {!loading && rows.length === 0 && (
          <div className="p-6 text-center text-white/60">
            No scores yet — be the first! <br />
            <span className="text-xs">Play the Daily Pack, Weekly Cup or any arcade mode to post a score.</span>
          </div>
        )}
        {rows.map((r, i) => (
          <div key={r.id} className={`flex items-center gap-2 border-b border-white/5 px-3 py-2 ${r.name === p.name ? 'bg-[#ffd94f]/10' : ''}`}>
            <span className={`w-8 text-center font-pixel text-sm ${i === 0 ? 'text-[#ffd94f]' : i === 1 ? 'text-gray-300' : i === 2 ? 'text-amber-600' : 'text-white/40'}`}>
              {i + 1}
            </span>
            <span className="text-xl">{r.avatar}</span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-bold text-white">{r.name} {r.name === p.name && <span className="text-[#ffd94f]">(you)</span>}</div>
              <div className="text-[11px] text-white/45">{r.title} · {r.scope}</div>
            </div>
            <span className="font-pixel text-sm text-[#6abe30]">{r.score}</span>
          </div>
        ))}
      </div>
      <p className="text-center text-[11px] text-white/40">Daily resets at midnight UTC · Weekly resets Monday · Scores are capped & rate-limited to keep boards fair.</p>
    </div>
  );
}

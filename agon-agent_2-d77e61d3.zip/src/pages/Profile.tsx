import { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../components/Icon';
import PixelSprite from '../components/PixelSprite';
import { usePlayer, setState, levelFromXp, xpForLevel } from '../lib/store';
import { ACHIEVEMENTS } from '../data/achievements';
import { ENTITIES, byId, CATS } from '../data/entities';
import { FRAMES, safeFrame } from '../data/frames';
import AvatarFrame from '../components/AvatarFrame';
import { gameById } from '../data/games';

const AVATARS = ['⛏️', '🧱', '💎', '🐷', '🐺', '🐝', '👻', '🐉', '🧙', '🤖', '🎃', '🐢'];

export default function Profile() {
  const p = usePlayer();
  const [tab, setTab] = useState<'stats' | 'achievements' | 'collection' | 'history' | 'frames'>('stats');
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(p.name);
  const { level, into, need } = levelFromXp(p.xp);
  const acc = p.answered ? Math.round((p.correct / p.answered) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* header card */}
      <div className="mc-panel p-5 text-center">
        <div className="mx-auto w-fit"><AvatarFrame avatar={p.avatar} frame={p.activeFrame} size="md" /></div>
        {editing ? (
          <div className="mx-auto mt-2 flex max-w-xs gap-1">
            <input value={name} onChange={e => setName(e.target.value.slice(0, 16))} className="mc-input flex-1" />
            <button className="mc-btn !text-xs" onClick={() => { setState({ name: name.trim() || p.name }); setEditing(false); }}>SAVE</button>
          </div>
        ) : (
          <h1 className="mt-2 font-pixel text-xl text-white">{p.name} <button onClick={() => setEditing(true)} className="text-xs text-white/40 hover:text-white">✎</button></h1>
        )}
        <div className="mt-1 flex flex-wrap justify-center gap-1.5">
          <select value={p.activeTitle} onChange={e => setState({ activeTitle: e.target.value })} className="rounded border border-black/60 bg-black/40 px-2 py-0.5 text-xs text-[#ffd94f]">
            {p.titles.map(t => <option key={t}>{t}</option>)}
          </select>
        </div>
        {/* active frame summary (full gallery lives in the FRAMES tab) */}
        <div className="mx-auto mt-2 max-w-md text-[11px] text-white/50">
          Frame: <b className="text-[#ffd94f]">{FRAMES.find(f => f.id === safeFrame(p.activeFrame))?.name ?? p.activeFrame}</b>
          {' · '}🎉 All {FRAMES.length} frames are FREE — open the <button onClick={() => setTab('frames')} className="text-[#ffd94f] underline hover:text-white">FRAMES tab</button> to equip one!
          Frames decorate your avatar here AND in the top-right corner profile chip.
        </div>
        <div className="mx-auto mt-2 flex max-w-xs flex-wrap justify-center gap-1">
          {AVATARS.map(a => (
            <button key={a} onClick={() => setState({ avatar: a })} className={`rounded border-2 p-0.5 text-lg ${p.avatar === a ? 'border-[#ffd94f]' : 'border-transparent'}`}>{a}</button>
          ))}
        </div>
        <div className="mt-2 text-sm text-white/70">Level {level} · {p.xp} XP</div>
        <div className="mx-auto mt-1 h-3 max-w-md overflow-hidden rounded border-2 border-black/60 bg-black/50">
          <div className="h-full bg-gradient-to-r from-[#6abe30] to-[#ffd94f]" style={{ width: `${(into / need) * 100}%` }} />
        </div>
        <div className="mt-2 flex flex-wrap justify-center gap-1.5 text-xs">
          <span className="mc-chip">🔥 {p.streak}d streak</span>
          <span className="mc-chip">🎮 {p.games} games</span>
          <span className="mc-chip">🎯 {acc}% acc</span>
          <span className="mc-chip">🔥 best x{p.bestCombo}</span>
          <span className="mc-chip">🏆 {p.achievements.length}/{ACHIEVEMENTS.length}</span>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {(['stats', 'achievements', 'collection', 'history', 'frames'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`mc-btn !text-xs ${tab === t ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{t === 'frames' ? '🖼️ FRAMES' : t.toUpperCase()}</button>
        ))}
      </div>

      {tab === 'stats' && (
        <div className="grid gap-2 sm:grid-cols-2">
          <StatBox title="PERSONAL RECORDS" rows={[
            ['Fastest answer', p.fastestMs ? `${(p.fastestMs / 1000).toFixed(2)}s` : '—'],
            ['Best daily', String(p.bestDaily)], ['Best weekly', String(p.bestWeekly)],
            ['Best endless', String(p.bestEndless)], ['Best Letter Rush', String(p.bestLetterRush)],
            ['Perfect runs', String(p.perfectRuns)], ['Tournaments won', String(p.tournaments)],
            ['Boss clears', String(p.bossClears)],
          ]} />
          <StatBox title="CATEGORY MASTERY" rows={CATS.map(c => [c.name, `${p.mastery[c.id] ?? 0} ★`])} />
          <StatBox title="FAVORITES" rows={p.favorites.length ? p.favorites.map(f => [gameById(f)?.name ?? f, '→']) : [['No favorites yet', '☆']]} link />
        </div>
      )}

      {tab === 'achievements' && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {ACHIEVEMENTS.map(a => {
            const got = p.achievements.includes(a.k);
            if (a.secret && !got) return (
              <div key={a.k} className="mc-panel p-3 text-center opacity-50"><div className="text-2xl">❔</div><div className="text-xs font-bold text-white/60">Secret…</div></div>
            );
            return (
              <div key={a.k} className={`mc-panel p-3 text-center ${got ? '!border-[#ffd94f]' : 'opacity-60'}`}>
                <Icon name={got ? a.icon : 'X'} size={26} className="mx-auto text-[#ffd94f]" />
                <div className="mt-1 text-xs font-bold text-white">{a.n}</div>
                <div className="text-[11px] text-white/55">{a.d}</div>
                <div className="text-[11px] text-[#6abe30]">+{a.xp} XP</div>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'collection' && (
        <div className="space-y-3">
          <div className="mc-panel p-3 text-center text-sm text-white/70">Discovered {p.discoveredIds.length}/{ENTITIES.length} entities</div>
          {CATS.map(c => (
            <div key={c.id}>
              <h3 className="mb-1 font-pixel text-xs text-white/70">{c.name.toUpperCase()}</h3>
              <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
                {ENTITIES.filter(e => e.cat === c.id).map(e => {
                  const has = p.discoveredIds.includes(e.id);
                  return (
                    <Link key={e.id} to={has ? `/wiki/${e.id}` : '#'} className={`rounded-lg border-2 p-1.5 text-center ${has ? 'border-black/60 bg-[#241832]' : 'border-black/40 bg-black/20 opacity-50'}`}>
                      <PixelSprite id={e.id} pal={e.pal} size={10} pixelSize={4} grayscale={!has} />
                      <div className="mt-0.5 truncate text-[10px] font-bold text-white">{has ? e.name : '???'}</div>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'frames' && (
        <div className="mc-panel p-4">
          <h3 className="text-center font-pixel text-sm text-[#ffd94f]">🖼️ PROFILE FRAMES</h3>
          <p className="mt-1 text-center text-xs text-white/60">
            All {FRAMES.length} frames are FREE — click one to equip it on your avatar here and in the top-right corner profile chip.
          </p>
          {/* TOP 3 PICKS — exact image frames from your uploads */}
          <div className="mx-auto mt-3 grid max-w-2xl grid-cols-3 gap-2">
            {FRAMES.slice(0, 3).map((f, i) => {
              const sel = safeFrame(p.activeFrame) === f.id;
              return (
                <button key={f.id} onClick={() => setState({ activeFrame: f.id })}
                  title={`${f.name} — Top Pick ${i + 1} (FREE)`}
                  className={`relative rounded-lg border-2 p-2 text-center transition-transform hover:scale-[1.03] ${sel ? '!border-[#ffd94f] bg-[#ffd94f]/10' : 'border-[#ffd94f]/40 bg-black/30'}`}>
                  <span className="absolute left-1 top-1 z-10 rounded bg-[#ffd94f] px-1.5 py-0.5 font-pixel text-[10px] text-black">TOP {i + 1}</span>
                  <span className="mx-auto mt-4 block w-fit"><AvatarFrame avatar={p.avatar} frame={f.id} size="md" /></span>
                  <span className="mt-2 block text-xs font-bold text-white">{f.name} {sel && <span className="text-[#ffd94f]">✓</span>}</span>
                  <span className="mc-chip mt-1 !text-[9px]">FREE</span>
                </button>
              );
            })}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {FRAMES.slice(3).map(f => {
              const sel = safeFrame(p.activeFrame) === f.id;
              return (
                <button key={f.id} onClick={() => setState({ activeFrame: f.id })}
                  title={`${f.name} — ${f.hint} (FREE)`}
                  className={`rounded-lg border-2 p-3 text-center transition-transform hover:scale-[1.02] ${sel ? '!border-[#ffd94f] bg-[#ffd94f]/10' : 'border-black/60 bg-black/30'}`}>
                  <span className="mx-auto block w-fit"><AvatarFrame avatar={p.avatar} frame={f.id} size="sm" /></span>
                  <span className="mt-2 block text-xs font-bold text-white">{f.name} {sel && <span className="text-[#ffd94f]">✓</span>}</span>
                  <span className="block text-[10px] text-white/50">{f.hint}</span>
                  <span className="mc-chip mt-1 !text-[9px]">FREE</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="mc-panel overflow-hidden">
          {p.history.length === 0 && <div className="p-4 text-center text-sm text-white/50">No games yet.</div>}
          {p.history.map((h, i) => (
            <div key={i} className="flex items-center gap-2 border-b border-white/5 px-3 py-2 text-sm">
              <Icon name={gameById(h.game)?.icon ?? 'Gamepad2'} size={18} className="text-[#ffd94f]" />
              <span className="flex-1 truncate text-white">{gameById(h.game)?.name ?? h.game}</span>
              <span className="text-white/60">{h.correct}/{h.total}</span>
              <span className="font-bold text-[#6abe30]">{h.score}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatBox({ title, rows, link }: { title: string; rows: [string, string][]; link?: boolean }) {
  return (
    <div className="mc-panel p-3">
      <h3 className="font-pixel text-xs text-[#ffd94f]">{title}</h3>
      {rows.map(([k, v], i) => (
        <div key={i} className="mt-1 flex justify-between border-b border-white/5 pb-1 text-xs">
          <span className="text-white/70">{k}</span><b className="text-white">{v}</b>
        </div>
      ))}
    </div>
  );
}

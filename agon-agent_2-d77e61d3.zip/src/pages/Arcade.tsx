import { Link } from 'react-router-dom';
import { gamesByCat } from '../data/games';
import { GameCard } from './Home';

export default function Arcade() {
  const arcade = gamesByCat('ARCADE');
  return (
    <div className="space-y-4">
      <h1 className="font-pixel text-xl text-white">🕹️ ARCADE MODES</h1>
      <p className="text-sm text-white/60">Gauntlets with lives, clocks and fixed rules. Daily & Weekly scores hit the global boards.</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
        {arcade.map(g => <GameCard key={g.id} id={g.id} />)}
      </div>
      <div className="mc-panel p-4 text-center text-xs text-white/60">
        Competitive integrity: Daily (Medium, 20s, no hints) · Weekly (Hard, 18s, no hints). Scores validated & capped server-side.
        <Link to="/leaderboards" className="ml-2 text-[#ffd94f] hover:underline">View boards →</Link>
      </div>
    </div>
  );
}

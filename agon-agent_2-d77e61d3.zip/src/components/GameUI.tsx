import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from './Icon';
import PixelSprite from './PixelSprite';
import { byId } from '../data/entities';
import { playUI } from '../lib/audio';
import { getState } from '../lib/store';

export function TimerBar({ total, running, onExpire, resetKey }: { total: number; running: boolean; onExpire: () => void; resetKey: string | number }) {
  const [left, setLeft] = useState(total);
  const ref = useRef<number>(0);
  useEffect(() => {
    setLeft(total);
    if (!running) return;
    const start = Date.now();
    ref.current = window.setInterval(() => {
      const l = total - (Date.now() - start) / 1000;
      if (l <= 0) { clearInterval(ref.current); setLeft(0); onExpire(); } else setLeft(l);
    }, 100);
    return () => clearInterval(ref.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetKey, running]);
  const pct = Math.max(0, (left / total) * 100);
  return (
    <div className="h-3 w-full overflow-hidden rounded border-2 border-black/60 bg-black/50">
      <div className={`h-full transition-[width] ${pct < 25 ? 'bg-red-500' : pct < 50 ? 'bg-amber-400' : 'bg-[#6abe30]'}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function ScoreHUD({ score, combo, q, total, xp }: { score: number; combo: number; q: number; total: number; xp: number }) {
  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      <span className="mc-chip">SCORE <b>{score}</b></span>
      <span className={`mc-chip ${combo >= 3 ? '!bg-[#e07b1f]' : ''}`}>🔥 x{combo}</span>
      <span className="mc-chip">Q {q}/{total}</span>
      <span className="mc-chip !bg-[#3b2a55]">+{xp} XP</span>
    </div>
  );
}

export interface ResultInfo {
  correct: boolean; answerId: string; fact: string;
  points: number; breakdown: string[]; xp: number; combo: number; hintsUsed: number;
  newRecords: string[];
}

export function ResultCard({ r, gameId, onNext, onRetry, isLast }: { r: ResultInfo; gameId: string; onNext: () => void; onRetry: () => void; isLast: boolean }) {
  const nav = useNavigate();
  const e = byId(r.answerId);
  useEffect(() => { playUI(r.correct ? 'correct' : 'wrong', getState().sound ? getState().volume : 0); }, [r]);
  return (
    <div className={`mc-panel p-5 text-center ${r.correct ? '!border-[#6abe30]' : '!border-red-500'}`}>
      <div className={`font-pixel text-xl ${r.correct ? 'text-[#6abe30]' : 'text-red-400'}`}>
        {r.correct ? '✓ CORRECT!' : '✗ INCORRECT'}
      </div>
      <div className="mt-2 text-lg font-bold text-white">{e?.name}</div>
      {e && <div className="mx-auto mt-2 w-fit rounded-lg border-2 border-black/60 bg-black/40 p-2"><PixelSprite id={e.id} pal={e.pal} size={16} pixelSize={6} /></div>}
      <p className="mx-auto mt-2 max-w-md text-sm text-white/75">💡 {r.fact}</p>
      <div className="mx-auto mt-3 max-w-sm rounded-md border border-white/10 bg-black/30 p-2 text-left text-xs text-white/80">
        <div className="font-bold text-[#ffd94f]">+{r.points} pts · +{r.xp} XP · 🔥x{r.combo}</div>
        {r.breakdown.map((b, i) => <div key={i}>• {b}</div>)}
        {r.hintsUsed > 0 && <div>• Hints used: {r.hintsUsed}</div>}
        {r.newRecords.map(rec => <div key={rec} className="font-bold text-[#ffd94f]">🏆 NEW PERSONAL BEST: {rec}</div>)}
      </div>
      <div className="mt-4 flex flex-wrap justify-center gap-2">
        <button className="mc-btn" onClick={onNext}>{isLast ? 'FINISH' : 'NEXT'} <Icon name="ChevronRight" size={16} /></button>
        <button className="mc-btn mc-btn-gray" onClick={onRetry}><Icon name="RotateCcw" size={16} /> RETRY</button>
        {e && <button className="mc-btn mc-btn-blue" onClick={() => nav(`/wiki/${e.id}`)}><Icon name="BookOpen" size={16} /> OPEN WIKI</button>}
      </div>
      <div className="mt-2 text-[11px] text-white/40">Game: {gameId} · Retry is practice — first-attempt stats stay intact.</div>
    </div>
  );
}

export function DifficultyPicker({ value, onChange }: { value: string; onChange: (d: string) => void }) {
  const ds = ['Easy', 'Medium', 'Hard', 'Insane', 'Nightmare'];
  return (
    <div className="flex flex-wrap gap-1.5">
      {ds.map(d => (
        <button key={d} onClick={() => onChange(d)}
          className={`mc-btn !px-3 !py-1 !text-xs ${value === d ? '!bg-[#6abe30]' : 'mc-btn-gray'}`}>{d.toUpperCase()}</button>
      ))}
    </div>
  );
}

export function ChoiceGrid({ choices, picked, answerIdx, onPick, disabled }: {
  choices: string[]; picked: number | null; answerIdx: number; onPick: (i: number) => void; disabled: boolean;
}) {
  const labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const colors = ['#ff4d6d', '#4fa8f0', '#6abe30', '#ffd94f', '#b04fd8', '#ff6a1a', '#5ff2e0', '#ff9ad5'];
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {choices.map((c, i) => {
        let cls = 'mc-choice';
        if (picked !== null) {
          if (i === answerIdx) cls += ' !border-[#6abe30] !bg-[#2e7d32]';
          else if (i === picked) cls += ' !border-red-500 !bg-[#7d2a2a]';
          else cls += ' opacity-60';
        }
        return (
          <button key={i} disabled={disabled} onClick={() => onPick(i)} className={`${cls} !flex-row !items-center gap-3`}>
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-md border-2 border-black/60 font-pixel text-sm text-black"
              style={{ background: colors[i % colors.length] }}>{labels[i % labels.length]}</span>
            <span>{c}</span>
          </button>
        );
      })}
    </div>
  );
}

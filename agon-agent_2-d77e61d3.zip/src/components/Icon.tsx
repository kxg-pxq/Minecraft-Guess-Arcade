import {
  Box, Backpack, Ghost, Trees, Castle, Globe, Hammer, Shield, Wand, FlaskConical,
  Volume2, CookingPot, History, Bone, Grid3x3, Camera, MapPin, Smile, ScanSearch,
  ZoomIn, Moon, Puzzle, Brain, Eye, Bug, Images, MousePointerClick, ListOrdered,
  CircleAlert, Palette, CalendarDays, CircleHelp, CheckCheck, ListChecks, Scale,
  ArrowDownUp, Split, TrendingUp, PenLine, Banknote, Flame, Footprints, CaseSensitive,
  Timer, Tags, BookA, Link, Ban, Repeat, Hash, Crown, Shuffle, Keyboard, MoveHorizontal,
  Tent, Briefcase, Package, Gem, Flag, Swords, Trophy, Dices, DoorOpen, Coins,
  Infinity as InfinityIcon, Heart, Gauge, Star, Skull, Milestone, Award, CalendarCheck,
  CupSoda, Home, Play, Gamepad2, BookOpen, ChartNoAxesColumn, User, Settings as SettingsIcon,
  Search, Shuffle as ShuffleIcon, Zap, Sparkles, GraduationCap, Medal, Library, Boxes,
  BrainCircuit, Vote, Rabbit, HeartPulse, Moon as MoonIcon, Check, X, Clock, Lightbulb,
  ChevronRight, ArrowLeft, RotateCcw, Share2, VolumeX, Trophy as TrophyIcon, Info, Target,
  Layers, Compass, Rocket, WholeWord, Dices as DiceIcon, House, CircleHelp as Help,
} from 'lucide-react';

const MAP: Record<string, React.ComponentType<{ size?: number | string; className?: string }>> = {
  Box, Backpack, Ghost, Trees, Castle, Globe, Hammer, Shield, Wand, FlaskConical,
  Volume2, CookingPot, History, Bone, Grid3x3, Camera, MapPin, Smile, ScanSearch,
  ZoomIn, Moon, Puzzle, Brain, Eye, Bug, Images, MousePointerClick, ListOrdered,
  CircleAlert, Palette, CalendarDays, CircleHelp, CheckCheck, ListChecks, Scale,
  ArrowDownUp, Split, TrendingUp, PenLine, Banknote, Flame, Footprints, CaseSensitive,
  Timer, Tags, BookA, Link, Ban, Repeat, Hash, Crown, Shuffle, Keyboard, MoveHorizontal,
  Tent, Briefcase, Package, Gem, Flag, Swords, Trophy, Dices, DoorOpen, Coins,
  Infinity: InfinityIcon, Heart, Gauge, Star, Skull, Milestone, Award, CalendarCheck,
  CupSoda, Home, Play, Gamepad2, BookOpen, Chart: ChartNoAxesColumn, User, Settings: SettingsIcon,
  Search, Zap, Sparkles, GraduationCap, Medal, Library, Boxes, BrainCircuit, Vote,
  Rabbit, HeartPulse, Check, X, Clock, Lightbulb, ChevronRight, ArrowLeft, RotateCcw,
  Share2, VolumeX, Info, Target, Layers, Compass, Rocket, WholeWord, Boss: Skull,
  CrystalBall: Dices, House,
};

export default function Icon({ name, size = 20, className = '' }: { name: string; size?: number | string; className?: string }) {
  const C = MAP[name] || Help;
  return <C size={size} className={className} />;
}

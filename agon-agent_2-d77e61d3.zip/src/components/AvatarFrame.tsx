import { safeFrame, FRAMES } from '../data/frames';

// Avatar wrapped in the equipped profile frame. Used by the top-right
// header chip AND the profile page avatar so both always match.
// Art frames (art-pro / art-victory / art-elite) overlay the exact
// user-supplied frame images on top of the avatar — no emojis, no code art.
export default function AvatarFrame({
  avatar, frame, size = 'md',
}: {
  avatar: string; frame: string; size?: 'sm' | 'md' | 'lg';
}) {
  const f = safeFrame(frame);
  const dims =
    size === 'sm' ? 'h-9 w-9 text-xl rounded-lg' :
    size === 'lg' ? 'h-24 w-24 text-6xl rounded-2xl' :
    'h-20 w-20 text-5xl rounded-xl';
  const def = FRAMES.find(x => x.id === f);

  // Exact image frames: avatar sits inside the inner window, art overlays all.
  if (def?.img) {
    return (
      <span className={`relative grid shrink-0 place-items-center ${dims}`} title={def.name}>
        <span className="absolute grid place-items-center overflow-hidden rounded-[6px] bg-[#2a1c3d]"
          style={{ inset: '17% 16% 13% 16%' }}>
          <span className="leading-none" style={{ fontSize: '1.55em' }}>{avatar}</span>
        </span>
        <img src={def.img} alt="" draggable={false}
          className="pointer-events-none absolute inset-0 z-10 h-full w-full select-none" />
      </span>
    );
  }

  // Champion Pro: ornate gold ring + crown, built with pure CSS (no external art)
  if (f === 'pro') {
    return (
      <span className={`avatar-pro relative grid shrink-0 place-items-center ${dims}`} title={def?.name}>
        <span className="absolute -top-3 left-1/2 z-10 -translate-x-1/2 text-lg leading-none drop-shadow-[0_2px_2px_rgba(0,0,0,0.7)]">👑</span>
        <span className="grid h-full w-full place-items-center overflow-hidden rounded-[inherit] bg-[#2a1c3d]">{avatar}</span>
      </span>
    );
  }

  if (f === 'rainbow') {
    return (
      <span className={`avatar-rainbow relative grid shrink-0 place-items-center p-[3px] ${dims}`} title={def?.name}>
        <span className="grid h-full w-full place-items-center overflow-hidden rounded-[inherit] bg-[#2a1c3d]">{avatar}</span>
      </span>
    );
  }

  const border =
    f === 'default' ? 'border-black/60' :
    f === 'gold' ? 'border-[#ffd94f] shadow-[0_0_12px_rgba(255,217,79,0.6)]' :
    f === 'animated' ? 'border-[#ffd94f] avatar-pulse' :
    '';
  const style =
    f === 'default' || f === 'gold' || f === 'animated'
      ? undefined
      : { borderColor: def?.swatch, boxShadow: `0 0 12px ${def?.swatch}` };

  return (
    <span
      title={def?.name}
      style={style}
      className={`grid shrink-0 place-items-center overflow-hidden border-4 bg-[#2a1c3d] ${dims} ${border}`}
    >
      {avatar}
    </span>
  );
}

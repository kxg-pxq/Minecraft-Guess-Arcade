import { useEffect } from 'react';
import { ACHIEVEMENTS } from '../data/achievements';
import { getState, unlockAchievement } from '../lib/store';

// Check + unlock achievements. Returns newly unlocked keys.
export function checkAchievements(ctx: { perfect?: boolean; combo?: number; speedMs?: number; game?: string; diff?: string } = {}): string[] {
  const s = getState();
  const fresh: string[] = [];
  for (const a of ACHIEVEMENTS) {
    if (s.achievements.includes(a.k)) continue;
    try {
      if (a.check(s, ctx)) {
        if (unlockAchievement(a.k, a.xp)) fresh.push(a.k);
      }
    } catch { /* ignore */ }
  }
  return fresh;
}

export function Toast({ msg, onDone }: { msg: string | null; onDone: () => void }) {
  useEffect(() => {
    if (!msg) return;
    const t = setTimeout(onDone, 3200);
    return () => clearTimeout(t);
  }, [msg, onDone]);
  if (!msg) return null;
  return (
    <div className="fixed left-1/2 top-20 z-50 -translate-x-1/2 animate-bounce rounded-lg border-4 border-[#ffd94f] bg-[#2a1c3d] px-4 py-2 text-center shadow-xl">
      <div className="font-pixel text-xs text-[#ffd94f]">🏆 ACHIEVEMENT</div>
      <div className="text-sm font-bold text-white">{msg}</div>
    </div>
  );
}

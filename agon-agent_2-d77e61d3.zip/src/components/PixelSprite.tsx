// Procedural pixel-sprite generator — 100% original art, no Mojang assets.
// Deterministic per entity id: same id always yields the same sprite.
import { useMemo } from 'react';

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

export function spriteGrid(id: string, size = 16): number[][] {
  const h = hashStr(id);
  const grid: number[][] = [];
  const style = h % 5; // 0 blob, 1 face, 2 ore, 3 stripes, 4 emblem
  for (let y = 0; y < size; y++) {
    const row: number[] = [];
    for (let x = 0; x < size; x++) {
      // mirror for symmetry
      const mx = x < size / 2 ? x : size - 1 - x;
      const n = hashStr(`${id}:${mx},${y}`) % 100;
      let v = 0;
      if (style === 0) { // blob
        const cx = size / 2 - 0.5, cy = size / 2 - 0.5;
        const d = Math.hypot(mx - cx, y - cy) / (size / 2);
        v = d > 0.95 ? 0 : n < 18 ? 1 : n < 30 ? 2 : n < 38 ? 3 : 0 + (d < 0.5 ? 0 : 0);
        if (d <= 0.95 && v === 0) v = 0;
      } else if (style === 1) { // face
        const eye = y >= size * 0.3 && y < size * 0.45 && ((mx >= size * 0.2 && mx < size * 0.35) || (mx >= size * 0.65 && mx < size * 0.8));
        const mouth = y >= size * 0.62 && y < size * 0.72 && mx >= size * 0.3 && mx < size * 0.7;
        v = eye || mouth ? 3 : n < 25 ? 1 : n < 40 ? 2 : 0;
      } else if (style === 2) { // ore
        const spot = [[0.28, 0.3], [0.68, 0.25], [0.5, 0.55], [0.3, 0.72], [0.72, 0.7]]
          .some(([sx, sy]) => Math.hypot(mx / size - sx, y / size - sy) < 0.11);
        v = spot ? (n < 50 ? 2 : 3) : n < 30 ? 1 : 0;
      } else if (style === 3) { // stripes
        v = (y % 4 === 0) ? 1 : (y % 4 === 2 && n < 40) ? 2 : (n < 8 ? 3 : 0);
      } else { // emblem
        const cx = size / 2, cy = size / 2;
        const ring = Math.abs(Math.hypot(mx - cx, y - cy) - size * 0.3) < 1.2;
        const core = Math.hypot(mx - cx, y - cy) < size * 0.14;
        v = core ? 2 : ring ? 3 : n < 22 ? 1 : 0;
      }
      row.push(v);
    }
    grid.push(row);
  }
  return grid;
}

interface Props {
  id: string;
  pal: [string, string, string, string];
  size?: number;
  pixelSize?: number;
  className?: string;
  style?: React.CSSProperties;
  crop?: number; // 0..1 visible fraction (center crop)
  silhouette?: boolean;
  grayscale?: boolean;
  rotate?: number;
  glitch?: boolean;
  seed?: string;
}

export default function PixelSprite({ id, pal, size = 16, pixelSize = 8, className = '', style, crop = 1, silhouette = false, grayscale = false, rotate = 0, glitch = false, seed = '' }: Props) {
  const dataUrl = useMemo(() => {
    const grid = spriteGrid(id + seed, size);
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    const colors = silhouette ? ['#14101f', '#0d0a16', '#241d38', '#000000'] : [pal[0], pal[1], pal[2], pal[3]];
    const show = Math.max(1, Math.floor(size * crop));
    const off = Math.floor((size - show) / 2);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const inCrop = x >= off && x < off + show && y >= off && y < off + show;
        if (!inCrop) { ctx.fillStyle = 'rgba(0,0,0,0)'; ctx.fillRect(x, y, 1, 1); continue; }
        let v = grid[y][x];
        if (glitch && hashStr(`${id}:${x},${y}:g`) % 7 === 0) v = (v + 2) % 4;
        let c = colors[v];
        if (grayscale) {
          const rgb = parseInt(c.slice(1), 16);
          const g = Math.round(((rgb >> 16) * 0.3 + ((rgb >> 8) & 255) * 0.6 + (rgb & 255) * 0.1));
          c = `rgb(${g},${g},${g})`;
        }
        ctx.fillStyle = c;
        ctx.fillRect(x, y, 1, 1);
      }
    }
    return canvas.toDataURL();
  }, [id, pal, size, crop, silhouette, grayscale, glitch, seed]);

  return (
    <img
      src={dataUrl}
      alt=""
      draggable={false}
      className={className}
      style={{ width: pixelSize * size, height: pixelSize * size, imageRendering: 'pixelated', transform: rotate ? `rotate(${rotate}deg)` : undefined, ...style }}
    />
  );
}

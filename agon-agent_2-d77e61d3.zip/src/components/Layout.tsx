import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Icon from './Icon';
import { usePlayer, levelFromXp, xpForLevel } from '../lib/store';
import { searchEntities } from '../data/entities';
import { safeFrame } from '../data/frames';
import AvatarFrame from './AvatarFrame';
import PixelSprite from './PixelSprite';

const NAV = [
  { to: '/', label: 'Home', icon: 'Home', c: '#6abe30' },
  { to: '/play', label: 'Play', icon: 'Play', c: '#ffd94f' },
  { to: '/daily', label: 'Daily', icon: 'CalendarCheck', c: '#4fa8f0' },
  { to: '/arcade', label: 'Arcade', icon: 'Gamepad2', c: '#ff6a1a' },
  { to: '/wiki', label: 'Wiki', icon: 'BookOpen', c: '#5ff2e0' },
  { to: '/leaderboards', label: 'Boards', icon: 'Chart', c: '#ff4d6d' },
  { to: '/profile', label: 'Profile', icon: 'User', c: '#b04fd8' },
  { to: '/settings', label: 'Settings', icon: 'Settings', c: '#9aa4b2' },
];

export function TopBar() {
  const p = usePlayer();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const { level, into, need } = levelFromXp(p.xp);
  const results = searchEntities(q);
  const gold = p.theme === 'gold';

  return (
    <header className={`sticky top-0 z-40 border-b-4 border-black/60 backdrop-blur ${gold ? 'bg-[#2b1f06]/95' : 'bg-[#1d1226]/95'}`}>
      <div className="mx-auto flex max-w-7xl items-center gap-2 px-3 py-2">
        <Link to="/" className="flex shrink-0 items-center gap-2">
          <span className={`grid h-9 w-9 place-items-center rounded-md border-2 border-black/60 text-xl shadow-[2px_2px_0_#000] ${gold ? 'bg-gradient-to-br from-[#ffd94f] to-[#b87700]' : 'bg-gradient-to-br from-[#6abe30] to-[#2e7d32]'}`}>⛏️</span>
          <span className="hidden font-pixel text-sm leading-tight text-white sm:block">
            MINECRAFT<br /><span className="text-[#ffd94f]">GUESS ARCADE</span>
          </span>
        </Link>
        {/* wiki search */}
        <div className="relative mx-auto w-full max-w-md flex-1">
          <div className={`flex items-center gap-2 rounded-md border-2 px-2 py-1.5 ${gold ? 'border-[#ffd94f]/40 bg-[#1c1304]' : 'border-black/60 bg-[#120b1a]'}`}>
            <Icon name="Search" size={16} className="text-white/50" />
            <input
              value={q} onChange={e => setQ(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && results[0]) { nav(`/wiki/${results[0].id}`); setQ(''); } }}
              placeholder="Search the wiki… (blocks, mobs, biomes)"
              className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/35"
            />
          </div>
          {q.trim() && (
            <div className={`absolute left-0 right-0 top-full z-50 mt-1 overflow-hidden rounded-md border-2 ${gold ? 'border-[#ffd94f]/40 bg-[#2c2106]' : 'border-black/60 bg-[#241832]'}`}>
              {results.length === 0 && <div className="px-3 py-2 text-sm text-white/60">No matches — try another word.</div>}
              {results.map(e => (
                <button key={e.id} onClick={() => { nav(`/wiki/${e.id}`); setQ(''); }}
                  className="flex w-full items-center gap-2 px-2 py-1.5 text-left hover:bg-white/10">
                  <PixelSprite id={e.id} pal={e.pal} size={8} pixelSize={3} />
                  <span className="text-sm text-white">{e.name}</span>
                  <span className="ml-auto rounded bg-white/10 px-1.5 text-[10px] uppercase text-white/60">{e.cat}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        {/* player chip — avatar wears the equipped profile frame */}
        <Link to="/profile" className={`flex shrink-0 items-center gap-2 rounded-md border-2 px-2 py-1 chip-frame-${safeFrame(p.activeFrame)} ${gold ? 'border-[#ffd94f]/40 bg-[#3a2b08]' : 'border-black/60 bg-[#2a1c3d]'}`}>
          <AvatarFrame avatar={p.avatar} frame={p.activeFrame} size="sm" />
          <span className="hidden text-left leading-tight md:block">
            <span className="block text-xs font-bold text-white">{p.activeTitle} · Lv {level}</span>
            <span className="block h-1.5 w-20 overflow-hidden rounded bg-black/50">
              <span className={`block h-full ${gold ? 'bg-[#ffd94f]' : 'bg-[#6abe30]'}`} style={{ width: `${(into / need) * 100}%` }} />
            </span>
          </span>
        </Link>
      </div>
      {/* desktop nav */}
      <nav className="mx-auto hidden max-w-7xl items-center gap-1 px-3 pb-2 md:flex">
        {NAV.map(n => (
          <NavLink key={n.to} to={n.to}
            style={p.colorUI !== false ? ({ '--nav-c': n.c } as React.CSSProperties) : undefined}
            className={({ isActive }) => `mc-btn nav-btn flex items-center gap-1.5 !px-3 !py-1.5 !text-xs ${isActive ? 'nav-active' : ''} ${n.label === 'Play' ? 'mc-btn-yellow' : ''}`}>
            <Icon name={n.icon} size={14} /> {n.label.toUpperCase()}
          </NavLink>
        ))}
      </nav>
    </header>
  );
}

export function BottomNav() {
  const p = usePlayer();
  const gold = p.theme === 'gold';
  const items = NAV.slice(0, 7);
  return (
    <nav className={`fixed bottom-0 left-0 right-0 z-40 grid grid-cols-7 border-t-4 border-black/60 backdrop-blur md:hidden ${gold ? 'bg-[#2b1f06]/95' : 'bg-[#1d1226]/95'}`}>
      {items.map(n => (
        <NavLink key={n.to} to={n.to}
          style={p.colorUI !== false ? ({ color: undefined } as React.CSSProperties) : undefined}
          className={({ isActive }) => `flex flex-col items-center gap-0.5 py-2 text-[10px] font-bold ${isActive ? 'text-[#ffd94f]' : 'text-white/60'} ${n.label === 'Play' ? '!text-[#ffd94f]' : ''}`}>
          <span style={p.colorUI !== false ? { color: n.c } : undefined} className="grid place-items-center">
            <Icon name={n.icon} size={20} />
          </span>
          {n.label}
        </NavLink>
      ))}
    </nav>
  );
}

export function Footer() {
  const p = usePlayer();
  const gold = p.theme === 'gold';
  return (
    <footer className={`mt-10 border-t-4 px-4 py-6 text-center text-xs text-white/50 ${gold ? 'border-[#ffd94f]/30 bg-[#1c1304]' : 'border-black/60 bg-[#140d1e]'}`}>
      <p className="font-bold text-white/70">MINECRAFT GUESS ARCADE — a fan project</p>
      <p className="mx-auto mt-1 max-w-2xl">Not affiliated with, endorsed by, or connected to Mojang Studios or Microsoft. All artwork on this site is original and procedurally generated; all sounds are original synthesized effects.</p>
    </footer>
  );
}
